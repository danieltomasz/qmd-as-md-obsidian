'use strict';

var obsidian = require('obsidian');
var child_process = require('child_process');
var path = require('path');
var electron = require('electron');
var state = require('@codemirror/state');
var view = require('@codemirror/view');
var commands = require('@codemirror/commands');

function _interopNamespaceDefault(e) {
    var n = Object.create(null);
    if (e) {
        Object.keys(e).forEach(function (k) {
            if (k !== 'default') {
                var d = Object.getOwnPropertyDescriptor(e, k);
                Object.defineProperty(n, k, d.get ? d : {
                    enumerable: true,
                    get: function () { return e[k]; }
                });
            }
        });
    }
    n.default = e;
    return Object.freeze(n);
}

var path__namespace = /*#__PURE__*/_interopNamespaceDefault(path);

// --- Quarto output plumbing -----------------------------------------------
//
// Node's spawn-stream chunks don't align with line boundaries — a single
// data event can contain a partial line, and a logical line can be split
// across two events. Build a per-stream processor that buffers the
// trailing partial line and only emits whole lines. Call .flush() on the
// close handler to release any final partial line.
//
// logQuartoLine routes a single line to console by severity prefix:
// "ERROR:" -> console.error, "WARNING:"/"WARN:" -> console.warn,
// everything else -> console.log. Centralised so both the preview and
// render paths stay in sync and new prefixes only need handling here.
function logQuartoLine(prefix, line) {
    if (/^ERROR:/.test(line)) {
        console.error(`${prefix}: ${line}`);
    }
    else if (/^WARN(ING)?:/.test(line)) {
        console.warn(`${prefix}: ${line}`);
    }
    else {
        console.log(`${prefix}: ${line}`);
    }
}
function makeLineProcessor(handle) {
    let buffer = '';
    const proc = ((chunk) => {
        buffer += chunk;
        const lines = buffer.split(/\r?\n/);
        // Last element is the trailing fragment after the final newline
        // (or the whole chunk if there was no newline at all). Keep it
        // for the next chunk.
        buffer = lines.pop() ?? '';
        for (const line of lines) {
            if (line)
                handle(line);
        }
    });
    proc.flush = () => {
        if (buffer) {
            handle(buffer);
            buffer = '';
        }
    };
    return proc;
}
function stripAnsiCodes(text) {
    return text.replace(/\x1B\[[0-?]*[ -/]*[@-~]/g, '');
}
function previewUrlFromLine(line) {
    const match = stripAnsiCodes(line).match(/Browse at\s+(https?:\/\/\S+)/);
    return match?.[1] ?? null;
}
// --- Quarto outline -------------------------------------------------------
//
// Obsidian's core Outline panel reads headings from metadataCache, which
// only parses .md files — a .qmd opened via registerExtensions still gets
// no heading cache, so the panel stays blank (issue #3). parseQmdHeadings
// scans the file text directly: ATX headings (`# ...`, up to 3 spaces of
// indent per CommonMark) only — setext headings (underlined with === / ---)
// are intentionally not supported, they are vanishingly rare in Quarto and
// the --- form collides with YAML/frontmatter syntax. The scan skips the
// YAML frontmatter block and fenced code blocks (``` / ~~~) so a `#` line
// inside an R/Python cell is not mistaken for a heading.
const QMD_OUTLINE_VIEW = 'qmd-outline-view';
const QMD_YAML_VIEW = 'qmd-yaml-view';
function parseQmdHeadings(content) {
    const lines = content.split(/\r?\n/);
    const headings = [];
    let inFrontmatter = false;
    // Open code-fence state. Per CommonMark, a fence closes only on the same
    // marker char with a run at least as long as the opener — so a longer
    // ```` inside a ``` block, or a ~~~ inside a ``` block, does not close it.
    let fenceMarker = null; // '`' or '~' while inside a code block
    let fenceLength = 0; // length of the run that opened the current block
    for (let i = 0; i < lines.length; i++) {
        const line = lines[i];
        // YAML frontmatter is only frontmatter when --- is the very first line.
        if (i === 0 && /^---\s*$/.test(line)) {
            inFrontmatter = true;
            continue;
        }
        if (inFrontmatter) {
            if (/^(---|\.\.\.)\s*$/.test(line))
                inFrontmatter = false;
            continue;
        }
        // Fenced code block: a run of >=3 backticks or tildes, up to 3 spaces
        // of indent.
        const fence = line.match(/^\s{0,3}(`{3,}|~{3,})/);
        if (fence) {
            const run = fence[1];
            const marker = run[0];
            if (fenceMarker === null) {
                fenceMarker = marker;
                fenceLength = run.length;
            }
            else if (marker === fenceMarker && run.length >= fenceLength) {
                fenceMarker = null;
                fenceLength = 0;
            }
            continue;
        }
        if (fenceMarker !== null)
            continue;
        const h = line.match(/^\s{0,3}(#{1,6})\s+(.+?)\s*$/);
        if (h) {
            // Drop a trailing pandoc/quarto attribute block: `## Title {#id .cls}`.
            const text = h[2].replace(/\s*\{[^}]*\}\s*$/, '').trim();
            if (text)
                headings.push({ level: h[1].length, text, line: i });
        }
    }
    return headings;
}
const DEFAULT_SETTINGS = {
    quartoPath: 'quarto',
    enableQmdLinking: true,
    quartoTypst: '',
    openPdfInObsidian: false,
    previewInObsidian: true,
    previewMarkdownFiles: false,
    showYamlFiles: false,
    showOutline: false,
};
class QmdAsMdPlugin extends obsidian.Plugin {
    constructor() {
        super(...arguments);
        this.activePreviewProcesses = new Map();
        // The .qmd file the outline should describe. Tracked separately from the
        // active leaf: clicking inside the outline sidebar makes *it* the active
        // leaf, so the outline must remember the last real .qmd rather than ask
        // "what is active now?" each render.
        this.lastActiveQuartoFile = null;
    }
    async onload() {
        try {
            await this.loadSettings();
            this.registerView(QMD_OUTLINE_VIEW, (leaf) => new QmdOutlineView(leaf, this));
            this.registerView(QMD_YAML_VIEW, (leaf) => new QmdYamlView(leaf));
            if (this.settings.enableQmdLinking) {
                this.registerQmdExtension();
            }
            if (this.settings.showYamlFiles) {
                this.registerYamlExtensions();
            }
            this.addSettingTab(new QmdSettingTab(this.app, this));
            this.addRibbonIcon('eye', 'Toggle Quarto preview', async () => {
                const file = this.getActiveQuartoCommandFile();
                if (file)
                    await this.togglePreview(file);
            });
            this.addCommand({
                id: 'toggle-quarto-preview',
                name: 'Toggle Quarto preview',
                callback: async () => {
                    const file = this.getActiveQuartoCommandFile();
                    if (file)
                        await this.togglePreview(file);
                },
            });
            this.addCommand({
                id: 'toggle-quarto-preview-in-obsidian',
                name: 'Toggle Quarto preview in Obsidian',
                callback: async () => {
                    const file = this.getActiveQuartoCommandFile();
                    if (file)
                        await this.togglePreview(file, 'obsidian');
                },
            });
            this.addCommand({
                id: 'toggle-quarto-preview-external',
                name: 'Toggle Quarto preview in external browser',
                callback: async () => {
                    const file = this.getActiveQuartoCommandFile();
                    if (file)
                        await this.togglePreview(file, 'external');
                },
            });
            this.addRibbonIcon('file-output', 'Render Quarto to PDF', async () => {
                const file = this.getActiveQuartoCommandFile();
                if (file)
                    await this.renderPdf(file);
            });
            this.registerRenderCommand('render-quarto-pdf', 'Render Quarto (use format defined in YAML)');
            this.registerRenderCommand('render-quarto-pdf-typst', 'Render Quarto to PDF (Typst engine)', 'typst');
            this.registerRenderCommand('render-quarto-pdf-latex', 'Render Quarto to PDF (LaTeX engine)', 'pdf');
            this.addCommand({
                id: 'open-quarto-outline',
                name: 'Open Quarto outline',
                callback: () => this.activateOutlineView(),
            });
            // Keep any open outline view in sync with the focused file and its
            // edits. Debounced so a burst of keystrokes re-parses once it settles.
            const refresh = obsidian.debounce(() => {
                this.trackActiveQuartoFile();
                this.refreshOutlineViews();
            }, 250, true);
            this.registerEvent(this.app.workspace.on('active-leaf-change', refresh));
            this.registerEvent(this.app.workspace.on('editor-change', refresh));
            // Opt-in: only auto-open the outline when the user enabled it. The
            // command above always works regardless of this setting.
            if (this.settings.showOutline) {
                this.app.workspace.onLayoutReady(() => this.activateOutlineView());
            }
        }
        catch (error) {
            console.error('Error loading plugin:', error);
            new obsidian.Notice('Failed to load the QMD as md plugin. Check the developer console for details.');
        }
    }
    onunload() {
        this.stopAllPreviews();
    }
    async loadSettings() {
        const loaded = (await this.loadData());
        this.settings = Object.assign({}, DEFAULT_SETTINGS, loaded);
    }
    async saveSettings() {
        await this.saveData(this.settings);
    }
    isQuartoFile(file) {
        return file.extension === 'qmd';
    }
    isMarkdownFile(file) {
        return file.extension === 'md';
    }
    hasQuartoProjectConfigInPath(file) {
        let dir = file.parent?.path ?? '';
        while (true) {
            const configPath = obsidian.normalizePath(dir ? `${dir}/_quarto.yml` : '_quarto.yml');
            if (this.app.vault.getAbstractFileByPath(configPath) instanceof obsidian.TFile) {
                return true;
            }
            if (!dir)
                return false;
            const slash = dir.lastIndexOf('/');
            dir = slash === -1 ? '' : dir.slice(0, slash);
        }
    }
    getActiveQuartoCommandFile() {
        const activeView = this.app.workspace.getActiveViewOfType(obsidian.MarkdownView);
        const file = activeView?.file;
        if (!file) {
            new obsidian.Notice('Quarto commands require an active .qmd file.');
            return null;
        }
        if (this.isQuartoFile(file)) {
            return file;
        }
        if (this.isMarkdownFile(file)) {
            if (!this.settings.previewMarkdownFiles) {
                new obsidian.Notice('Markdown support is off. Enable it in settings to preview or render .md files with Quarto.');
                return null;
            }
            if (!this.hasQuartoProjectConfigInPath(file)) {
                new obsidian.Notice('Markdown Quarto commands require _quarto.yml in this file folder or an ancestor up to the vault root.');
                return null;
            }
            return file;
        }
        if (this.settings.previewMarkdownFiles) {
            new obsidian.Notice('Quarto commands require an active .qmd or .md file.');
        }
        else {
            new obsidian.Notice('Quarto commands require an active .qmd file.');
        }
        return null;
    }
    getVaultFullPath(file) {
        const adapter = this.app.vault.adapter;
        if (adapter instanceof obsidian.FileSystemAdapter) {
            return adapter.getFullPath(file.path);
        }
        new obsidian.Notice('Vault is not on a local filesystem; cannot run Quarto.');
        return null;
    }
    pdfPathFor(file) {
        return file.path.replace(/\.(qmd|md)$/i, '.pdf');
    }
    // Pull the TFile a leaf currently shows, without resorting to
    // `as any`. The built-in PDF view (and most file-backed views)
    // extend FileView, which exposes a typed `file: TFile | null`.
    leafFile(leaf) {
        return leaf.view instanceof obsidian.FileView ? leaf.view.file : null;
    }
    // Open (or reuse) a leaf showing the given vault-relative PDF path in
    // Obsidian's native PDF viewer. Returns the leaf so callers can keep
    // refreshing it on subsequent preview compiles.
    //
    // Leaf-resolution order:
    //   1. Caller's captured ref, if still attached to the workspace.
    //   2. Any open 'pdf' leaf already showing this exact file (user may
    //      have opened it manually, or renderPdf may have opened it).
    //   3. New vertical split.
    async openOrRefreshPdfPreview(vaultPath, existingLeaf) {
        const pdfTFile = await this.waitForVaultFile(vaultPath);
        if (!pdfTFile) {
            new obsidian.Notice(`Quarto preview produced ${vaultPath} but it did not appear in the vault within the timeout.`);
            return null;
        }
        try {
            const reusable = existingLeaf?.parent != null
                ? existingLeaf
                : this.app.workspace
                    .getLeavesOfType('pdf')
                    .find((l) => this.leafFile(l)?.path === pdfTFile.path) ?? null;
            const leaf = reusable ?? this.app.workspace.getLeaf('split', 'vertical');
            // Skip the openFile call when the leaf already shows this file —
            // calling openFile in that case is harmless for the file display
            // but still triggers a reveal/focus shuffle the user does not want.
            // Obsidian's PDF viewer picks up the file rewrite via its own
            // mtime watcher, so live reload still works without our help.
            const currentFile = this.leafFile(leaf);
            if (!currentFile || currentFile.path !== pdfTFile.path) {
                await leaf.openFile(pdfTFile, { active: false });
            }
            await this.app.workspace.revealLeaf(leaf);
            return leaf;
        }
        catch (err) {
            console.error('[qmd-as-md] Failed to open PDF preview in native viewer:', err);
            new obsidian.Notice(`Could not open ${vaultPath} in Obsidian's PDF viewer.`);
            return null;
        }
    }
    async openPreviewUrl(url, mode) {
        console.log('[qmd-as-md][diag] openPreviewUrl called. url:', url, 'mode:', mode);
        new obsidian.Notice(`Preview available at ${url}`);
        if (mode === 'external') {
            // Quarto is launched with --no-browser in every mode; this opens the
            // captured URL once while leaving Quarto's live-reload client in charge
            // after the page is loaded.
            try {
                await electron.shell.openExternal(url);
            }
            catch (err) {
                console.error('[qmd-as-md] Failed to open external preview:', err);
                new obsidian.Notice(`Could not open external browser. Preview URL: ${url}`, 10000);
            }
            return;
        }
        // The "Web viewer" core plugin (Obsidian 1.8+) registers the
        // 'webviewer' view type. If the user has it disabled, setViewState
        // silently fails / leaves an empty leaf, and the user is left
        // wondering why nothing opened. Detect and report instead.
        const internalPlugins = this.app.internalPlugins;
        const webviewerOn = internalPlugins?.getEnabledPluginById?.('webviewer') != null ||
            internalPlugins?.plugins?.webviewer?.enabled === true;
        if (!webviewerOn) {
            new obsidian.Notice('Obsidian core plugin "Web viewer" is disabled — cannot show preview in-app. ' +
                'Enable it in Settings → Core plugins, or use "Toggle Quarto preview in external browser" instead. ' +
                'Falling back to your external browser.', 10000);
            console.warn('[qmd-as-md] webviewer core plugin disabled; preview URL was:', url);
            void electron.shell.openExternal(url);
            return;
        }
        try {
            const leaf = this.app.workspace.getLeaf('tab');
            await leaf.setViewState({
                type: 'webviewer',
                active: true,
                state: { url },
            });
            await this.app.workspace.revealLeaf(leaf);
        }
        catch (err) {
            console.error('[qmd-as-md] Failed to open preview in webviewer:', err);
            new obsidian.Notice("Could not open preview in Obsidian's web viewer. Falling back to external browser.");
            void electron.shell.openExternal(url);
        }
    }
    registerRenderCommand(id, name, toFormat) {
        this.addCommand({
            id,
            name,
            icon: 'file-output',
            callback: async () => {
                const file = this.getActiveQuartoCommandFile();
                if (file)
                    await this.renderPdf(file, toFormat);
            },
        });
    }
    registerQmdExtension() {
        this.registerExtensions(['qmd'], 'markdown');
    }
    registerYamlExtensions() {
        this.registerExtensions(['yml', 'yaml'], QMD_YAML_VIEW);
    }
    // Open the Quarto outline in the right sidebar, reusing an existing
    // outline leaf if one is already open.
    async activateOutlineView() {
        const { workspace } = this.app;
        // Capture the current .qmd before opening the outline — setViewState
        // with active:true makes the outline the active leaf, after which the
        // active markdown view is gone.
        this.trackActiveQuartoFile();
        let leaf = workspace.getLeavesOfType(QMD_OUTLINE_VIEW)[0] ?? null;
        if (!leaf) {
            leaf = workspace.getRightLeaf(false);
            await leaf?.setViewState({ type: QMD_OUTLINE_VIEW, active: true });
        }
        if (leaf)
            await workspace.revealLeaf(leaf);
        this.refreshOutlineViews();
    }
    // Remember the active .qmd file. Called whenever the active leaf changes;
    // a non-.qmd active leaf (including the outline sidebar itself) leaves the
    // last value untouched so the outline keeps describing that file.
    trackActiveQuartoFile() {
        const view = this.app.workspace.getActiveViewOfType(obsidian.MarkdownView);
        if (view?.file && this.isQuartoFile(view.file)) {
            this.lastActiveQuartoFile = view.file;
        }
    }
    // Re-render every open outline view. No-op when none are open.
    refreshOutlineViews() {
        for (const leaf of this.app.workspace.getLeavesOfType(QMD_OUTLINE_VIEW)) {
            if (leaf.view instanceof QmdOutlineView) {
                leaf.view.render();
            }
        }
    }
    // Close any open outline views — used when the user turns the setting off.
    detachOutlineViews() {
        for (const leaf of this.app.workspace.getLeavesOfType(QMD_OUTLINE_VIEW)) {
            leaf.detach();
        }
    }
    defaultPreviewMode() {
        return this.settings.previewInObsidian ? 'obsidian' : 'external';
    }
    async togglePreview(file, mode = this.defaultPreviewMode()) {
        const activePreview = this.activePreviewProcesses.get(file.path);
        if (activePreview?.mode === mode) {
            await this.stopPreview(file);
        }
        else {
            if (activePreview) {
                await this.stopPreview(file);
            }
            await this.startPreview(file, mode);
        }
    }
    async startPreview(file, mode = this.defaultPreviewMode()) {
        const activePreview = this.activePreviewProcesses.get(file.path);
        if (activePreview?.mode === mode) {
            return; // Preview already running for this file in this mode.
        }
        if (activePreview) {
            await this.stopPreview(file);
        }
        try {
            const abstractFile = this.app.vault.getAbstractFileByPath(file.path);
            if (!abstractFile || !(abstractFile instanceof obsidian.TFile)) {
                new obsidian.Notice(`File ${file.path} not found`);
                return;
            }
            const filePath = this.getVaultFullPath(abstractFile);
            if (!filePath)
                return;
            const workingDir = path__namespace.dirname(filePath);
            const envVars = { ...process.env };
            if (this.settings.quartoTypst.trim()) {
                envVars.QUARTO_TYPST = this.settings.quartoTypst.trim();
            }
            // Always suppress Quarto's own browser launch. The plugin opens the
            // captured URL exactly once for the selected target, which avoids
            // duplicate tabs and avoids Quarto-managed browser navigation closing
            // the preview process on subsequent source changes.
            const args = ['preview', filePath, '--no-browser'];
            // detached: `quarto preview` forks a separate long-lived server
            // process. Making the spawned process a process-group leader (POSIX)
            // lets killPreviewProcess signal the whole group — a plain kill() of
            // the wrapper would orphan the server, leaving it serving and
            // recompiling after "stop". No process groups on Windows; the kill
            // there goes through taskkill instead.
            const quartoProcess = child_process.spawn(this.settings.quartoPath, args, {
                cwd: workingDir,
                env: envVars,
                detached: process.platform !== 'win32',
            });
            let previewUrl = null;
            // PDF-preview state. Quarto emits "Output created: foo.pdf" on
            // every recompile (often several times per recompile); the
            // handler dedups so we don't spawn tabs on every save.
            //
            //  leaf:  current PDF tab, if any.
            //  path:  the path that leaf is showing (and the path of an
            //         in-flight open call, recorded synchronously when it
            //         is scheduled). Also gates the preview-URL skip logic
            //         on the "Browse at" branch below — when a PDF
            //         preview is active, we don't open Quarto's PDF.js
            //         wrapper page in the webviewer too.
            //  busy:  a call to openOrRefreshPdfPreview is in flight.
            //
            // Schedule open when any of:
            //   - leaf is detached (user closed the tab manually)
            //   - the new output path differs from the tracked one
            //     (multi-format project, or rename)
            //   - we never opened in this session
            // Skip when busy (bursts of emissions during recompile dedup
            // automatically; the final emission of a burst wins because it
            // arrives after busy clears).
            let pdfPreviewLeaf = null;
            let pdfPreviewPath = null;
            let pdfPreviewBusy = false;
            const schedulePdfPreview = (vaultPath) => {
                if (pdfPreviewBusy)
                    return;
                const leafAttached = pdfPreviewLeaf?.parent != null;
                const pathSame = pdfPreviewPath === vaultPath;
                if (leafAttached && pathSame)
                    return;
                pdfPreviewBusy = true;
                pdfPreviewPath = vaultPath;
                this.openOrRefreshPdfPreview(vaultPath, pdfPreviewLeaf)
                    .then((leaf) => {
                    if (leaf)
                        pdfPreviewLeaf = leaf;
                })
                    .catch((err) => {
                    console.error('[qmd-as-md] PDF preview open failed:', err);
                    pdfPreviewLeaf = null;
                    pdfPreviewPath = null;
                })
                    .finally(() => {
                    pdfPreviewBusy = false;
                });
            };
            // Quarto "ERROR:" lines from this preview run. Used both to surface
            // recompile failures live (preview keeps running, so the close
            // handler never fires) and to explain a startup exit in the Notice.
            const errorLines = [];
            // Dedupe: a single failed recompile emits the same ERROR: block on
            // every save until fixed — only Notice when the error text changes.
            let lastErrorShown = '';
            // Per-line handler: log the line, then look for the two markers
            // we care about ("Output created:" and "Browse at").
            const handlePreviewLine = (line) => {
                logQuartoLine('Quarto Preview', line);
                if (/^ERROR:/.test(line)) {
                    errorLines.push(line);
                    if (line !== lastErrorShown) {
                        lastErrorShown = line;
                        new obsidian.Notice(`Quarto preview error:\n${line}`, 15000);
                    }
                    return;
                }
                // A clean compile clears the dedupe guard so the same error
                // reappearing after a good build is surfaced again.
                if (line.includes('Output created:')) {
                    lastErrorShown = '';
                }
                // Detect "Output created: <path>" — quarto prints this on every
                // compile in preview mode. If the output is a PDF, route to
                // Obsidian's native PDF viewer rather than the webviewer page
                // Quarto serves at /web/viewer.html. Subsequent compiles refresh
                // the same leaf so live reload still works.
                const outMatch = line.match(/Output created:\s*(.+?)\s*$/);
                if (outMatch && /\.pdf$/i.test(outMatch[1].trim()) && mode === 'obsidian') {
                    const outBasename = path__namespace.basename(outMatch[1].trim());
                    const sourceDir = file.parent?.path ?? '';
                    const vaultPath = obsidian.normalizePath(sourceDir ? `${sourceDir}/${outBasename}` : outBasename);
                    schedulePdfPreview(vaultPath);
                    return;
                }
                const matchedPreviewUrl = previewUrlFromLine(line);
                if (!previewUrl && matchedPreviewUrl) {
                    console.log('[qmd-as-md][diag] Browse-at line seen.', 'matched:', matchedPreviewUrl, 'pdfPreviewPath:', pdfPreviewPath, 'mode:', mode);
                    previewUrl = matchedPreviewUrl;
                    // If we already opened a native PDF preview, skip the
                    // webviewer URL — Quarto's PDF.js wrapper would just be
                    // a worse version of the same content.
                    if (pdfPreviewPath) {
                        new obsidian.Notice(`PDF preview opened natively. Server URL: ${previewUrl}`);
                    }
                    else {
                        void this.openPreviewUrl(previewUrl, mode);
                    }
                }
            };
            // One buffered processor per stream — stdout and stderr each
            // need their own partial-line buffer, or interleaved fragments
            // from the two streams would be spliced into synthetic lines.
            const previewStdout = makeLineProcessor(handlePreviewLine);
            const previewStderr = makeLineProcessor(handlePreviewLine);
            quartoProcess.stdout?.on('data', (data) => previewStdout(data.toString()));
            quartoProcess.stderr?.on('data', (data) => previewStderr(data.toString()));
            // child_process.spawn does not throw on a missing binary; it emits
            // an 'error' event later. Without this listener an ENOENT just
            // produced a silent "exit 1" close with no output to console.
            quartoProcess.on('error', (err) => {
                console.error('[qmd-as-md] Failed to spawn quarto for preview:', err);
                new obsidian.Notice(`Failed to spawn '${this.settings.quartoPath}': ${err.message}. ` +
                    'Check the Quarto path setting and that Quarto is on PATH.');
                if (this.activePreviewProcesses.get(file.path)?.process === quartoProcess) {
                    this.activePreviewProcesses.delete(file.path);
                }
            });
            quartoProcess.on('close', (code, signal) => {
                previewStdout.flush(); // release any final partial line
                previewStderr.flush();
                if (code !== null && code !== 0) {
                    const reason = errorLines.length > 0
                        ? errorLines.join('\n')
                        : 'Check the developer console for details.';
                    new obsidian.Notice(`Quarto preview exited with code ${code}.\n${reason}`, 15000);
                }
                else if (code === null && signal && signal !== 'SIGTERM' && signal !== 'SIGKILL') {
                    // SIGTERM/SIGKILL come from our own stopPreview / onunload — silent.
                    new obsidian.Notice(`Quarto preview process was terminated by ${signal}`);
                }
                if (this.activePreviewProcesses.get(file.path)?.process === quartoProcess) {
                    this.activePreviewProcesses.delete(file.path);
                }
            });
            this.activePreviewProcesses.set(file.path, { process: quartoProcess, mode });
            new obsidian.Notice(`Quarto preview started (${mode === 'obsidian' ? 'Obsidian' : 'external browser'})`);
        }
        catch (error) {
            console.error('Failed to start Quarto preview:', error);
            new obsidian.Notice('Failed to start Quarto preview');
        }
    }
    // `quarto preview` forks a long-lived server as a child of the spawned
    // process, so killing only the wrapper leaves that server running. Signal
    // the whole process tree: the process group on POSIX (the child was
    // spawned detached, see startPreview), or taskkill /t on Windows.
    killPreviewProcess(quartoProcess) {
        if (quartoProcess.killed || quartoProcess.pid === undefined)
            return;
        if (process.platform === 'win32') {
            child_process.spawn('taskkill', ['/pid', String(quartoProcess.pid), '/t', '/f']);
            return;
        }
        try {
            // Negative PID targets the whole process group.
            process.kill(-quartoProcess.pid, 'SIGTERM');
        }
        catch {
            // Group already gone, or never became a leader — best-effort direct kill.
            try {
                quartoProcess.kill('SIGTERM');
            }
            catch {
                /* already dead */
            }
        }
    }
    async stopPreview(file) {
        const activePreview = this.activePreviewProcesses.get(file.path);
        if (activePreview) {
            this.killPreviewProcess(activePreview.process);
            this.activePreviewProcesses.delete(file.path);
            new obsidian.Notice('Quarto preview stopped');
        }
    }
    stopAllPreviews() {
        const hadPreviews = this.activePreviewProcesses.size > 0;
        this.activePreviewProcesses.forEach((activePreview, filePath) => {
            this.killPreviewProcess(activePreview.process);
            this.activePreviewProcesses.delete(filePath);
        });
        if (hadPreviews) {
            new obsidian.Notice('All Quarto previews stopped');
        }
    }
    async renderPdf(file, toFormat) {
        try {
            const abstractFile = this.app.vault.getAbstractFileByPath(file.path);
            if (!abstractFile || !(abstractFile instanceof obsidian.TFile)) {
                new obsidian.Notice(`File ${file.path} not found`);
                return;
            }
            // A running `quarto preview` keeps recompiling the same source and
            // writes to overlapping output paths. Stop it before a one-shot
            // render so the two Quarto processes do not fight over the output.
            if (this.activePreviewProcesses.has(file.path)) {
                await this.stopPreview(file);
            }
            const filePath = this.getVaultFullPath(abstractFile);
            if (!filePath)
                return;
            const workingDir = path__namespace.dirname(filePath);
            const envVars = { ...process.env };
            if (this.settings.quartoTypst.trim()) {
                envVars.QUARTO_TYPST = this.settings.quartoTypst.trim();
            }
            const engineLabel = toFormat === 'typst' ? 'Typst' : toFormat === 'pdf' ? 'LaTeX' : 'format defined in YAML';
            new obsidian.Notice(`Rendering Quarto (${engineLabel})...`);
            // Best-guess path used for the pre-render leaf-capture (so we can
            // reuse an existing PDF tab on recompile). The authoritative path
            // comes from quarto's "Output created:" stdout line, parsed below.
            const guessedPdfPath = this.pdfPathFor(file);
            const existingLeaf = this.app.workspace
                .getLeavesOfType('pdf')
                .find((l) => this.leafFile(l)?.path === guessedPdfPath);
            const args = ['render', filePath];
            if (toFormat)
                args.push('--to', toFormat);
            const quartoProcess = child_process.spawn(this.settings.quartoPath, args, {
                cwd: workingDir,
                env: envVars,
            });
            let detectedOutputBasename = null;
            // Quarto prints the human-readable cause on "ERROR:" lines (bad YAML,
            // missing engine, etc.). Keep them so a failing close can surface the
            // real reason in the Notice instead of a bare exit code.
            const errorLines = [];
            // Per-line handler: log the line, then watch for "Output created:".
            const handleRenderLine = (line) => {
                logQuartoLine('Quarto', line);
                const match = line.match(/Output created:\s*(.+?)\s*$/);
                if (match) {
                    detectedOutputBasename = path__namespace.basename(match[1].trim());
                }
                if (/^ERROR:/.test(line)) {
                    errorLines.push(line);
                }
            };
            // One buffered processor per stream — stdout and stderr each
            // need their own partial-line buffer, or interleaved fragments
            // from the two streams would be spliced into synthetic lines.
            const renderStdout = makeLineProcessor(handleRenderLine);
            const renderStderr = makeLineProcessor(handleRenderLine);
            quartoProcess.stdout?.on('data', (data) => renderStdout(data.toString()));
            quartoProcess.stderr?.on('data', (data) => renderStderr(data.toString()));
            // child_process.spawn does not throw on a missing binary; it emits
            // an 'error' event later. Without this listener an ENOENT just
            // produced a silent "exit 1" close with no output to console.
            quartoProcess.on('error', (err) => {
                console.error('[qmd-as-md] Failed to spawn quarto for render:', err);
                new obsidian.Notice(`Failed to spawn '${this.settings.quartoPath}': ${err.message}. ` +
                    'Check the Quarto path setting and that Quarto is on PATH.');
            });
            quartoProcess.on('close', (code, signal) => {
                void (async () => {
                    renderStdout.flush(); // release any final partial line
                    renderStderr.flush();
                    // A clean exit is code 0. Anything else is a failure, except a
                    // termination by SIGTERM/SIGKILL — that means the process was
                    // intentionally cancelled (matching the preview handler, which
                    // suppresses notices for those signals). Stay quiet then.
                    if (code === 0) {
                        // fall through to the success path below
                    }
                    else if (code === null && (signal === 'SIGTERM' || signal === 'SIGKILL')) {
                        console.error(`[qmd-as-md] Quarto render cancelled (${signal}).`);
                        return;
                    }
                    else {
                        const exitLabel = code !== null
                            ? `exit ${code}`
                            : signal
                                ? `terminated by ${signal}`
                                : 'terminated';
                        // The full output was already streamed line-by-line through
                        // console.log / console.error as it arrived — no need to
                        // re-dump it. Surface the actual ERROR: line(s) in the Notice so
                        // the user sees the cause (bad YAML, missing engine, ...) without
                        // having to open the developer console.
                        console.error(`[qmd-as-md] Quarto render failed (${exitLabel}).`);
                        const reason = errorLines.length > 0
                            ? errorLines.join('\n')
                            : 'Check the developer console for details.';
                        new obsidian.Notice(`Quarto render failed (${exitLabel}).\n${reason}`, 15000);
                        return;
                    }
                    const sourceDir = file.parent?.path ?? '';
                    const outputVaultPath = obsidian.normalizePath(detectedOutputBasename
                        ? (sourceDir ? `${sourceDir}/${detectedOutputBasename}` : detectedOutputBasename)
                        : guessedPdfPath);
                    const outputTFile = await this.waitForVaultFile(outputVaultPath);
                    if (!outputTFile) {
                        new obsidian.Notice(`Quarto rendered, but ${outputVaultPath} did not appear in the vault within the timeout. Check Quarto's output-dir or vault sync.`);
                        return;
                    }
                    const isPdf = outputVaultPath.toLowerCase().endsWith('.pdf');
                    if (!this.settings.openPdfInObsidian || !isPdf) {
                        new obsidian.Notice(isPdf
                            ? `PDF rendered: ${outputVaultPath}`
                            : `Rendered: ${outputVaultPath} (Obsidian's built-in viewer only handles PDFs).`);
                        return;
                    }
                    try {
                        const leaf = existingLeaf?.parent != null
                            ? existingLeaf
                            : this.app.workspace.getLeaf('split', 'vertical');
                        await leaf.openFile(outputTFile, { active: false });
                        await this.app.workspace.revealLeaf(leaf);
                        new obsidian.Notice(`Opened ${outputVaultPath}`);
                    }
                    catch (err) {
                        console.error('Failed to open PDF in Obsidian:', err);
                        new obsidian.Notice(`PDF rendered at ${outputVaultPath}, but Obsidian could not open it (no PDF viewer registered?).`);
                    }
                })();
            });
        }
        catch (error) {
            console.error('Failed to render Quarto PDF:', error);
            new obsidian.Notice('Failed to render Quarto PDF');
        }
    }
    async waitForVaultFile(vaultPath, timeoutMs = 5000) {
        const start = Date.now();
        while (Date.now() - start < timeoutMs) {
            const f = this.app.vault.getAbstractFileByPath(vaultPath);
            if (f instanceof obsidian.TFile)
                return f;
            await new Promise((r) => activeWindow.setTimeout(r, 200));
        }
        return null;
    }
}
// Sidebar outline for the active .qmd file. Re-renders on demand (the
// plugin wires it to active-leaf-change and editor-change). Active-file
// only by design — Quarto `{{< include >}}` targets are not resolved.
class QmdOutlineView extends obsidian.ItemView {
    constructor(leaf, plugin) {
        super(leaf);
        this.plugin = plugin;
    }
    getViewType() {
        return QMD_OUTLINE_VIEW;
    }
    getDisplayText() {
        return 'Quarto outline';
    }
    getIcon() {
        return 'list';
    }
    async onOpen() {
        // The outline may already be the active leaf at this point (opened via
        // command/setting), so capture the underlying .qmd before rendering.
        this.plugin.trackActiveQuartoFile();
        this.render();
    }
    // Find the open markdown view for a file, regardless of which leaf is
    // active. .qmd files open as 'markdown' leaves (registerExtensions).
    markdownViewFor(file) {
        for (const leaf of this.app.workspace.getLeavesOfType('markdown')) {
            if (leaf.view instanceof obsidian.MarkdownView && leaf.view.file?.path === file.path) {
                return leaf.view;
            }
        }
        return null;
    }
    render() {
        const container = this.contentEl;
        container.empty();
        container.addClass('qmd-outline');
        const file = this.plugin.lastActiveQuartoFile;
        if (!file) {
            container.createDiv({
                cls: 'qmd-outline-empty',
                text: 'No Quarto (.qmd) file is active.',
            });
            return;
        }
        // Read live content from the open editor rather than the active leaf —
        // clicking inside this sidebar makes it the active leaf.
        const mdView = this.markdownViewFor(file);
        if (!mdView) {
            container.createDiv({
                cls: 'qmd-outline-empty',
                text: `Open ${file.name} to see its outline.`,
            });
            return;
        }
        const headings = parseQmdHeadings(mdView.editor.getValue());
        if (headings.length === 0) {
            container.createDiv({
                cls: 'qmd-outline-empty',
                text: 'No headings in this file.',
            });
            return;
        }
        const list = container.createDiv({ cls: 'qmd-outline-list' });
        for (const heading of headings) {
            const item = list.createDiv({
                cls: 'qmd-outline-item',
                text: heading.text,
                // Keyboard-accessible: focusable, announced as a link, and the
                // keydown handler below makes Enter/Space activate it.
                attr: { tabindex: '0', role: 'link' },
            });
            // Indentation is driven by CSS off this attribute — no inline styles.
            item.dataset.level = String(heading.level);
            const jumpTo = () => {
                // Resolve the editor by file, not by "active leaf" — the click
                // itself just moved focus to this sidebar.
                const view = this.markdownViewFor(file);
                if (!view)
                    return;
                const pos = { line: heading.line, ch: 0 };
                this.app.workspace.setActiveLeaf(view.leaf, { focus: true });
                view.editor.setCursor(pos);
                view.editor.scrollIntoView({ from: pos, to: pos }, true);
                view.editor.focus();
            };
            item.addEventListener('click', jumpTo);
            item.addEventListener('keydown', (evt) => {
                if (evt.key === 'Enter' || evt.key === ' ') {
                    evt.preventDefault();
                    jumpTo();
                }
            });
        }
    }
}
const yamlHighlightField = state.StateField.define({
    create(state) {
        return buildYamlDecorations(state.doc);
    },
    update(decorations, transaction) {
        if (transaction.docChanged) {
            return buildYamlDecorations(transaction.state.doc);
        }
        return decorations.map(transaction.changes);
    },
    provide: (field) => view.EditorView.decorations.from(field),
});
function buildYamlDecorations(doc) {
    const builder = new state.RangeSetBuilder();
    for (let lineNumber = 1; lineNumber <= doc.lines; lineNumber++) {
        const line = doc.line(lineNumber);
        decorateYamlLine(builder, line.from, line.text);
    }
    return builder.finish();
}
function decorateYamlLine(builder, lineStart, line) {
    const indent = line.match(/^\s*/)?.[0] ?? '';
    const content = line.slice(indent.length);
    const contentStart = lineStart + indent.length;
    if (!content)
        return;
    if (content.startsWith('#')) {
        markYamlToken(builder, contentStart, lineStart + line.length, 'qmd-yaml-comment');
        return;
    }
    const markerMatch = content.match(/^(-\s+)(.*)$/);
    if (markerMatch) {
        const markerLength = markerMatch[1].length;
        markYamlToken(builder, contentStart, contentStart + markerLength, 'qmd-yaml-list-marker');
        decorateYamlSegment(builder, contentStart + markerLength, markerMatch[2]);
        return;
    }
    decorateYamlSegment(builder, contentStart, content);
}
function decorateYamlSegment(builder, segmentStart, segment) {
    const docMatch = segment.match(/^(\.{3}|-{3})(\s*(#.*)?)$/);
    if (docMatch) {
        const markerLength = docMatch[1].length;
        markYamlToken(builder, segmentStart, segmentStart + markerLength, 'qmd-yaml-doc-marker');
        decorateYamlValue(builder, segmentStart + markerLength, docMatch[2] ?? '');
        return;
    }
    const colon = findYamlKeyColon(segment);
    if (colon !== -1) {
        markYamlToken(builder, segmentStart, segmentStart + colon, 'qmd-yaml-key');
        markYamlToken(builder, segmentStart + colon, segmentStart + colon + 1, 'qmd-yaml-colon');
        decorateYamlValue(builder, segmentStart + colon + 1, segment.slice(colon + 1));
        return;
    }
    decorateYamlValue(builder, segmentStart, segment);
}
function decorateYamlValue(builder, valueStart, value) {
    const leading = value.match(/^\s*/)?.[0] ?? '';
    const rest = value.slice(leading.length);
    const restStart = valueStart + leading.length;
    if (!rest)
        return;
    const commentIndex = findYamlComment(rest);
    const scalar = commentIndex === -1 ? rest : rest.slice(0, commentIndex);
    decorateYamlScalar(builder, restStart, scalar);
    if (commentIndex !== -1) {
        markYamlToken(builder, restStart + commentIndex, restStart + rest.length, 'qmd-yaml-comment');
    }
}
function decorateYamlScalar(builder, scalarStart, scalar) {
    const trailing = scalar.match(/\s*$/)?.[0] ?? '';
    const token = trailing ? scalar.slice(0, scalar.length - trailing.length) : scalar;
    if (!token)
        return;
    const className = yamlScalarClass(token);
    markYamlToken(builder, scalarStart, scalarStart + token.length, className);
}
function yamlScalarClass(token) {
    if (/^['"].*['"]$/.test(token))
        return 'qmd-yaml-string';
    if (/^[&*][A-Za-z0-9_-]+$/.test(token))
        return 'qmd-yaml-anchor';
    if (/^(true|false|yes|no|on|off|null|~)$/i.test(token))
        return 'qmd-yaml-boolean';
    if (/^[-+]?(?:\d+\.?\d*|\.\d+)(?:e[-+]?\d+)?$/i.test(token))
        return 'qmd-yaml-number';
    if (/^[>|][+-]?$/.test(token))
        return 'qmd-yaml-block';
    if (/^(html|pdf|typst|latex|beamer|revealjs|docx|odt|epub|gfm|jats|dashboard)$/i.test(token)) {
        return 'qmd-yaml-quarto-format';
    }
    return 'qmd-yaml-scalar';
}
function findYamlKeyColon(segment) {
    let singleQuoted = false;
    let doubleQuoted = false;
    for (let i = 0; i < segment.length; i++) {
        const char = segment[i];
        const prev = i > 0 ? segment[i - 1] : '';
        if (char === "'" && !doubleQuoted) {
            singleQuoted = !singleQuoted;
        }
        else if (char === '"' && !singleQuoted && prev !== '\\') {
            doubleQuoted = !doubleQuoted;
        }
        else if (char === ':' && !singleQuoted && !doubleQuoted) {
            const next = segment[i + 1] ?? '';
            const key = segment.slice(0, i).trim();
            if (key && (!next || /\s/.test(next)))
                return i;
        }
    }
    return -1;
}
function findYamlComment(value) {
    let singleQuoted = false;
    let doubleQuoted = false;
    for (let i = 0; i < value.length; i++) {
        const char = value[i];
        const prev = i > 0 ? value[i - 1] : '';
        if (char === "'" && !doubleQuoted) {
            singleQuoted = !singleQuoted;
        }
        else if (char === '"' && !singleQuoted && prev !== '\\') {
            doubleQuoted = !doubleQuoted;
        }
        else if (char === '#' && !singleQuoted && !doubleQuoted && (i === 0 || /\s/.test(prev))) {
            return i;
        }
    }
    return -1;
}
function markYamlToken(builder, from, to, className) {
    if (to <= from)
        return;
    builder.add(from, to, view.Decoration.mark({ class: className }));
}
class QmdYamlView extends obsidian.TextFileView {
    constructor() {
        super(...arguments);
        this.editorView = null;
        this.settingViewData = false;
    }
    getViewType() {
        return QMD_YAML_VIEW;
    }
    getDisplayText() {
        return this.file?.name ?? 'YAML file';
    }
    getIcon() {
        return 'file-code';
    }
    onload() {
        super.onload();
        this.contentEl.empty();
        this.contentEl.addClass('qmd-yaml-view');
        this.editorView = new view.EditorView({
            parent: this.contentEl,
            state: state.EditorState.create({
                doc: this.data ?? '',
                extensions: [
                    state.EditorState.tabSize.of(2),
                    yamlHighlightField,
                    view.EditorView.contentAttributes.of({
                        'aria-label': 'YAML file contents',
                        autocapitalize: 'off',
                        autocomplete: 'off',
                        spellcheck: 'false',
                    }),
                    view.keymap.of([
                        { key: 'Tab', run: commands.indentMore },
                        { key: 'Shift-Tab', run: commands.indentLess },
                    ]),
                    view.EditorView.updateListener.of((update) => {
                        if (!update.docChanged || this.settingViewData)
                            return;
                        this.data = update.state.doc.toString();
                        this.requestSave();
                    }),
                ],
            }),
        });
        this.register(() => {
            this.editorView?.destroy();
            this.editorView = null;
        });
    }
    getViewData() {
        return this.editorView?.state.doc.toString() ?? this.data ?? '';
    }
    setViewData(data) {
        this.data = data;
        const view = this.editorView;
        if (!view)
            return;
        const current = view.state.doc.toString();
        if (current === data)
            return;
        this.settingViewData = true;
        try {
            view.dispatch({
                changes: {
                    from: 0,
                    to: current.length,
                    insert: data,
                },
            });
        }
        finally {
            this.settingViewData = false;
        }
    }
    clear() {
        this.setViewData('');
    }
}
class QmdSettingTab extends obsidian.PluginSettingTab {
    constructor(app, plugin) {
        super(app, plugin);
        this.plugin = plugin;
    }
    display() {
        const { containerEl } = this;
        containerEl.empty();
        new obsidian.Setting(containerEl)
            .setName('Quarto path')
            .setDesc('Path to the Quarto executable (e.g. quarto, /usr/local/bin/quarto)')
            .addText((text) => text
            .setPlaceholder('quarto')
            .setValue(this.plugin.settings.quartoPath)
            .onChange(async (value) => {
            this.plugin.settings.quartoPath = value;
            await this.plugin.saveSettings();
        }));
        new obsidian.Setting(containerEl)
            .setName('Enable editing Quarto files')
            .setDesc('When on, .qmd files open in the Markdown editor. Turn off if another plugin handles .qmd editing.')
            .addToggle((toggle) => toggle
            .setValue(this.plugin.settings.enableQmdLinking)
            .onChange(async (value) => {
            this.plugin.settings.enableQmdLinking = value;
            if (value) {
                this.plugin.registerQmdExtension();
            }
            await this.plugin.saveSettings();
        }));
        new obsidian.Setting(containerEl)
            .setName('QUARTO_TYPST variable')
            .setDesc('Value for the QUARTO_TYPST environment variable (leave empty to unset).')
            .addText((text) => text
            .setPlaceholder('e.g. typst_path')
            .setValue(this.plugin.settings.quartoTypst)
            .onChange(async (value) => {
            this.plugin.settings.quartoTypst = value;
            await this.plugin.saveSettings();
        }));
        new obsidian.Setting(containerEl)
            .setName('Open compiled PDF in Obsidian')
            .setDesc("When rendering to PDF, open the resulting file inside Obsidian using the built-in PDF viewer. The .qmd source must live in the vault so the rendered PDF is accessible.")
            .addToggle((toggle) => toggle
            .setValue(this.plugin.settings.openPdfInObsidian)
            .onChange(async (value) => {
            this.plugin.settings.openPdfInObsidian = value;
            await this.plugin.saveSettings();
        }));
        new obsidian.Setting(containerEl)
            .setName('Open Quarto preview in Obsidian')
            .setDesc('Default target for the generic Toggle Quarto preview command and ribbon icon. ' +
            "When on: PDF previews (format: typst / pdf) open in Obsidian's native PDF viewer; " +
            "non-PDF previews (HTML, etc.) open in Obsidian 1.8's built-in web viewer. " +
            'When off, the plugin opens Quarto\'s preview URL in your default external browser. ' +
            'Use the explicit preview commands to choose a target without changing this setting.')
            .addToggle((toggle) => toggle
            .setValue(this.plugin.settings.previewInObsidian)
            .onChange(async (value) => {
            this.plugin.settings.previewInObsidian = value;
            await this.plugin.saveSettings();
        }));
        new obsidian.Setting(containerEl)
            .setName('Preview and render Markdown files with Quarto')
            .setDesc('When on, Quarto preview and render commands also accept .md files that have _quarto.yml in their folder or an ancestor up to the vault root. Leave off to restrict commands to .qmd files.')
            .addToggle((toggle) => toggle
            .setValue(this.plugin.settings.previewMarkdownFiles)
            .onChange(async (value) => {
            this.plugin.settings.previewMarkdownFiles = value;
            await this.plugin.saveSettings();
        }));
        new obsidian.Setting(containerEl)
            .setName('Show YAML files')
            .setDesc('When on, .yml and .yaml files appear in Obsidian using a CodeMirror editor with Quarto-oriented YAML highlighting. Turn off and reload the plugin to hide them again.')
            .addToggle((toggle) => toggle
            .setValue(this.plugin.settings.showYamlFiles)
            .onChange(async (value) => {
            this.plugin.settings.showYamlFiles = value;
            if (value) {
                this.plugin.registerYamlExtensions();
            }
            else {
                new obsidian.Notice('Reload the plugin to hide YAML files again.');
            }
            await this.plugin.saveSettings();
        }));
        new obsidian.Setting(containerEl)
            .setName('Show Quarto outline')
            .setDesc("Add a sidebar outline of the active .qmd file's headings (Obsidian's " +
            'core Outline panel cannot read .qmd files). Active file only — ' +
            'headings from included files are not listed. The "Open Quarto ' +
            'outline" command works regardless of this toggle.')
            .addToggle((toggle) => toggle
            .setValue(this.plugin.settings.showOutline)
            .onChange(async (value) => {
            this.plugin.settings.showOutline = value;
            await this.plugin.saveSettings();
            if (value) {
                await this.plugin.activateOutlineView();
            }
            else {
                this.plugin.detachOutlineViews();
            }
        }));
    }
}

module.exports = QmdAsMdPlugin;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibWFpbi5qcyIsInNvdXJjZXMiOlsic3JjL21haW4udHMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtcbiAgUGx1Z2luLFxuICBOb3RpY2UsXG4gIFRGaWxlLFxuICBGaWxlVmlldyxcbiAgSXRlbVZpZXcsXG4gIE1hcmtkb3duVmlldyxcbiAgVGV4dEZpbGVWaWV3LFxuICBQbHVnaW5TZXR0aW5nVGFiLFxuICBBcHAsXG4gIFNldHRpbmcsXG4gIEZpbGVTeXN0ZW1BZGFwdGVyLFxuICBXb3Jrc3BhY2VMZWFmLFxuICBkZWJvdW5jZSxcbiAgbm9ybWFsaXplUGF0aCxcbn0gZnJvbSAnb2JzaWRpYW4nO1xuaW1wb3J0IHsgc3Bhd24sIENoaWxkUHJvY2VzcyB9IGZyb20gJ2NoaWxkX3Byb2Nlc3MnO1xuaW1wb3J0ICogYXMgcGF0aCBmcm9tICdwYXRoJztcbmltcG9ydCB7IHNoZWxsIH0gZnJvbSAnZWxlY3Ryb24nO1xuaW1wb3J0IHsgRWRpdG9yU3RhdGUsIFJhbmdlU2V0QnVpbGRlciwgU3RhdGVGaWVsZCwgVGV4dCB9IGZyb20gJ0Bjb2RlbWlycm9yL3N0YXRlJztcbmltcG9ydCB7IERlY29yYXRpb24sIERlY29yYXRpb25TZXQsIEVkaXRvclZpZXcsIGtleW1hcCB9IGZyb20gJ0Bjb2RlbWlycm9yL3ZpZXcnO1xuaW1wb3J0IHsgaW5kZW50TW9yZSwgaW5kZW50TGVzcyB9IGZyb20gJ0Bjb2RlbWlycm9yL2NvbW1hbmRzJztcblxuLy8gLS0tIFF1YXJ0byBvdXRwdXQgcGx1bWJpbmcgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbi8vXG4vLyBOb2RlJ3Mgc3Bhd24tc3RyZWFtIGNodW5rcyBkb24ndCBhbGlnbiB3aXRoIGxpbmUgYm91bmRhcmllcyDigJQgYSBzaW5nbGVcbi8vIGRhdGEgZXZlbnQgY2FuIGNvbnRhaW4gYSBwYXJ0aWFsIGxpbmUsIGFuZCBhIGxvZ2ljYWwgbGluZSBjYW4gYmUgc3BsaXRcbi8vIGFjcm9zcyB0d28gZXZlbnRzLiBCdWlsZCBhIHBlci1zdHJlYW0gcHJvY2Vzc29yIHRoYXQgYnVmZmVycyB0aGVcbi8vIHRyYWlsaW5nIHBhcnRpYWwgbGluZSBhbmQgb25seSBlbWl0cyB3aG9sZSBsaW5lcy4gQ2FsbCAuZmx1c2goKSBvbiB0aGVcbi8vIGNsb3NlIGhhbmRsZXIgdG8gcmVsZWFzZSBhbnkgZmluYWwgcGFydGlhbCBsaW5lLlxuLy9cbi8vIGxvZ1F1YXJ0b0xpbmUgcm91dGVzIGEgc2luZ2xlIGxpbmUgdG8gY29uc29sZSBieSBzZXZlcml0eSBwcmVmaXg6XG4vLyBcIkVSUk9SOlwiIC0+IGNvbnNvbGUuZXJyb3IsIFwiV0FSTklORzpcIi9cIldBUk46XCIgLT4gY29uc29sZS53YXJuLFxuLy8gZXZlcnl0aGluZyBlbHNlIC0+IGNvbnNvbGUubG9nLiBDZW50cmFsaXNlZCBzbyBib3RoIHRoZSBwcmV2aWV3IGFuZFxuLy8gcmVuZGVyIHBhdGhzIHN0YXkgaW4gc3luYyBhbmQgbmV3IHByZWZpeGVzIG9ubHkgbmVlZCBoYW5kbGluZyBoZXJlLlxuXG5mdW5jdGlvbiBsb2dRdWFydG9MaW5lKHByZWZpeDogc3RyaW5nLCBsaW5lOiBzdHJpbmcpOiB2b2lkIHtcbiAgaWYgKC9eRVJST1I6Ly50ZXN0KGxpbmUpKSB7XG4gICAgY29uc29sZS5lcnJvcihgJHtwcmVmaXh9OiAke2xpbmV9YCk7XG4gIH0gZWxzZSBpZiAoL15XQVJOKElORyk/Oi8udGVzdChsaW5lKSkge1xuICAgIGNvbnNvbGUud2FybihgJHtwcmVmaXh9OiAke2xpbmV9YCk7XG4gIH0gZWxzZSB7XG4gICAgY29uc29sZS5sb2coYCR7cHJlZml4fTogJHtsaW5lfWApO1xuICB9XG59XG5cbmludGVyZmFjZSBMaW5lUHJvY2Vzc29yIHtcbiAgKGNodW5rOiBzdHJpbmcpOiB2b2lkO1xuICBmbHVzaCgpOiB2b2lkO1xufVxuXG5mdW5jdGlvbiBtYWtlTGluZVByb2Nlc3NvcihoYW5kbGU6IChsaW5lOiBzdHJpbmcpID0+IHZvaWQpOiBMaW5lUHJvY2Vzc29yIHtcbiAgbGV0IGJ1ZmZlciA9ICcnO1xuICBjb25zdCBwcm9jID0gKChjaHVuazogc3RyaW5nKSA9PiB7XG4gICAgYnVmZmVyICs9IGNodW5rO1xuICAgIGNvbnN0IGxpbmVzID0gYnVmZmVyLnNwbGl0KC9cXHI/XFxuLyk7XG4gICAgLy8gTGFzdCBlbGVtZW50IGlzIHRoZSB0cmFpbGluZyBmcmFnbWVudCBhZnRlciB0aGUgZmluYWwgbmV3bGluZVxuICAgIC8vIChvciB0aGUgd2hvbGUgY2h1bmsgaWYgdGhlcmUgd2FzIG5vIG5ld2xpbmUgYXQgYWxsKS4gS2VlcCBpdFxuICAgIC8vIGZvciB0aGUgbmV4dCBjaHVuay5cbiAgICBidWZmZXIgPSBsaW5lcy5wb3AoKSA/PyAnJztcbiAgICBmb3IgKGNvbnN0IGxpbmUgb2YgbGluZXMpIHtcbiAgICAgIGlmIChsaW5lKSBoYW5kbGUobGluZSk7XG4gICAgfVxuICB9KSBhcyBMaW5lUHJvY2Vzc29yO1xuICBwcm9jLmZsdXNoID0gKCkgPT4ge1xuICAgIGlmIChidWZmZXIpIHtcbiAgICAgIGhhbmRsZShidWZmZXIpO1xuICAgICAgYnVmZmVyID0gJyc7XG4gICAgfVxuICB9O1xuICByZXR1cm4gcHJvYztcbn1cblxuZnVuY3Rpb24gc3RyaXBBbnNpQ29kZXModGV4dDogc3RyaW5nKTogc3RyaW5nIHtcbiAgcmV0dXJuIHRleHQucmVwbGFjZSgvXFx4MUJcXFtbMC0/XSpbIC0vXSpbQC1+XS9nLCAnJyk7XG59XG5cbmZ1bmN0aW9uIHByZXZpZXdVcmxGcm9tTGluZShsaW5lOiBzdHJpbmcpOiBzdHJpbmcgfCBudWxsIHtcbiAgY29uc3QgbWF0Y2ggPSBzdHJpcEFuc2lDb2RlcyhsaW5lKS5tYXRjaCgvQnJvd3NlIGF0XFxzKyhodHRwcz86XFwvXFwvXFxTKykvKTtcbiAgcmV0dXJuIG1hdGNoPy5bMV0gPz8gbnVsbDtcbn1cblxuLy8gLS0tIFF1YXJ0byBvdXRsaW5lIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbi8vXG4vLyBPYnNpZGlhbidzIGNvcmUgT3V0bGluZSBwYW5lbCByZWFkcyBoZWFkaW5ncyBmcm9tIG1ldGFkYXRhQ2FjaGUsIHdoaWNoXG4vLyBvbmx5IHBhcnNlcyAubWQgZmlsZXMg4oCUIGEgLnFtZCBvcGVuZWQgdmlhIHJlZ2lzdGVyRXh0ZW5zaW9ucyBzdGlsbCBnZXRzXG4vLyBubyBoZWFkaW5nIGNhY2hlLCBzbyB0aGUgcGFuZWwgc3RheXMgYmxhbmsgKGlzc3VlICMzKS4gcGFyc2VRbWRIZWFkaW5nc1xuLy8gc2NhbnMgdGhlIGZpbGUgdGV4dCBkaXJlY3RseTogQVRYIGhlYWRpbmdzIChgIyAuLi5gLCB1cCB0byAzIHNwYWNlcyBvZlxuLy8gaW5kZW50IHBlciBDb21tb25NYXJrKSBvbmx5IOKAlCBzZXRleHQgaGVhZGluZ3MgKHVuZGVybGluZWQgd2l0aCA9PT0gLyAtLS0pXG4vLyBhcmUgaW50ZW50aW9uYWxseSBub3Qgc3VwcG9ydGVkLCB0aGV5IGFyZSB2YW5pc2hpbmdseSByYXJlIGluIFF1YXJ0byBhbmRcbi8vIHRoZSAtLS0gZm9ybSBjb2xsaWRlcyB3aXRoIFlBTUwvZnJvbnRtYXR0ZXIgc3ludGF4LiBUaGUgc2NhbiBza2lwcyB0aGVcbi8vIFlBTUwgZnJvbnRtYXR0ZXIgYmxvY2sgYW5kIGZlbmNlZCBjb2RlIGJsb2NrcyAoYGBgIC8gfn5+KSBzbyBhIGAjYCBsaW5lXG4vLyBpbnNpZGUgYW4gUi9QeXRob24gY2VsbCBpcyBub3QgbWlzdGFrZW4gZm9yIGEgaGVhZGluZy5cblxuY29uc3QgUU1EX09VVExJTkVfVklFVyA9ICdxbWQtb3V0bGluZS12aWV3JztcbmNvbnN0IFFNRF9ZQU1MX1ZJRVcgPSAncW1kLXlhbWwtdmlldyc7XG5cbmludGVyZmFjZSBRbWRIZWFkaW5nIHtcbiAgbGV2ZWw6IG51bWJlcjtcbiAgdGV4dDogc3RyaW5nO1xuICBsaW5lOiBudW1iZXI7IC8vIDAtYmFzZWQgbGluZSBpbmRleCBpbiB0aGUgc291cmNlXG59XG5cbmZ1bmN0aW9uIHBhcnNlUW1kSGVhZGluZ3MoY29udGVudDogc3RyaW5nKTogUW1kSGVhZGluZ1tdIHtcbiAgY29uc3QgbGluZXMgPSBjb250ZW50LnNwbGl0KC9cXHI/XFxuLyk7XG4gIGNvbnN0IGhlYWRpbmdzOiBRbWRIZWFkaW5nW10gPSBbXTtcbiAgbGV0IGluRnJvbnRtYXR0ZXIgPSBmYWxzZTtcbiAgLy8gT3BlbiBjb2RlLWZlbmNlIHN0YXRlLiBQZXIgQ29tbW9uTWFyaywgYSBmZW5jZSBjbG9zZXMgb25seSBvbiB0aGUgc2FtZVxuICAvLyBtYXJrZXIgY2hhciB3aXRoIGEgcnVuIGF0IGxlYXN0IGFzIGxvbmcgYXMgdGhlIG9wZW5lciDigJQgc28gYSBsb25nZXJcbiAgLy8gYGBgYCBpbnNpZGUgYSBgYGAgYmxvY2ssIG9yIGEgfn5+IGluc2lkZSBhIGBgYCBibG9jaywgZG9lcyBub3QgY2xvc2UgaXQuXG4gIGxldCBmZW5jZU1hcmtlcjogc3RyaW5nIHwgbnVsbCA9IG51bGw7IC8vICdgJyBvciAnficgd2hpbGUgaW5zaWRlIGEgY29kZSBibG9ja1xuICBsZXQgZmVuY2VMZW5ndGggPSAwOyAvLyBsZW5ndGggb2YgdGhlIHJ1biB0aGF0IG9wZW5lZCB0aGUgY3VycmVudCBibG9ja1xuXG4gIGZvciAobGV0IGkgPSAwOyBpIDwgbGluZXMubGVuZ3RoOyBpKyspIHtcbiAgICBjb25zdCBsaW5lID0gbGluZXNbaV07XG5cbiAgICAvLyBZQU1MIGZyb250bWF0dGVyIGlzIG9ubHkgZnJvbnRtYXR0ZXIgd2hlbiAtLS0gaXMgdGhlIHZlcnkgZmlyc3QgbGluZS5cbiAgICBpZiAoaSA9PT0gMCAmJiAvXi0tLVxccyokLy50ZXN0KGxpbmUpKSB7XG4gICAgICBpbkZyb250bWF0dGVyID0gdHJ1ZTtcbiAgICAgIGNvbnRpbnVlO1xuICAgIH1cbiAgICBpZiAoaW5Gcm9udG1hdHRlcikge1xuICAgICAgaWYgKC9eKC0tLXxcXC5cXC5cXC4pXFxzKiQvLnRlc3QobGluZSkpIGluRnJvbnRtYXR0ZXIgPSBmYWxzZTtcbiAgICAgIGNvbnRpbnVlO1xuICAgIH1cblxuICAgIC8vIEZlbmNlZCBjb2RlIGJsb2NrOiBhIHJ1biBvZiA+PTMgYmFja3RpY2tzIG9yIHRpbGRlcywgdXAgdG8gMyBzcGFjZXNcbiAgICAvLyBvZiBpbmRlbnQuXG4gICAgY29uc3QgZmVuY2UgPSBsaW5lLm1hdGNoKC9eXFxzezAsM30oYHszLH18fnszLH0pLyk7XG4gICAgaWYgKGZlbmNlKSB7XG4gICAgICBjb25zdCBydW4gPSBmZW5jZVsxXTtcbiAgICAgIGNvbnN0IG1hcmtlciA9IHJ1blswXTtcbiAgICAgIGlmIChmZW5jZU1hcmtlciA9PT0gbnVsbCkge1xuICAgICAgICBmZW5jZU1hcmtlciA9IG1hcmtlcjtcbiAgICAgICAgZmVuY2VMZW5ndGggPSBydW4ubGVuZ3RoO1xuICAgICAgfSBlbHNlIGlmIChtYXJrZXIgPT09IGZlbmNlTWFya2VyICYmIHJ1bi5sZW5ndGggPj0gZmVuY2VMZW5ndGgpIHtcbiAgICAgICAgZmVuY2VNYXJrZXIgPSBudWxsO1xuICAgICAgICBmZW5jZUxlbmd0aCA9IDA7XG4gICAgICB9XG4gICAgICBjb250aW51ZTtcbiAgICB9XG4gICAgaWYgKGZlbmNlTWFya2VyICE9PSBudWxsKSBjb250aW51ZTtcblxuICAgIGNvbnN0IGggPSBsaW5lLm1hdGNoKC9eXFxzezAsM30oI3sxLDZ9KVxccysoLis/KVxccyokLyk7XG4gICAgaWYgKGgpIHtcbiAgICAgIC8vIERyb3AgYSB0cmFpbGluZyBwYW5kb2MvcXVhcnRvIGF0dHJpYnV0ZSBibG9jazogYCMjIFRpdGxlIHsjaWQgLmNsc31gLlxuICAgICAgY29uc3QgdGV4dCA9IGhbMl0ucmVwbGFjZSgvXFxzKlxce1tefV0qXFx9XFxzKiQvLCAnJykudHJpbSgpO1xuICAgICAgaWYgKHRleHQpIGhlYWRpbmdzLnB1c2goeyBsZXZlbDogaFsxXS5sZW5ndGgsIHRleHQsIGxpbmU6IGkgfSk7XG4gICAgfVxuICB9XG4gIHJldHVybiBoZWFkaW5ncztcbn1cblxuaW50ZXJmYWNlIFFtZFBsdWdpblNldHRpbmdzIHtcbiAgcXVhcnRvUGF0aDogc3RyaW5nO1xuICBlbmFibGVRbWRMaW5raW5nOiBib29sZWFuO1xuICBxdWFydG9UeXBzdDogc3RyaW5nO1xuICBvcGVuUGRmSW5PYnNpZGlhbjogYm9vbGVhbjtcbiAgcHJldmlld0luT2JzaWRpYW46IGJvb2xlYW47XG4gIHByZXZpZXdNYXJrZG93bkZpbGVzOiBib29sZWFuO1xuICBzaG93WWFtbEZpbGVzOiBib29sZWFuO1xuICBzaG93T3V0bGluZTogYm9vbGVhbjtcbn1cblxudHlwZSBQcmV2aWV3TW9kZSA9ICdvYnNpZGlhbicgfCAnZXh0ZXJuYWwnO1xuXG5pbnRlcmZhY2UgQWN0aXZlUHJldmlldyB7XG4gIHByb2Nlc3M6IENoaWxkUHJvY2VzcztcbiAgbW9kZTogUHJldmlld01vZGU7XG59XG5cbmNvbnN0IERFRkFVTFRfU0VUVElOR1M6IFFtZFBsdWdpblNldHRpbmdzID0ge1xuICBxdWFydG9QYXRoOiAncXVhcnRvJyxcbiAgZW5hYmxlUW1kTGlua2luZzogdHJ1ZSxcbiAgcXVhcnRvVHlwc3Q6ICcnLFxuICBvcGVuUGRmSW5PYnNpZGlhbjogZmFsc2UsXG4gIHByZXZpZXdJbk9ic2lkaWFuOiB0cnVlLFxuICBwcmV2aWV3TWFya2Rvd25GaWxlczogZmFsc2UsXG4gIHNob3dZYW1sRmlsZXM6IGZhbHNlLFxuICBzaG93T3V0bGluZTogZmFsc2UsXG59O1xuXG5leHBvcnQgZGVmYXVsdCBjbGFzcyBRbWRBc01kUGx1Z2luIGV4dGVuZHMgUGx1Z2luIHtcbiAgc2V0dGluZ3M6IFFtZFBsdWdpblNldHRpbmdzO1xuICBhY3RpdmVQcmV2aWV3UHJvY2Vzc2VzOiBNYXA8c3RyaW5nLCBBY3RpdmVQcmV2aWV3PiA9IG5ldyBNYXAoKTtcbiAgLy8gVGhlIC5xbWQgZmlsZSB0aGUgb3V0bGluZSBzaG91bGQgZGVzY3JpYmUuIFRyYWNrZWQgc2VwYXJhdGVseSBmcm9tIHRoZVxuICAvLyBhY3RpdmUgbGVhZjogY2xpY2tpbmcgaW5zaWRlIHRoZSBvdXRsaW5lIHNpZGViYXIgbWFrZXMgKml0KiB0aGUgYWN0aXZlXG4gIC8vIGxlYWYsIHNvIHRoZSBvdXRsaW5lIG11c3QgcmVtZW1iZXIgdGhlIGxhc3QgcmVhbCAucW1kIHJhdGhlciB0aGFuIGFza1xuICAvLyBcIndoYXQgaXMgYWN0aXZlIG5vdz9cIiBlYWNoIHJlbmRlci5cbiAgbGFzdEFjdGl2ZVF1YXJ0b0ZpbGU6IFRGaWxlIHwgbnVsbCA9IG51bGw7XG5cbiAgYXN5bmMgb25sb2FkKCkge1xuICAgIHRyeSB7XG4gICAgICBhd2FpdCB0aGlzLmxvYWRTZXR0aW5ncygpO1xuXG4gICAgICB0aGlzLnJlZ2lzdGVyVmlldyhRTURfT1VUTElORV9WSUVXLCAobGVhZikgPT4gbmV3IFFtZE91dGxpbmVWaWV3KGxlYWYsIHRoaXMpKTtcbiAgICAgIHRoaXMucmVnaXN0ZXJWaWV3KFFNRF9ZQU1MX1ZJRVcsIChsZWFmKSA9PiBuZXcgUW1kWWFtbFZpZXcobGVhZikpO1xuXG4gICAgICBpZiAodGhpcy5zZXR0aW5ncy5lbmFibGVRbWRMaW5raW5nKSB7XG4gICAgICAgIHRoaXMucmVnaXN0ZXJRbWRFeHRlbnNpb24oKTtcbiAgICAgIH1cbiAgICAgIGlmICh0aGlzLnNldHRpbmdzLnNob3dZYW1sRmlsZXMpIHtcbiAgICAgICAgdGhpcy5yZWdpc3RlcllhbWxFeHRlbnNpb25zKCk7XG4gICAgICB9XG5cbiAgICAgIHRoaXMuYWRkU2V0dGluZ1RhYihuZXcgUW1kU2V0dGluZ1RhYih0aGlzLmFwcCwgdGhpcykpO1xuXG4gICAgICB0aGlzLmFkZFJpYmJvbkljb24oJ2V5ZScsICdUb2dnbGUgUXVhcnRvIHByZXZpZXcnLCBhc3luYyAoKSA9PiB7XG4gICAgICAgIGNvbnN0IGZpbGUgPSB0aGlzLmdldEFjdGl2ZVF1YXJ0b0NvbW1hbmRGaWxlKCk7XG4gICAgICAgIGlmIChmaWxlKSBhd2FpdCB0aGlzLnRvZ2dsZVByZXZpZXcoZmlsZSk7XG4gICAgICB9KTtcblxuICAgICAgdGhpcy5hZGRDb21tYW5kKHtcbiAgICAgICAgaWQ6ICd0b2dnbGUtcXVhcnRvLXByZXZpZXcnLFxuICAgICAgICBuYW1lOiAnVG9nZ2xlIFF1YXJ0byBwcmV2aWV3JyxcbiAgICAgICAgY2FsbGJhY2s6IGFzeW5jICgpID0+IHtcbiAgICAgICAgICBjb25zdCBmaWxlID0gdGhpcy5nZXRBY3RpdmVRdWFydG9Db21tYW5kRmlsZSgpO1xuICAgICAgICAgIGlmIChmaWxlKSBhd2FpdCB0aGlzLnRvZ2dsZVByZXZpZXcoZmlsZSk7XG4gICAgICAgIH0sXG4gICAgICB9KTtcblxuICAgICAgdGhpcy5hZGRDb21tYW5kKHtcbiAgICAgICAgaWQ6ICd0b2dnbGUtcXVhcnRvLXByZXZpZXctaW4tb2JzaWRpYW4nLFxuICAgICAgICBuYW1lOiAnVG9nZ2xlIFF1YXJ0byBwcmV2aWV3IGluIE9ic2lkaWFuJyxcbiAgICAgICAgY2FsbGJhY2s6IGFzeW5jICgpID0+IHtcbiAgICAgICAgICBjb25zdCBmaWxlID0gdGhpcy5nZXRBY3RpdmVRdWFydG9Db21tYW5kRmlsZSgpO1xuICAgICAgICAgIGlmIChmaWxlKSBhd2FpdCB0aGlzLnRvZ2dsZVByZXZpZXcoZmlsZSwgJ29ic2lkaWFuJyk7XG4gICAgICAgIH0sXG4gICAgICB9KTtcblxuICAgICAgdGhpcy5hZGRDb21tYW5kKHtcbiAgICAgICAgaWQ6ICd0b2dnbGUtcXVhcnRvLXByZXZpZXctZXh0ZXJuYWwnLFxuICAgICAgICBuYW1lOiAnVG9nZ2xlIFF1YXJ0byBwcmV2aWV3IGluIGV4dGVybmFsIGJyb3dzZXInLFxuICAgICAgICBjYWxsYmFjazogYXN5bmMgKCkgPT4ge1xuICAgICAgICAgIGNvbnN0IGZpbGUgPSB0aGlzLmdldEFjdGl2ZVF1YXJ0b0NvbW1hbmRGaWxlKCk7XG4gICAgICAgICAgaWYgKGZpbGUpIGF3YWl0IHRoaXMudG9nZ2xlUHJldmlldyhmaWxlLCAnZXh0ZXJuYWwnKTtcbiAgICAgICAgfSxcbiAgICAgIH0pO1xuXG4gICAgICB0aGlzLmFkZFJpYmJvbkljb24oJ2ZpbGUtb3V0cHV0JywgJ1JlbmRlciBRdWFydG8gdG8gUERGJywgYXN5bmMgKCkgPT4ge1xuICAgICAgICBjb25zdCBmaWxlID0gdGhpcy5nZXRBY3RpdmVRdWFydG9Db21tYW5kRmlsZSgpO1xuICAgICAgICBpZiAoZmlsZSkgYXdhaXQgdGhpcy5yZW5kZXJQZGYoZmlsZSk7XG4gICAgICB9KTtcblxuICAgICAgdGhpcy5yZWdpc3RlclJlbmRlckNvbW1hbmQoJ3JlbmRlci1xdWFydG8tcGRmJywgJ1JlbmRlciBRdWFydG8gKHVzZSBmb3JtYXQgZGVmaW5lZCBpbiBZQU1MKScpO1xuICAgICAgdGhpcy5yZWdpc3RlclJlbmRlckNvbW1hbmQoJ3JlbmRlci1xdWFydG8tcGRmLXR5cHN0JywgJ1JlbmRlciBRdWFydG8gdG8gUERGIChUeXBzdCBlbmdpbmUpJywgJ3R5cHN0Jyk7XG4gICAgICB0aGlzLnJlZ2lzdGVyUmVuZGVyQ29tbWFuZCgncmVuZGVyLXF1YXJ0by1wZGYtbGF0ZXgnLCAnUmVuZGVyIFF1YXJ0byB0byBQREYgKExhVGVYIGVuZ2luZSknLCAncGRmJyk7XG5cbiAgICAgIHRoaXMuYWRkQ29tbWFuZCh7XG4gICAgICAgIGlkOiAnb3Blbi1xdWFydG8tb3V0bGluZScsXG4gICAgICAgIG5hbWU6ICdPcGVuIFF1YXJ0byBvdXRsaW5lJyxcbiAgICAgICAgY2FsbGJhY2s6ICgpID0+IHRoaXMuYWN0aXZhdGVPdXRsaW5lVmlldygpLFxuICAgICAgfSk7XG5cbiAgICAgIC8vIEtlZXAgYW55IG9wZW4gb3V0bGluZSB2aWV3IGluIHN5bmMgd2l0aCB0aGUgZm9jdXNlZCBmaWxlIGFuZCBpdHNcbiAgICAgIC8vIGVkaXRzLiBEZWJvdW5jZWQgc28gYSBidXJzdCBvZiBrZXlzdHJva2VzIHJlLXBhcnNlcyBvbmNlIGl0IHNldHRsZXMuXG4gICAgICBjb25zdCByZWZyZXNoID0gZGVib3VuY2UoKCkgPT4ge1xuICAgICAgICB0aGlzLnRyYWNrQWN0aXZlUXVhcnRvRmlsZSgpO1xuICAgICAgICB0aGlzLnJlZnJlc2hPdXRsaW5lVmlld3MoKTtcbiAgICAgIH0sIDI1MCwgdHJ1ZSk7XG4gICAgICB0aGlzLnJlZ2lzdGVyRXZlbnQodGhpcy5hcHAud29ya3NwYWNlLm9uKCdhY3RpdmUtbGVhZi1jaGFuZ2UnLCByZWZyZXNoKSk7XG4gICAgICB0aGlzLnJlZ2lzdGVyRXZlbnQodGhpcy5hcHAud29ya3NwYWNlLm9uKCdlZGl0b3ItY2hhbmdlJywgcmVmcmVzaCkpO1xuXG4gICAgICAvLyBPcHQtaW46IG9ubHkgYXV0by1vcGVuIHRoZSBvdXRsaW5lIHdoZW4gdGhlIHVzZXIgZW5hYmxlZCBpdC4gVGhlXG4gICAgICAvLyBjb21tYW5kIGFib3ZlIGFsd2F5cyB3b3JrcyByZWdhcmRsZXNzIG9mIHRoaXMgc2V0dGluZy5cbiAgICAgIGlmICh0aGlzLnNldHRpbmdzLnNob3dPdXRsaW5lKSB7XG4gICAgICAgIHRoaXMuYXBwLndvcmtzcGFjZS5vbkxheW91dFJlYWR5KCgpID0+IHRoaXMuYWN0aXZhdGVPdXRsaW5lVmlldygpKTtcbiAgICAgIH1cbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgY29uc29sZS5lcnJvcignRXJyb3IgbG9hZGluZyBwbHVnaW46JywgZXJyb3IpO1xuICAgICAgbmV3IE5vdGljZSgnRmFpbGVkIHRvIGxvYWQgdGhlIFFNRCBhcyBtZCBwbHVnaW4uIENoZWNrIHRoZSBkZXZlbG9wZXIgY29uc29sZSBmb3IgZGV0YWlscy4nKTtcbiAgICB9XG4gIH1cblxuICBvbnVubG9hZCgpIHtcbiAgICB0aGlzLnN0b3BBbGxQcmV2aWV3cygpO1xuICB9XG5cbiAgYXN5bmMgbG9hZFNldHRpbmdzKCkge1xuICAgIGNvbnN0IGxvYWRlZCA9IChhd2FpdCB0aGlzLmxvYWREYXRhKCkpIGFzIFBhcnRpYWw8UW1kUGx1Z2luU2V0dGluZ3M+IHwgbnVsbDtcbiAgICB0aGlzLnNldHRpbmdzID0gT2JqZWN0LmFzc2lnbih7fSwgREVGQVVMVF9TRVRUSU5HUywgbG9hZGVkKTtcbiAgfVxuXG4gIGFzeW5jIHNhdmVTZXR0aW5ncygpIHtcbiAgICBhd2FpdCB0aGlzLnNhdmVEYXRhKHRoaXMuc2V0dGluZ3MpO1xuICB9XG5cbiAgaXNRdWFydG9GaWxlKGZpbGU6IFRGaWxlKTogYm9vbGVhbiB7XG4gICAgcmV0dXJuIGZpbGUuZXh0ZW5zaW9uID09PSAncW1kJztcbiAgfVxuXG4gIGlzTWFya2Rvd25GaWxlKGZpbGU6IFRGaWxlKTogYm9vbGVhbiB7XG4gICAgcmV0dXJuIGZpbGUuZXh0ZW5zaW9uID09PSAnbWQnO1xuICB9XG5cbiAgaGFzUXVhcnRvUHJvamVjdENvbmZpZ0luUGF0aChmaWxlOiBURmlsZSk6IGJvb2xlYW4ge1xuICAgIGxldCBkaXIgPSBmaWxlLnBhcmVudD8ucGF0aCA/PyAnJztcbiAgICB3aGlsZSAodHJ1ZSkge1xuICAgICAgY29uc3QgY29uZmlnUGF0aCA9IG5vcm1hbGl6ZVBhdGgoZGlyID8gYCR7ZGlyfS9fcXVhcnRvLnltbGAgOiAnX3F1YXJ0by55bWwnKTtcbiAgICAgIGlmICh0aGlzLmFwcC52YXVsdC5nZXRBYnN0cmFjdEZpbGVCeVBhdGgoY29uZmlnUGF0aCkgaW5zdGFuY2VvZiBURmlsZSkge1xuICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgIH1cbiAgICAgIGlmICghZGlyKSByZXR1cm4gZmFsc2U7XG4gICAgICBjb25zdCBzbGFzaCA9IGRpci5sYXN0SW5kZXhPZignLycpO1xuICAgICAgZGlyID0gc2xhc2ggPT09IC0xID8gJycgOiBkaXIuc2xpY2UoMCwgc2xhc2gpO1xuICAgIH1cbiAgfVxuXG4gIGdldEFjdGl2ZVF1YXJ0b0NvbW1hbmRGaWxlKCk6IFRGaWxlIHwgbnVsbCB7XG4gICAgY29uc3QgYWN0aXZlVmlldyA9IHRoaXMuYXBwLndvcmtzcGFjZS5nZXRBY3RpdmVWaWV3T2ZUeXBlKE1hcmtkb3duVmlldyk7XG4gICAgY29uc3QgZmlsZSA9IGFjdGl2ZVZpZXc/LmZpbGU7XG4gICAgaWYgKCFmaWxlKSB7XG4gICAgICBuZXcgTm90aWNlKCdRdWFydG8gY29tbWFuZHMgcmVxdWlyZSBhbiBhY3RpdmUgLnFtZCBmaWxlLicpO1xuICAgICAgcmV0dXJuIG51bGw7XG4gICAgfVxuXG4gICAgaWYgKHRoaXMuaXNRdWFydG9GaWxlKGZpbGUpKSB7XG4gICAgICByZXR1cm4gZmlsZTtcbiAgICB9XG5cbiAgICBpZiAodGhpcy5pc01hcmtkb3duRmlsZShmaWxlKSkge1xuICAgICAgaWYgKCF0aGlzLnNldHRpbmdzLnByZXZpZXdNYXJrZG93bkZpbGVzKSB7XG4gICAgICAgIG5ldyBOb3RpY2UoJ01hcmtkb3duIHN1cHBvcnQgaXMgb2ZmLiBFbmFibGUgaXQgaW4gc2V0dGluZ3MgdG8gcHJldmlldyBvciByZW5kZXIgLm1kIGZpbGVzIHdpdGggUXVhcnRvLicpO1xuICAgICAgICByZXR1cm4gbnVsbDtcbiAgICAgIH1cbiAgICAgIGlmICghdGhpcy5oYXNRdWFydG9Qcm9qZWN0Q29uZmlnSW5QYXRoKGZpbGUpKSB7XG4gICAgICAgIG5ldyBOb3RpY2UoJ01hcmtkb3duIFF1YXJ0byBjb21tYW5kcyByZXF1aXJlIF9xdWFydG8ueW1sIGluIHRoaXMgZmlsZSBmb2xkZXIgb3IgYW4gYW5jZXN0b3IgdXAgdG8gdGhlIHZhdWx0IHJvb3QuJyk7XG4gICAgICAgIHJldHVybiBudWxsO1xuICAgICAgfVxuICAgICAgcmV0dXJuIGZpbGU7XG4gICAgfVxuXG4gICAgaWYgKHRoaXMuc2V0dGluZ3MucHJldmlld01hcmtkb3duRmlsZXMpIHtcbiAgICAgIG5ldyBOb3RpY2UoJ1F1YXJ0byBjb21tYW5kcyByZXF1aXJlIGFuIGFjdGl2ZSAucW1kIG9yIC5tZCBmaWxlLicpO1xuICAgIH0gZWxzZSB7XG4gICAgICBuZXcgTm90aWNlKCdRdWFydG8gY29tbWFuZHMgcmVxdWlyZSBhbiBhY3RpdmUgLnFtZCBmaWxlLicpO1xuICAgIH1cbiAgICByZXR1cm4gbnVsbDtcbiAgfVxuXG4gIGdldFZhdWx0RnVsbFBhdGgoZmlsZTogVEZpbGUpOiBzdHJpbmcgfCBudWxsIHtcbiAgICBjb25zdCBhZGFwdGVyID0gdGhpcy5hcHAudmF1bHQuYWRhcHRlcjtcbiAgICBpZiAoYWRhcHRlciBpbnN0YW5jZW9mIEZpbGVTeXN0ZW1BZGFwdGVyKSB7XG4gICAgICByZXR1cm4gYWRhcHRlci5nZXRGdWxsUGF0aChmaWxlLnBhdGgpO1xuICAgIH1cbiAgICBuZXcgTm90aWNlKCdWYXVsdCBpcyBub3Qgb24gYSBsb2NhbCBmaWxlc3lzdGVtOyBjYW5ub3QgcnVuIFF1YXJ0by4nKTtcbiAgICByZXR1cm4gbnVsbDtcbiAgfVxuXG4gIHBkZlBhdGhGb3IoZmlsZTogVEZpbGUpOiBzdHJpbmcge1xuICAgIHJldHVybiBmaWxlLnBhdGgucmVwbGFjZSgvXFwuKHFtZHxtZCkkL2ksICcucGRmJyk7XG4gIH1cblxuICAvLyBQdWxsIHRoZSBURmlsZSBhIGxlYWYgY3VycmVudGx5IHNob3dzLCB3aXRob3V0IHJlc29ydGluZyB0b1xuICAvLyBgYXMgYW55YC4gVGhlIGJ1aWx0LWluIFBERiB2aWV3IChhbmQgbW9zdCBmaWxlLWJhY2tlZCB2aWV3cylcbiAgLy8gZXh0ZW5kIEZpbGVWaWV3LCB3aGljaCBleHBvc2VzIGEgdHlwZWQgYGZpbGU6IFRGaWxlIHwgbnVsbGAuXG4gIHByaXZhdGUgbGVhZkZpbGUobGVhZjogV29ya3NwYWNlTGVhZik6IFRGaWxlIHwgbnVsbCB7XG4gICAgcmV0dXJuIGxlYWYudmlldyBpbnN0YW5jZW9mIEZpbGVWaWV3ID8gbGVhZi52aWV3LmZpbGUgOiBudWxsO1xuICB9XG5cbiAgLy8gT3BlbiAob3IgcmV1c2UpIGEgbGVhZiBzaG93aW5nIHRoZSBnaXZlbiB2YXVsdC1yZWxhdGl2ZSBQREYgcGF0aCBpblxuICAvLyBPYnNpZGlhbidzIG5hdGl2ZSBQREYgdmlld2VyLiBSZXR1cm5zIHRoZSBsZWFmIHNvIGNhbGxlcnMgY2FuIGtlZXBcbiAgLy8gcmVmcmVzaGluZyBpdCBvbiBzdWJzZXF1ZW50IHByZXZpZXcgY29tcGlsZXMuXG4gIC8vXG4gIC8vIExlYWYtcmVzb2x1dGlvbiBvcmRlcjpcbiAgLy8gICAxLiBDYWxsZXIncyBjYXB0dXJlZCByZWYsIGlmIHN0aWxsIGF0dGFjaGVkIHRvIHRoZSB3b3Jrc3BhY2UuXG4gIC8vICAgMi4gQW55IG9wZW4gJ3BkZicgbGVhZiBhbHJlYWR5IHNob3dpbmcgdGhpcyBleGFjdCBmaWxlICh1c2VyIG1heVxuICAvLyAgICAgIGhhdmUgb3BlbmVkIGl0IG1hbnVhbGx5LCBvciByZW5kZXJQZGYgbWF5IGhhdmUgb3BlbmVkIGl0KS5cbiAgLy8gICAzLiBOZXcgdmVydGljYWwgc3BsaXQuXG4gIGFzeW5jIG9wZW5PclJlZnJlc2hQZGZQcmV2aWV3KFxuICAgIHZhdWx0UGF0aDogc3RyaW5nLFxuICAgIGV4aXN0aW5nTGVhZjogV29ya3NwYWNlTGVhZiB8IG51bGxcbiAgKTogUHJvbWlzZTxXb3Jrc3BhY2VMZWFmIHwgbnVsbD4ge1xuICAgIGNvbnN0IHBkZlRGaWxlID0gYXdhaXQgdGhpcy53YWl0Rm9yVmF1bHRGaWxlKHZhdWx0UGF0aCk7XG4gICAgaWYgKCFwZGZURmlsZSkge1xuICAgICAgbmV3IE5vdGljZShcbiAgICAgICAgYFF1YXJ0byBwcmV2aWV3IHByb2R1Y2VkICR7dmF1bHRQYXRofSBidXQgaXQgZGlkIG5vdCBhcHBlYXIgaW4gdGhlIHZhdWx0IHdpdGhpbiB0aGUgdGltZW91dC5gXG4gICAgICApO1xuICAgICAgcmV0dXJuIG51bGw7XG4gICAgfVxuICAgIHRyeSB7XG4gICAgICBjb25zdCByZXVzYWJsZSA9XG4gICAgICAgIGV4aXN0aW5nTGVhZj8ucGFyZW50ICE9IG51bGxcbiAgICAgICAgICA/IGV4aXN0aW5nTGVhZlxuICAgICAgICAgIDogdGhpcy5hcHAud29ya3NwYWNlXG4gICAgICAgICAgICAgIC5nZXRMZWF2ZXNPZlR5cGUoJ3BkZicpXG4gICAgICAgICAgICAgIC5maW5kKChsKSA9PiB0aGlzLmxlYWZGaWxlKGwpPy5wYXRoID09PSBwZGZURmlsZS5wYXRoKSA/PyBudWxsO1xuICAgICAgY29uc3QgbGVhZiA9IHJldXNhYmxlID8/IHRoaXMuYXBwLndvcmtzcGFjZS5nZXRMZWFmKCdzcGxpdCcsICd2ZXJ0aWNhbCcpO1xuICAgICAgLy8gU2tpcCB0aGUgb3BlbkZpbGUgY2FsbCB3aGVuIHRoZSBsZWFmIGFscmVhZHkgc2hvd3MgdGhpcyBmaWxlIOKAlFxuICAgICAgLy8gY2FsbGluZyBvcGVuRmlsZSBpbiB0aGF0IGNhc2UgaXMgaGFybWxlc3MgZm9yIHRoZSBmaWxlIGRpc3BsYXlcbiAgICAgIC8vIGJ1dCBzdGlsbCB0cmlnZ2VycyBhIHJldmVhbC9mb2N1cyBzaHVmZmxlIHRoZSB1c2VyIGRvZXMgbm90IHdhbnQuXG4gICAgICAvLyBPYnNpZGlhbidzIFBERiB2aWV3ZXIgcGlja3MgdXAgdGhlIGZpbGUgcmV3cml0ZSB2aWEgaXRzIG93blxuICAgICAgLy8gbXRpbWUgd2F0Y2hlciwgc28gbGl2ZSByZWxvYWQgc3RpbGwgd29ya3Mgd2l0aG91dCBvdXIgaGVscC5cbiAgICAgIGNvbnN0IGN1cnJlbnRGaWxlID0gdGhpcy5sZWFmRmlsZShsZWFmKTtcbiAgICAgIGlmICghY3VycmVudEZpbGUgfHwgY3VycmVudEZpbGUucGF0aCAhPT0gcGRmVEZpbGUucGF0aCkge1xuICAgICAgICBhd2FpdCBsZWFmLm9wZW5GaWxlKHBkZlRGaWxlLCB7IGFjdGl2ZTogZmFsc2UgfSk7XG4gICAgICB9XG4gICAgICBhd2FpdCB0aGlzLmFwcC53b3Jrc3BhY2UucmV2ZWFsTGVhZihsZWFmKTtcbiAgICAgIHJldHVybiBsZWFmO1xuICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgY29uc29sZS5lcnJvcignW3FtZC1hcy1tZF0gRmFpbGVkIHRvIG9wZW4gUERGIHByZXZpZXcgaW4gbmF0aXZlIHZpZXdlcjonLCBlcnIpO1xuICAgICAgbmV3IE5vdGljZShgQ291bGQgbm90IG9wZW4gJHt2YXVsdFBhdGh9IGluIE9ic2lkaWFuJ3MgUERGIHZpZXdlci5gKTtcbiAgICAgIHJldHVybiBudWxsO1xuICAgIH1cbiAgfVxuXG4gIGFzeW5jIG9wZW5QcmV2aWV3VXJsKHVybDogc3RyaW5nLCBtb2RlOiBQcmV2aWV3TW9kZSkge1xuICAgIGNvbnNvbGUubG9nKCdbcW1kLWFzLW1kXVtkaWFnXSBvcGVuUHJldmlld1VybCBjYWxsZWQuIHVybDonLCB1cmwsICdtb2RlOicsIG1vZGUpO1xuICAgIG5ldyBOb3RpY2UoYFByZXZpZXcgYXZhaWxhYmxlIGF0ICR7dXJsfWApO1xuXG4gICAgaWYgKG1vZGUgPT09ICdleHRlcm5hbCcpIHtcbiAgICAgIC8vIFF1YXJ0byBpcyBsYXVuY2hlZCB3aXRoIC0tbm8tYnJvd3NlciBpbiBldmVyeSBtb2RlOyB0aGlzIG9wZW5zIHRoZVxuICAgICAgLy8gY2FwdHVyZWQgVVJMIG9uY2Ugd2hpbGUgbGVhdmluZyBRdWFydG8ncyBsaXZlLXJlbG9hZCBjbGllbnQgaW4gY2hhcmdlXG4gICAgICAvLyBhZnRlciB0aGUgcGFnZSBpcyBsb2FkZWQuXG4gICAgICB0cnkge1xuICAgICAgICBhd2FpdCBzaGVsbC5vcGVuRXh0ZXJuYWwodXJsKTtcbiAgICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgICBjb25zb2xlLmVycm9yKCdbcW1kLWFzLW1kXSBGYWlsZWQgdG8gb3BlbiBleHRlcm5hbCBwcmV2aWV3OicsIGVycik7XG4gICAgICAgIG5ldyBOb3RpY2UoYENvdWxkIG5vdCBvcGVuIGV4dGVybmFsIGJyb3dzZXIuIFByZXZpZXcgVVJMOiAke3VybH1gLCAxMDAwMCk7XG4gICAgICB9XG4gICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgLy8gVGhlIFwiV2ViIHZpZXdlclwiIGNvcmUgcGx1Z2luIChPYnNpZGlhbiAxLjgrKSByZWdpc3RlcnMgdGhlXG4gICAgLy8gJ3dlYnZpZXdlcicgdmlldyB0eXBlLiBJZiB0aGUgdXNlciBoYXMgaXQgZGlzYWJsZWQsIHNldFZpZXdTdGF0ZVxuICAgIC8vIHNpbGVudGx5IGZhaWxzIC8gbGVhdmVzIGFuIGVtcHR5IGxlYWYsIGFuZCB0aGUgdXNlciBpcyBsZWZ0XG4gICAgLy8gd29uZGVyaW5nIHdoeSBub3RoaW5nIG9wZW5lZC4gRGV0ZWN0IGFuZCByZXBvcnQgaW5zdGVhZC5cbiAgICBjb25zdCBpbnRlcm5hbFBsdWdpbnMgPSAoXG4gICAgICB0aGlzLmFwcCBhcyBBcHAgJiB7XG4gICAgICAgIGludGVybmFsUGx1Z2lucz86IHtcbiAgICAgICAgICBnZXRFbmFibGVkUGx1Z2luQnlJZD86IChpZDogc3RyaW5nKSA9PiB1bmtub3duO1xuICAgICAgICAgIHBsdWdpbnM/OiBSZWNvcmQ8c3RyaW5nLCB7IGVuYWJsZWQ/OiBib29sZWFuIH0gfCB1bmRlZmluZWQ+O1xuICAgICAgICB9O1xuICAgICAgfVxuICAgICkuaW50ZXJuYWxQbHVnaW5zO1xuICAgIGNvbnN0IHdlYnZpZXdlck9uID1cbiAgICAgIGludGVybmFsUGx1Z2lucz8uZ2V0RW5hYmxlZFBsdWdpbkJ5SWQ/Lignd2Vidmlld2VyJykgIT0gbnVsbCB8fFxuICAgICAgaW50ZXJuYWxQbHVnaW5zPy5wbHVnaW5zPy53ZWJ2aWV3ZXI/LmVuYWJsZWQgPT09IHRydWU7XG5cbiAgICBpZiAoIXdlYnZpZXdlck9uKSB7XG4gICAgICBuZXcgTm90aWNlKFxuICAgICAgICAnT2JzaWRpYW4gY29yZSBwbHVnaW4gXCJXZWIgdmlld2VyXCIgaXMgZGlzYWJsZWQg4oCUIGNhbm5vdCBzaG93IHByZXZpZXcgaW4tYXBwLiAnICtcbiAgICAgICAgICAnRW5hYmxlIGl0IGluIFNldHRpbmdzIOKGkiBDb3JlIHBsdWdpbnMsIG9yIHVzZSBcIlRvZ2dsZSBRdWFydG8gcHJldmlldyBpbiBleHRlcm5hbCBicm93c2VyXCIgaW5zdGVhZC4gJyArXG4gICAgICAgICAgJ0ZhbGxpbmcgYmFjayB0byB5b3VyIGV4dGVybmFsIGJyb3dzZXIuJyxcbiAgICAgICAgMTAwMDBcbiAgICAgICk7XG4gICAgICBjb25zb2xlLndhcm4oXG4gICAgICAgICdbcW1kLWFzLW1kXSB3ZWJ2aWV3ZXIgY29yZSBwbHVnaW4gZGlzYWJsZWQ7IHByZXZpZXcgVVJMIHdhczonLFxuICAgICAgICB1cmxcbiAgICAgICk7XG4gICAgICB2b2lkIHNoZWxsLm9wZW5FeHRlcm5hbCh1cmwpO1xuICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIHRyeSB7XG4gICAgICBjb25zdCBsZWFmID0gdGhpcy5hcHAud29ya3NwYWNlLmdldExlYWYoJ3RhYicpO1xuICAgICAgYXdhaXQgbGVhZi5zZXRWaWV3U3RhdGUoe1xuICAgICAgICB0eXBlOiAnd2Vidmlld2VyJyxcbiAgICAgICAgYWN0aXZlOiB0cnVlLFxuICAgICAgICBzdGF0ZTogeyB1cmwgfSxcbiAgICAgIH0pO1xuICAgICAgYXdhaXQgdGhpcy5hcHAud29ya3NwYWNlLnJldmVhbExlYWYobGVhZik7XG4gICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICBjb25zb2xlLmVycm9yKCdbcW1kLWFzLW1kXSBGYWlsZWQgdG8gb3BlbiBwcmV2aWV3IGluIHdlYnZpZXdlcjonLCBlcnIpO1xuICAgICAgbmV3IE5vdGljZShcbiAgICAgICAgXCJDb3VsZCBub3Qgb3BlbiBwcmV2aWV3IGluIE9ic2lkaWFuJ3Mgd2ViIHZpZXdlci4gRmFsbGluZyBiYWNrIHRvIGV4dGVybmFsIGJyb3dzZXIuXCJcbiAgICAgICk7XG4gICAgICB2b2lkIHNoZWxsLm9wZW5FeHRlcm5hbCh1cmwpO1xuICAgIH1cbiAgfVxuXG4gIHJlZ2lzdGVyUmVuZGVyQ29tbWFuZChpZDogc3RyaW5nLCBuYW1lOiBzdHJpbmcsIHRvRm9ybWF0PzogJ3BkZicgfCAndHlwc3QnKSB7XG4gICAgdGhpcy5hZGRDb21tYW5kKHtcbiAgICAgIGlkLFxuICAgICAgbmFtZSxcbiAgICAgIGljb246ICdmaWxlLW91dHB1dCcsXG4gICAgICBjYWxsYmFjazogYXN5bmMgKCkgPT4ge1xuICAgICAgICBjb25zdCBmaWxlID0gdGhpcy5nZXRBY3RpdmVRdWFydG9Db21tYW5kRmlsZSgpO1xuICAgICAgICBpZiAoZmlsZSkgYXdhaXQgdGhpcy5yZW5kZXJQZGYoZmlsZSwgdG9Gb3JtYXQpO1xuICAgICAgfSxcbiAgICB9KTtcbiAgfVxuXG4gIHJlZ2lzdGVyUW1kRXh0ZW5zaW9uKCkge1xuICAgIHRoaXMucmVnaXN0ZXJFeHRlbnNpb25zKFsncW1kJ10sICdtYXJrZG93bicpO1xuICB9XG5cbiAgcmVnaXN0ZXJZYW1sRXh0ZW5zaW9ucygpIHtcbiAgICB0aGlzLnJlZ2lzdGVyRXh0ZW5zaW9ucyhbJ3ltbCcsICd5YW1sJ10sIFFNRF9ZQU1MX1ZJRVcpO1xuICB9XG5cbiAgLy8gT3BlbiB0aGUgUXVhcnRvIG91dGxpbmUgaW4gdGhlIHJpZ2h0IHNpZGViYXIsIHJldXNpbmcgYW4gZXhpc3RpbmdcbiAgLy8gb3V0bGluZSBsZWFmIGlmIG9uZSBpcyBhbHJlYWR5IG9wZW4uXG4gIGFzeW5jIGFjdGl2YXRlT3V0bGluZVZpZXcoKTogUHJvbWlzZTx2b2lkPiB7XG4gICAgY29uc3QgeyB3b3Jrc3BhY2UgfSA9IHRoaXMuYXBwO1xuICAgIC8vIENhcHR1cmUgdGhlIGN1cnJlbnQgLnFtZCBiZWZvcmUgb3BlbmluZyB0aGUgb3V0bGluZSDigJQgc2V0Vmlld1N0YXRlXG4gICAgLy8gd2l0aCBhY3RpdmU6dHJ1ZSBtYWtlcyB0aGUgb3V0bGluZSB0aGUgYWN0aXZlIGxlYWYsIGFmdGVyIHdoaWNoIHRoZVxuICAgIC8vIGFjdGl2ZSBtYXJrZG93biB2aWV3IGlzIGdvbmUuXG4gICAgdGhpcy50cmFja0FjdGl2ZVF1YXJ0b0ZpbGUoKTtcbiAgICBsZXQgbGVhZjogV29ya3NwYWNlTGVhZiB8IG51bGwgPSB3b3Jrc3BhY2UuZ2V0TGVhdmVzT2ZUeXBlKFFNRF9PVVRMSU5FX1ZJRVcpWzBdID8/IG51bGw7XG4gICAgaWYgKCFsZWFmKSB7XG4gICAgICBsZWFmID0gd29ya3NwYWNlLmdldFJpZ2h0TGVhZihmYWxzZSk7XG4gICAgICBhd2FpdCBsZWFmPy5zZXRWaWV3U3RhdGUoeyB0eXBlOiBRTURfT1VUTElORV9WSUVXLCBhY3RpdmU6IHRydWUgfSk7XG4gICAgfVxuICAgIGlmIChsZWFmKSBhd2FpdCB3b3Jrc3BhY2UucmV2ZWFsTGVhZihsZWFmKTtcbiAgICB0aGlzLnJlZnJlc2hPdXRsaW5lVmlld3MoKTtcbiAgfVxuXG4gIC8vIFJlbWVtYmVyIHRoZSBhY3RpdmUgLnFtZCBmaWxlLiBDYWxsZWQgd2hlbmV2ZXIgdGhlIGFjdGl2ZSBsZWFmIGNoYW5nZXM7XG4gIC8vIGEgbm9uLS5xbWQgYWN0aXZlIGxlYWYgKGluY2x1ZGluZyB0aGUgb3V0bGluZSBzaWRlYmFyIGl0c2VsZikgbGVhdmVzIHRoZVxuICAvLyBsYXN0IHZhbHVlIHVudG91Y2hlZCBzbyB0aGUgb3V0bGluZSBrZWVwcyBkZXNjcmliaW5nIHRoYXQgZmlsZS5cbiAgdHJhY2tBY3RpdmVRdWFydG9GaWxlKCk6IHZvaWQge1xuICAgIGNvbnN0IHZpZXcgPSB0aGlzLmFwcC53b3Jrc3BhY2UuZ2V0QWN0aXZlVmlld09mVHlwZShNYXJrZG93blZpZXcpO1xuICAgIGlmICh2aWV3Py5maWxlICYmIHRoaXMuaXNRdWFydG9GaWxlKHZpZXcuZmlsZSkpIHtcbiAgICAgIHRoaXMubGFzdEFjdGl2ZVF1YXJ0b0ZpbGUgPSB2aWV3LmZpbGU7XG4gICAgfVxuICB9XG5cbiAgLy8gUmUtcmVuZGVyIGV2ZXJ5IG9wZW4gb3V0bGluZSB2aWV3LiBOby1vcCB3aGVuIG5vbmUgYXJlIG9wZW4uXG4gIHJlZnJlc2hPdXRsaW5lVmlld3MoKTogdm9pZCB7XG4gICAgZm9yIChjb25zdCBsZWFmIG9mIHRoaXMuYXBwLndvcmtzcGFjZS5nZXRMZWF2ZXNPZlR5cGUoUU1EX09VVExJTkVfVklFVykpIHtcbiAgICAgIGlmIChsZWFmLnZpZXcgaW5zdGFuY2VvZiBRbWRPdXRsaW5lVmlldykge1xuICAgICAgICBsZWFmLnZpZXcucmVuZGVyKCk7XG4gICAgICB9XG4gICAgfVxuICB9XG5cbiAgLy8gQ2xvc2UgYW55IG9wZW4gb3V0bGluZSB2aWV3cyDigJQgdXNlZCB3aGVuIHRoZSB1c2VyIHR1cm5zIHRoZSBzZXR0aW5nIG9mZi5cbiAgZGV0YWNoT3V0bGluZVZpZXdzKCk6IHZvaWQge1xuICAgIGZvciAoY29uc3QgbGVhZiBvZiB0aGlzLmFwcC53b3Jrc3BhY2UuZ2V0TGVhdmVzT2ZUeXBlKFFNRF9PVVRMSU5FX1ZJRVcpKSB7XG4gICAgICBsZWFmLmRldGFjaCgpO1xuICAgIH1cbiAgfVxuXG4gIHByaXZhdGUgZGVmYXVsdFByZXZpZXdNb2RlKCk6IFByZXZpZXdNb2RlIHtcbiAgICByZXR1cm4gdGhpcy5zZXR0aW5ncy5wcmV2aWV3SW5PYnNpZGlhbiA/ICdvYnNpZGlhbicgOiAnZXh0ZXJuYWwnO1xuICB9XG5cbiAgYXN5bmMgdG9nZ2xlUHJldmlldyhmaWxlOiBURmlsZSwgbW9kZTogUHJldmlld01vZGUgPSB0aGlzLmRlZmF1bHRQcmV2aWV3TW9kZSgpKSB7XG4gICAgY29uc3QgYWN0aXZlUHJldmlldyA9IHRoaXMuYWN0aXZlUHJldmlld1Byb2Nlc3Nlcy5nZXQoZmlsZS5wYXRoKTtcbiAgICBpZiAoYWN0aXZlUHJldmlldz8ubW9kZSA9PT0gbW9kZSkge1xuICAgICAgYXdhaXQgdGhpcy5zdG9wUHJldmlldyhmaWxlKTtcbiAgICB9IGVsc2Uge1xuICAgICAgaWYgKGFjdGl2ZVByZXZpZXcpIHtcbiAgICAgICAgYXdhaXQgdGhpcy5zdG9wUHJldmlldyhmaWxlKTtcbiAgICAgIH1cbiAgICAgIGF3YWl0IHRoaXMuc3RhcnRQcmV2aWV3KGZpbGUsIG1vZGUpO1xuICAgIH1cbiAgfVxuXG4gIGFzeW5jIHN0YXJ0UHJldmlldyhmaWxlOiBURmlsZSwgbW9kZTogUHJldmlld01vZGUgPSB0aGlzLmRlZmF1bHRQcmV2aWV3TW9kZSgpKSB7XG4gICAgY29uc3QgYWN0aXZlUHJldmlldyA9IHRoaXMuYWN0aXZlUHJldmlld1Byb2Nlc3Nlcy5nZXQoZmlsZS5wYXRoKTtcbiAgICBpZiAoYWN0aXZlUHJldmlldz8ubW9kZSA9PT0gbW9kZSkge1xuICAgICAgcmV0dXJuOyAvLyBQcmV2aWV3IGFscmVhZHkgcnVubmluZyBmb3IgdGhpcyBmaWxlIGluIHRoaXMgbW9kZS5cbiAgICB9XG4gICAgaWYgKGFjdGl2ZVByZXZpZXcpIHtcbiAgICAgIGF3YWl0IHRoaXMuc3RvcFByZXZpZXcoZmlsZSk7XG4gICAgfVxuXG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IGFic3RyYWN0RmlsZSA9IHRoaXMuYXBwLnZhdWx0LmdldEFic3RyYWN0RmlsZUJ5UGF0aChmaWxlLnBhdGgpO1xuICAgICAgaWYgKCFhYnN0cmFjdEZpbGUgfHwgIShhYnN0cmFjdEZpbGUgaW5zdGFuY2VvZiBURmlsZSkpIHtcbiAgICAgICAgbmV3IE5vdGljZShgRmlsZSAke2ZpbGUucGF0aH0gbm90IGZvdW5kYCk7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cbiAgICAgIGNvbnN0IGZpbGVQYXRoID0gdGhpcy5nZXRWYXVsdEZ1bGxQYXRoKGFic3RyYWN0RmlsZSk7XG4gICAgICBpZiAoIWZpbGVQYXRoKSByZXR1cm47XG4gICAgICBjb25zdCB3b3JraW5nRGlyID0gcGF0aC5kaXJuYW1lKGZpbGVQYXRoKTtcblxuICAgICAgY29uc3QgZW52VmFyczogTm9kZUpTLlByb2Nlc3NFbnYgPSB7IC4uLnByb2Nlc3MuZW52IH07XG4gICAgICBpZiAodGhpcy5zZXR0aW5ncy5xdWFydG9UeXBzdC50cmltKCkpIHtcbiAgICAgICAgZW52VmFycy5RVUFSVE9fVFlQU1QgPSB0aGlzLnNldHRpbmdzLnF1YXJ0b1R5cHN0LnRyaW0oKTtcbiAgICAgIH1cblxuICAgICAgLy8gQWx3YXlzIHN1cHByZXNzIFF1YXJ0bydzIG93biBicm93c2VyIGxhdW5jaC4gVGhlIHBsdWdpbiBvcGVucyB0aGVcbiAgICAgIC8vIGNhcHR1cmVkIFVSTCBleGFjdGx5IG9uY2UgZm9yIHRoZSBzZWxlY3RlZCB0YXJnZXQsIHdoaWNoIGF2b2lkc1xuICAgICAgLy8gZHVwbGljYXRlIHRhYnMgYW5kIGF2b2lkcyBRdWFydG8tbWFuYWdlZCBicm93c2VyIG5hdmlnYXRpb24gY2xvc2luZ1xuICAgICAgLy8gdGhlIHByZXZpZXcgcHJvY2VzcyBvbiBzdWJzZXF1ZW50IHNvdXJjZSBjaGFuZ2VzLlxuICAgICAgY29uc3QgYXJncyA9IFsncHJldmlldycsIGZpbGVQYXRoLCAnLS1uby1icm93c2VyJ107XG5cbiAgICAgIC8vIGRldGFjaGVkOiBgcXVhcnRvIHByZXZpZXdgIGZvcmtzIGEgc2VwYXJhdGUgbG9uZy1saXZlZCBzZXJ2ZXJcbiAgICAgIC8vIHByb2Nlc3MuIE1ha2luZyB0aGUgc3Bhd25lZCBwcm9jZXNzIGEgcHJvY2Vzcy1ncm91cCBsZWFkZXIgKFBPU0lYKVxuICAgICAgLy8gbGV0cyBraWxsUHJldmlld1Byb2Nlc3Mgc2lnbmFsIHRoZSB3aG9sZSBncm91cCDigJQgYSBwbGFpbiBraWxsKCkgb2ZcbiAgICAgIC8vIHRoZSB3cmFwcGVyIHdvdWxkIG9ycGhhbiB0aGUgc2VydmVyLCBsZWF2aW5nIGl0IHNlcnZpbmcgYW5kXG4gICAgICAvLyByZWNvbXBpbGluZyBhZnRlciBcInN0b3BcIi4gTm8gcHJvY2VzcyBncm91cHMgb24gV2luZG93czsgdGhlIGtpbGxcbiAgICAgIC8vIHRoZXJlIGdvZXMgdGhyb3VnaCB0YXNra2lsbCBpbnN0ZWFkLlxuICAgICAgY29uc3QgcXVhcnRvUHJvY2VzcyA9IHNwYXduKFxuICAgICAgICB0aGlzLnNldHRpbmdzLnF1YXJ0b1BhdGgsXG4gICAgICAgIGFyZ3MsXG4gICAgICAgIHtcbiAgICAgICAgICBjd2Q6IHdvcmtpbmdEaXIsXG4gICAgICAgICAgZW52OiBlbnZWYXJzLFxuICAgICAgICAgIGRldGFjaGVkOiBwcm9jZXNzLnBsYXRmb3JtICE9PSAnd2luMzInLFxuICAgICAgICB9XG4gICAgICApO1xuXG4gICAgICBsZXQgcHJldmlld1VybDogc3RyaW5nIHwgbnVsbCA9IG51bGw7XG5cbiAgICAgIC8vIFBERi1wcmV2aWV3IHN0YXRlLiBRdWFydG8gZW1pdHMgXCJPdXRwdXQgY3JlYXRlZDogZm9vLnBkZlwiIG9uXG4gICAgICAvLyBldmVyeSByZWNvbXBpbGUgKG9mdGVuIHNldmVyYWwgdGltZXMgcGVyIHJlY29tcGlsZSk7IHRoZVxuICAgICAgLy8gaGFuZGxlciBkZWR1cHMgc28gd2UgZG9uJ3Qgc3Bhd24gdGFicyBvbiBldmVyeSBzYXZlLlxuICAgICAgLy9cbiAgICAgIC8vICBsZWFmOiAgY3VycmVudCBQREYgdGFiLCBpZiBhbnkuXG4gICAgICAvLyAgcGF0aDogIHRoZSBwYXRoIHRoYXQgbGVhZiBpcyBzaG93aW5nIChhbmQgdGhlIHBhdGggb2YgYW5cbiAgICAgIC8vICAgICAgICAgaW4tZmxpZ2h0IG9wZW4gY2FsbCwgcmVjb3JkZWQgc3luY2hyb25vdXNseSB3aGVuIGl0XG4gICAgICAvLyAgICAgICAgIGlzIHNjaGVkdWxlZCkuIEFsc28gZ2F0ZXMgdGhlIHByZXZpZXctVVJMIHNraXAgbG9naWNcbiAgICAgIC8vICAgICAgICAgb24gdGhlIFwiQnJvd3NlIGF0XCIgYnJhbmNoIGJlbG93IOKAlCB3aGVuIGEgUERGXG4gICAgICAvLyAgICAgICAgIHByZXZpZXcgaXMgYWN0aXZlLCB3ZSBkb24ndCBvcGVuIFF1YXJ0bydzIFBERi5qc1xuICAgICAgLy8gICAgICAgICB3cmFwcGVyIHBhZ2UgaW4gdGhlIHdlYnZpZXdlciB0b28uXG4gICAgICAvLyAgYnVzeTogIGEgY2FsbCB0byBvcGVuT3JSZWZyZXNoUGRmUHJldmlldyBpcyBpbiBmbGlnaHQuXG4gICAgICAvL1xuICAgICAgLy8gU2NoZWR1bGUgb3BlbiB3aGVuIGFueSBvZjpcbiAgICAgIC8vICAgLSBsZWFmIGlzIGRldGFjaGVkICh1c2VyIGNsb3NlZCB0aGUgdGFiIG1hbnVhbGx5KVxuICAgICAgLy8gICAtIHRoZSBuZXcgb3V0cHV0IHBhdGggZGlmZmVycyBmcm9tIHRoZSB0cmFja2VkIG9uZVxuICAgICAgLy8gICAgIChtdWx0aS1mb3JtYXQgcHJvamVjdCwgb3IgcmVuYW1lKVxuICAgICAgLy8gICAtIHdlIG5ldmVyIG9wZW5lZCBpbiB0aGlzIHNlc3Npb25cbiAgICAgIC8vIFNraXAgd2hlbiBidXN5IChidXJzdHMgb2YgZW1pc3Npb25zIGR1cmluZyByZWNvbXBpbGUgZGVkdXBcbiAgICAgIC8vIGF1dG9tYXRpY2FsbHk7IHRoZSBmaW5hbCBlbWlzc2lvbiBvZiBhIGJ1cnN0IHdpbnMgYmVjYXVzZSBpdFxuICAgICAgLy8gYXJyaXZlcyBhZnRlciBidXN5IGNsZWFycykuXG4gICAgICBsZXQgcGRmUHJldmlld0xlYWY6IFdvcmtzcGFjZUxlYWYgfCBudWxsID0gbnVsbDtcbiAgICAgIGxldCBwZGZQcmV2aWV3UGF0aDogc3RyaW5nIHwgbnVsbCA9IG51bGw7XG4gICAgICBsZXQgcGRmUHJldmlld0J1c3kgPSBmYWxzZTtcblxuICAgICAgY29uc3Qgc2NoZWR1bGVQZGZQcmV2aWV3ID0gKHZhdWx0UGF0aDogc3RyaW5nKTogdm9pZCA9PiB7XG4gICAgICAgIGlmIChwZGZQcmV2aWV3QnVzeSkgcmV0dXJuO1xuICAgICAgICBjb25zdCBsZWFmQXR0YWNoZWQgPSBwZGZQcmV2aWV3TGVhZj8ucGFyZW50ICE9IG51bGw7XG4gICAgICAgIGNvbnN0IHBhdGhTYW1lID0gcGRmUHJldmlld1BhdGggPT09IHZhdWx0UGF0aDtcbiAgICAgICAgaWYgKGxlYWZBdHRhY2hlZCAmJiBwYXRoU2FtZSkgcmV0dXJuO1xuXG4gICAgICAgIHBkZlByZXZpZXdCdXN5ID0gdHJ1ZTtcbiAgICAgICAgcGRmUHJldmlld1BhdGggPSB2YXVsdFBhdGg7XG4gICAgICAgIHRoaXMub3Blbk9yUmVmcmVzaFBkZlByZXZpZXcodmF1bHRQYXRoLCBwZGZQcmV2aWV3TGVhZilcbiAgICAgICAgICAudGhlbigobGVhZikgPT4ge1xuICAgICAgICAgICAgaWYgKGxlYWYpIHBkZlByZXZpZXdMZWFmID0gbGVhZjtcbiAgICAgICAgICB9KVxuICAgICAgICAgIC5jYXRjaCgoZXJyKSA9PiB7XG4gICAgICAgICAgICBjb25zb2xlLmVycm9yKCdbcW1kLWFzLW1kXSBQREYgcHJldmlldyBvcGVuIGZhaWxlZDonLCBlcnIpO1xuICAgICAgICAgICAgcGRmUHJldmlld0xlYWYgPSBudWxsO1xuICAgICAgICAgICAgcGRmUHJldmlld1BhdGggPSBudWxsO1xuICAgICAgICAgIH0pXG4gICAgICAgICAgLmZpbmFsbHkoKCkgPT4ge1xuICAgICAgICAgICAgcGRmUHJldmlld0J1c3kgPSBmYWxzZTtcbiAgICAgICAgICB9KTtcbiAgICAgIH07XG5cbiAgICAgIC8vIFF1YXJ0byBcIkVSUk9SOlwiIGxpbmVzIGZyb20gdGhpcyBwcmV2aWV3IHJ1bi4gVXNlZCBib3RoIHRvIHN1cmZhY2VcbiAgICAgIC8vIHJlY29tcGlsZSBmYWlsdXJlcyBsaXZlIChwcmV2aWV3IGtlZXBzIHJ1bm5pbmcsIHNvIHRoZSBjbG9zZVxuICAgICAgLy8gaGFuZGxlciBuZXZlciBmaXJlcykgYW5kIHRvIGV4cGxhaW4gYSBzdGFydHVwIGV4aXQgaW4gdGhlIE5vdGljZS5cbiAgICAgIGNvbnN0IGVycm9yTGluZXM6IHN0cmluZ1tdID0gW107XG4gICAgICAvLyBEZWR1cGU6IGEgc2luZ2xlIGZhaWxlZCByZWNvbXBpbGUgZW1pdHMgdGhlIHNhbWUgRVJST1I6IGJsb2NrIG9uXG4gICAgICAvLyBldmVyeSBzYXZlIHVudGlsIGZpeGVkIOKAlCBvbmx5IE5vdGljZSB3aGVuIHRoZSBlcnJvciB0ZXh0IGNoYW5nZXMuXG4gICAgICBsZXQgbGFzdEVycm9yU2hvd24gPSAnJztcblxuICAgICAgLy8gUGVyLWxpbmUgaGFuZGxlcjogbG9nIHRoZSBsaW5lLCB0aGVuIGxvb2sgZm9yIHRoZSB0d28gbWFya2Vyc1xuICAgICAgLy8gd2UgY2FyZSBhYm91dCAoXCJPdXRwdXQgY3JlYXRlZDpcIiBhbmQgXCJCcm93c2UgYXRcIikuXG4gICAgICBjb25zdCBoYW5kbGVQcmV2aWV3TGluZSA9IChsaW5lOiBzdHJpbmcpID0+IHtcbiAgICAgICAgbG9nUXVhcnRvTGluZSgnUXVhcnRvIFByZXZpZXcnLCBsaW5lKTtcblxuICAgICAgICBpZiAoL15FUlJPUjovLnRlc3QobGluZSkpIHtcbiAgICAgICAgICBlcnJvckxpbmVzLnB1c2gobGluZSk7XG4gICAgICAgICAgaWYgKGxpbmUgIT09IGxhc3RFcnJvclNob3duKSB7XG4gICAgICAgICAgICBsYXN0RXJyb3JTaG93biA9IGxpbmU7XG4gICAgICAgICAgICBuZXcgTm90aWNlKGBRdWFydG8gcHJldmlldyBlcnJvcjpcXG4ke2xpbmV9YCwgMTUwMDApO1xuICAgICAgICAgIH1cbiAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgLy8gQSBjbGVhbiBjb21waWxlIGNsZWFycyB0aGUgZGVkdXBlIGd1YXJkIHNvIHRoZSBzYW1lIGVycm9yXG4gICAgICAgIC8vIHJlYXBwZWFyaW5nIGFmdGVyIGEgZ29vZCBidWlsZCBpcyBzdXJmYWNlZCBhZ2Fpbi5cbiAgICAgICAgaWYgKGxpbmUuaW5jbHVkZXMoJ091dHB1dCBjcmVhdGVkOicpKSB7XG4gICAgICAgICAgbGFzdEVycm9yU2hvd24gPSAnJztcbiAgICAgICAgfVxuXG4gICAgICAgIC8vIERldGVjdCBcIk91dHB1dCBjcmVhdGVkOiA8cGF0aD5cIiDigJQgcXVhcnRvIHByaW50cyB0aGlzIG9uIGV2ZXJ5XG4gICAgICAgIC8vIGNvbXBpbGUgaW4gcHJldmlldyBtb2RlLiBJZiB0aGUgb3V0cHV0IGlzIGEgUERGLCByb3V0ZSB0b1xuICAgICAgICAvLyBPYnNpZGlhbidzIG5hdGl2ZSBQREYgdmlld2VyIHJhdGhlciB0aGFuIHRoZSB3ZWJ2aWV3ZXIgcGFnZVxuICAgICAgICAvLyBRdWFydG8gc2VydmVzIGF0IC93ZWIvdmlld2VyLmh0bWwuIFN1YnNlcXVlbnQgY29tcGlsZXMgcmVmcmVzaFxuICAgICAgICAvLyB0aGUgc2FtZSBsZWFmIHNvIGxpdmUgcmVsb2FkIHN0aWxsIHdvcmtzLlxuICAgICAgICBjb25zdCBvdXRNYXRjaCA9IGxpbmUubWF0Y2goL091dHB1dCBjcmVhdGVkOlxccyooLis/KVxccyokLyk7XG4gICAgICAgIGlmIChvdXRNYXRjaCAmJiAvXFwucGRmJC9pLnRlc3Qob3V0TWF0Y2hbMV0udHJpbSgpKSAmJiBtb2RlID09PSAnb2JzaWRpYW4nKSB7XG4gICAgICAgICAgY29uc3Qgb3V0QmFzZW5hbWUgPSBwYXRoLmJhc2VuYW1lKG91dE1hdGNoWzFdLnRyaW0oKSk7XG4gICAgICAgICAgY29uc3Qgc291cmNlRGlyID0gZmlsZS5wYXJlbnQ/LnBhdGggPz8gJyc7XG4gICAgICAgICAgY29uc3QgdmF1bHRQYXRoID0gbm9ybWFsaXplUGF0aChzb3VyY2VEaXIgPyBgJHtzb3VyY2VEaXJ9LyR7b3V0QmFzZW5hbWV9YCA6IG91dEJhc2VuYW1lKTtcbiAgICAgICAgICBzY2hlZHVsZVBkZlByZXZpZXcodmF1bHRQYXRoKTtcbiAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cblxuICAgICAgICBjb25zdCBtYXRjaGVkUHJldmlld1VybCA9IHByZXZpZXdVcmxGcm9tTGluZShsaW5lKTtcbiAgICAgICAgaWYgKCFwcmV2aWV3VXJsICYmIG1hdGNoZWRQcmV2aWV3VXJsKSB7XG4gICAgICAgICAgY29uc29sZS5sb2coXG4gICAgICAgICAgICAnW3FtZC1hcy1tZF1bZGlhZ10gQnJvd3NlLWF0IGxpbmUgc2Vlbi4nLFxuICAgICAgICAgICAgJ21hdGNoZWQ6JywgbWF0Y2hlZFByZXZpZXdVcmwsXG4gICAgICAgICAgICAncGRmUHJldmlld1BhdGg6JywgcGRmUHJldmlld1BhdGgsXG4gICAgICAgICAgICAnbW9kZTonLCBtb2RlXG4gICAgICAgICAgKTtcbiAgICAgICAgICBwcmV2aWV3VXJsID0gbWF0Y2hlZFByZXZpZXdVcmw7XG4gICAgICAgICAgLy8gSWYgd2UgYWxyZWFkeSBvcGVuZWQgYSBuYXRpdmUgUERGIHByZXZpZXcsIHNraXAgdGhlXG4gICAgICAgICAgLy8gd2Vidmlld2VyIFVSTCDigJQgUXVhcnRvJ3MgUERGLmpzIHdyYXBwZXIgd291bGQganVzdCBiZVxuICAgICAgICAgIC8vIGEgd29yc2UgdmVyc2lvbiBvZiB0aGUgc2FtZSBjb250ZW50LlxuICAgICAgICAgIGlmIChwZGZQcmV2aWV3UGF0aCkge1xuICAgICAgICAgICAgbmV3IE5vdGljZShgUERGIHByZXZpZXcgb3BlbmVkIG5hdGl2ZWx5LiBTZXJ2ZXIgVVJMOiAke3ByZXZpZXdVcmx9YCk7XG4gICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHZvaWQgdGhpcy5vcGVuUHJldmlld1VybChwcmV2aWV3VXJsLCBtb2RlKTtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgIH07XG5cbiAgICAgIC8vIE9uZSBidWZmZXJlZCBwcm9jZXNzb3IgcGVyIHN0cmVhbSDigJQgc3Rkb3V0IGFuZCBzdGRlcnIgZWFjaFxuICAgICAgLy8gbmVlZCB0aGVpciBvd24gcGFydGlhbC1saW5lIGJ1ZmZlciwgb3IgaW50ZXJsZWF2ZWQgZnJhZ21lbnRzXG4gICAgICAvLyBmcm9tIHRoZSB0d28gc3RyZWFtcyB3b3VsZCBiZSBzcGxpY2VkIGludG8gc3ludGhldGljIGxpbmVzLlxuICAgICAgY29uc3QgcHJldmlld1N0ZG91dCA9IG1ha2VMaW5lUHJvY2Vzc29yKGhhbmRsZVByZXZpZXdMaW5lKTtcbiAgICAgIGNvbnN0IHByZXZpZXdTdGRlcnIgPSBtYWtlTGluZVByb2Nlc3NvcihoYW5kbGVQcmV2aWV3TGluZSk7XG4gICAgICBxdWFydG9Qcm9jZXNzLnN0ZG91dD8ub24oJ2RhdGEnLCAoZGF0YTogQnVmZmVyKSA9PiBwcmV2aWV3U3Rkb3V0KGRhdGEudG9TdHJpbmcoKSkpO1xuICAgICAgcXVhcnRvUHJvY2Vzcy5zdGRlcnI/Lm9uKCdkYXRhJywgKGRhdGE6IEJ1ZmZlcikgPT4gcHJldmlld1N0ZGVycihkYXRhLnRvU3RyaW5nKCkpKTtcblxuICAgICAgLy8gY2hpbGRfcHJvY2Vzcy5zcGF3biBkb2VzIG5vdCB0aHJvdyBvbiBhIG1pc3NpbmcgYmluYXJ5OyBpdCBlbWl0c1xuICAgICAgLy8gYW4gJ2Vycm9yJyBldmVudCBsYXRlci4gV2l0aG91dCB0aGlzIGxpc3RlbmVyIGFuIEVOT0VOVCBqdXN0XG4gICAgICAvLyBwcm9kdWNlZCBhIHNpbGVudCBcImV4aXQgMVwiIGNsb3NlIHdpdGggbm8gb3V0cHV0IHRvIGNvbnNvbGUuXG4gICAgICBxdWFydG9Qcm9jZXNzLm9uKCdlcnJvcicsIChlcnIpID0+IHtcbiAgICAgICAgY29uc29sZS5lcnJvcignW3FtZC1hcy1tZF0gRmFpbGVkIHRvIHNwYXduIHF1YXJ0byBmb3IgcHJldmlldzonLCBlcnIpO1xuICAgICAgICBuZXcgTm90aWNlKFxuICAgICAgICAgIGBGYWlsZWQgdG8gc3Bhd24gJyR7dGhpcy5zZXR0aW5ncy5xdWFydG9QYXRofSc6ICR7ZXJyLm1lc3NhZ2V9LiBgICtcbiAgICAgICAgICAgICdDaGVjayB0aGUgUXVhcnRvIHBhdGggc2V0dGluZyBhbmQgdGhhdCBRdWFydG8gaXMgb24gUEFUSC4nXG4gICAgICAgICk7XG4gICAgICAgIGlmICh0aGlzLmFjdGl2ZVByZXZpZXdQcm9jZXNzZXMuZ2V0KGZpbGUucGF0aCk/LnByb2Nlc3MgPT09IHF1YXJ0b1Byb2Nlc3MpIHtcbiAgICAgICAgICB0aGlzLmFjdGl2ZVByZXZpZXdQcm9jZXNzZXMuZGVsZXRlKGZpbGUucGF0aCk7XG4gICAgICAgIH1cbiAgICAgIH0pO1xuXG4gICAgICBxdWFydG9Qcm9jZXNzLm9uKCdjbG9zZScsIChjb2RlOiBudW1iZXIgfCBudWxsLCBzaWduYWw6IE5vZGVKUy5TaWduYWxzIHwgbnVsbCkgPT4ge1xuICAgICAgICBwcmV2aWV3U3Rkb3V0LmZsdXNoKCk7IC8vIHJlbGVhc2UgYW55IGZpbmFsIHBhcnRpYWwgbGluZVxuICAgICAgICBwcmV2aWV3U3RkZXJyLmZsdXNoKCk7XG4gICAgICAgIGlmIChjb2RlICE9PSBudWxsICYmIGNvZGUgIT09IDApIHtcbiAgICAgICAgICBjb25zdCByZWFzb24gPSBlcnJvckxpbmVzLmxlbmd0aCA+IDBcbiAgICAgICAgICAgID8gZXJyb3JMaW5lcy5qb2luKCdcXG4nKVxuICAgICAgICAgICAgOiAnQ2hlY2sgdGhlIGRldmVsb3BlciBjb25zb2xlIGZvciBkZXRhaWxzLic7XG4gICAgICAgICAgbmV3IE5vdGljZShgUXVhcnRvIHByZXZpZXcgZXhpdGVkIHdpdGggY29kZSAke2NvZGV9LlxcbiR7cmVhc29ufWAsIDE1MDAwKTtcbiAgICAgICAgfSBlbHNlIGlmIChjb2RlID09PSBudWxsICYmIHNpZ25hbCAmJiBzaWduYWwgIT09ICdTSUdURVJNJyAmJiBzaWduYWwgIT09ICdTSUdLSUxMJykge1xuICAgICAgICAgIC8vIFNJR1RFUk0vU0lHS0lMTCBjb21lIGZyb20gb3VyIG93biBzdG9wUHJldmlldyAvIG9udW5sb2FkIOKAlCBzaWxlbnQuXG4gICAgICAgICAgbmV3IE5vdGljZShgUXVhcnRvIHByZXZpZXcgcHJvY2VzcyB3YXMgdGVybWluYXRlZCBieSAke3NpZ25hbH1gKTtcbiAgICAgICAgfVxuICAgICAgICBpZiAodGhpcy5hY3RpdmVQcmV2aWV3UHJvY2Vzc2VzLmdldChmaWxlLnBhdGgpPy5wcm9jZXNzID09PSBxdWFydG9Qcm9jZXNzKSB7XG4gICAgICAgICAgdGhpcy5hY3RpdmVQcmV2aWV3UHJvY2Vzc2VzLmRlbGV0ZShmaWxlLnBhdGgpO1xuICAgICAgICB9XG4gICAgICB9KTtcblxuICAgICAgdGhpcy5hY3RpdmVQcmV2aWV3UHJvY2Vzc2VzLnNldChmaWxlLnBhdGgsIHsgcHJvY2VzczogcXVhcnRvUHJvY2VzcywgbW9kZSB9KTtcbiAgICAgIG5ldyBOb3RpY2UoYFF1YXJ0byBwcmV2aWV3IHN0YXJ0ZWQgKCR7bW9kZSA9PT0gJ29ic2lkaWFuJyA/ICdPYnNpZGlhbicgOiAnZXh0ZXJuYWwgYnJvd3Nlcid9KWApO1xuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICBjb25zb2xlLmVycm9yKCdGYWlsZWQgdG8gc3RhcnQgUXVhcnRvIHByZXZpZXc6JywgZXJyb3IpO1xuICAgICAgbmV3IE5vdGljZSgnRmFpbGVkIHRvIHN0YXJ0IFF1YXJ0byBwcmV2aWV3Jyk7XG4gICAgfVxuICB9XG5cbiAgLy8gYHF1YXJ0byBwcmV2aWV3YCBmb3JrcyBhIGxvbmctbGl2ZWQgc2VydmVyIGFzIGEgY2hpbGQgb2YgdGhlIHNwYXduZWRcbiAgLy8gcHJvY2Vzcywgc28ga2lsbGluZyBvbmx5IHRoZSB3cmFwcGVyIGxlYXZlcyB0aGF0IHNlcnZlciBydW5uaW5nLiBTaWduYWxcbiAgLy8gdGhlIHdob2xlIHByb2Nlc3MgdHJlZTogdGhlIHByb2Nlc3MgZ3JvdXAgb24gUE9TSVggKHRoZSBjaGlsZCB3YXNcbiAgLy8gc3Bhd25lZCBkZXRhY2hlZCwgc2VlIHN0YXJ0UHJldmlldyksIG9yIHRhc2traWxsIC90IG9uIFdpbmRvd3MuXG4gIHByaXZhdGUga2lsbFByZXZpZXdQcm9jZXNzKHF1YXJ0b1Byb2Nlc3M6IENoaWxkUHJvY2Vzcyk6IHZvaWQge1xuICAgIGlmIChxdWFydG9Qcm9jZXNzLmtpbGxlZCB8fCBxdWFydG9Qcm9jZXNzLnBpZCA9PT0gdW5kZWZpbmVkKSByZXR1cm47XG4gICAgaWYgKHByb2Nlc3MucGxhdGZvcm0gPT09ICd3aW4zMicpIHtcbiAgICAgIHNwYXduKCd0YXNra2lsbCcsIFsnL3BpZCcsIFN0cmluZyhxdWFydG9Qcm9jZXNzLnBpZCksICcvdCcsICcvZiddKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgdHJ5IHtcbiAgICAgIC8vIE5lZ2F0aXZlIFBJRCB0YXJnZXRzIHRoZSB3aG9sZSBwcm9jZXNzIGdyb3VwLlxuICAgICAgcHJvY2Vzcy5raWxsKC1xdWFydG9Qcm9jZXNzLnBpZCwgJ1NJR1RFUk0nKTtcbiAgICB9IGNhdGNoIHtcbiAgICAgIC8vIEdyb3VwIGFscmVhZHkgZ29uZSwgb3IgbmV2ZXIgYmVjYW1lIGEgbGVhZGVyIOKAlCBiZXN0LWVmZm9ydCBkaXJlY3Qga2lsbC5cbiAgICAgIHRyeSB7XG4gICAgICAgIHF1YXJ0b1Byb2Nlc3Mua2lsbCgnU0lHVEVSTScpO1xuICAgICAgfSBjYXRjaCB7XG4gICAgICAgIC8qIGFscmVhZHkgZGVhZCAqL1xuICAgICAgfVxuICAgIH1cbiAgfVxuXG4gIGFzeW5jIHN0b3BQcmV2aWV3KGZpbGU6IFRGaWxlKSB7XG4gICAgY29uc3QgYWN0aXZlUHJldmlldyA9IHRoaXMuYWN0aXZlUHJldmlld1Byb2Nlc3Nlcy5nZXQoZmlsZS5wYXRoKTtcbiAgICBpZiAoYWN0aXZlUHJldmlldykge1xuICAgICAgdGhpcy5raWxsUHJldmlld1Byb2Nlc3MoYWN0aXZlUHJldmlldy5wcm9jZXNzKTtcbiAgICAgIHRoaXMuYWN0aXZlUHJldmlld1Byb2Nlc3Nlcy5kZWxldGUoZmlsZS5wYXRoKTtcbiAgICAgIG5ldyBOb3RpY2UoJ1F1YXJ0byBwcmV2aWV3IHN0b3BwZWQnKTtcbiAgICB9XG4gIH1cblxuICBzdG9wQWxsUHJldmlld3MoKSB7XG4gICAgY29uc3QgaGFkUHJldmlld3MgPSB0aGlzLmFjdGl2ZVByZXZpZXdQcm9jZXNzZXMuc2l6ZSA+IDA7XG4gICAgdGhpcy5hY3RpdmVQcmV2aWV3UHJvY2Vzc2VzLmZvckVhY2goKGFjdGl2ZVByZXZpZXcsIGZpbGVQYXRoKSA9PiB7XG4gICAgICB0aGlzLmtpbGxQcmV2aWV3UHJvY2VzcyhhY3RpdmVQcmV2aWV3LnByb2Nlc3MpO1xuICAgICAgdGhpcy5hY3RpdmVQcmV2aWV3UHJvY2Vzc2VzLmRlbGV0ZShmaWxlUGF0aCk7XG4gICAgfSk7XG4gICAgaWYgKGhhZFByZXZpZXdzKSB7XG4gICAgICBuZXcgTm90aWNlKCdBbGwgUXVhcnRvIHByZXZpZXdzIHN0b3BwZWQnKTtcbiAgICB9XG4gIH1cblxuICBhc3luYyByZW5kZXJQZGYoZmlsZTogVEZpbGUsIHRvRm9ybWF0PzogJ3BkZicgfCAndHlwc3QnKSB7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IGFic3RyYWN0RmlsZSA9IHRoaXMuYXBwLnZhdWx0LmdldEFic3RyYWN0RmlsZUJ5UGF0aChmaWxlLnBhdGgpO1xuICAgICAgaWYgKCFhYnN0cmFjdEZpbGUgfHwgIShhYnN0cmFjdEZpbGUgaW5zdGFuY2VvZiBURmlsZSkpIHtcbiAgICAgICAgbmV3IE5vdGljZShgRmlsZSAke2ZpbGUucGF0aH0gbm90IGZvdW5kYCk7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cblxuICAgICAgLy8gQSBydW5uaW5nIGBxdWFydG8gcHJldmlld2Aga2VlcHMgcmVjb21waWxpbmcgdGhlIHNhbWUgc291cmNlIGFuZFxuICAgICAgLy8gd3JpdGVzIHRvIG92ZXJsYXBwaW5nIG91dHB1dCBwYXRocy4gU3RvcCBpdCBiZWZvcmUgYSBvbmUtc2hvdFxuICAgICAgLy8gcmVuZGVyIHNvIHRoZSB0d28gUXVhcnRvIHByb2Nlc3NlcyBkbyBub3QgZmlnaHQgb3ZlciB0aGUgb3V0cHV0LlxuICAgICAgaWYgKHRoaXMuYWN0aXZlUHJldmlld1Byb2Nlc3Nlcy5oYXMoZmlsZS5wYXRoKSkge1xuICAgICAgICBhd2FpdCB0aGlzLnN0b3BQcmV2aWV3KGZpbGUpO1xuICAgICAgfVxuXG4gICAgICBjb25zdCBmaWxlUGF0aCA9IHRoaXMuZ2V0VmF1bHRGdWxsUGF0aChhYnN0cmFjdEZpbGUpO1xuICAgICAgaWYgKCFmaWxlUGF0aCkgcmV0dXJuO1xuICAgICAgY29uc3Qgd29ya2luZ0RpciA9IHBhdGguZGlybmFtZShmaWxlUGF0aCk7XG5cbiAgICAgIGNvbnN0IGVudlZhcnM6IE5vZGVKUy5Qcm9jZXNzRW52ID0geyAuLi5wcm9jZXNzLmVudiB9O1xuICAgICAgaWYgKHRoaXMuc2V0dGluZ3MucXVhcnRvVHlwc3QudHJpbSgpKSB7XG4gICAgICAgIGVudlZhcnMuUVVBUlRPX1RZUFNUID0gdGhpcy5zZXR0aW5ncy5xdWFydG9UeXBzdC50cmltKCk7XG4gICAgICB9XG5cbiAgICAgIGNvbnN0IGVuZ2luZUxhYmVsID0gdG9Gb3JtYXQgPT09ICd0eXBzdCcgPyAnVHlwc3QnIDogdG9Gb3JtYXQgPT09ICdwZGYnID8gJ0xhVGVYJyA6ICdmb3JtYXQgZGVmaW5lZCBpbiBZQU1MJztcbiAgICAgIG5ldyBOb3RpY2UoYFJlbmRlcmluZyBRdWFydG8gKCR7ZW5naW5lTGFiZWx9KS4uLmApO1xuXG4gICAgICAvLyBCZXN0LWd1ZXNzIHBhdGggdXNlZCBmb3IgdGhlIHByZS1yZW5kZXIgbGVhZi1jYXB0dXJlIChzbyB3ZSBjYW5cbiAgICAgIC8vIHJldXNlIGFuIGV4aXN0aW5nIFBERiB0YWIgb24gcmVjb21waWxlKS4gVGhlIGF1dGhvcml0YXRpdmUgcGF0aFxuICAgICAgLy8gY29tZXMgZnJvbSBxdWFydG8ncyBcIk91dHB1dCBjcmVhdGVkOlwiIHN0ZG91dCBsaW5lLCBwYXJzZWQgYmVsb3cuXG4gICAgICBjb25zdCBndWVzc2VkUGRmUGF0aCA9IHRoaXMucGRmUGF0aEZvcihmaWxlKTtcbiAgICAgIGNvbnN0IGV4aXN0aW5nTGVhZiA9IHRoaXMuYXBwLndvcmtzcGFjZVxuICAgICAgICAuZ2V0TGVhdmVzT2ZUeXBlKCdwZGYnKVxuICAgICAgICAuZmluZCgobCkgPT4gdGhpcy5sZWFmRmlsZShsKT8ucGF0aCA9PT0gZ3Vlc3NlZFBkZlBhdGgpO1xuXG4gICAgICBjb25zdCBhcmdzID0gWydyZW5kZXInLCBmaWxlUGF0aF07XG4gICAgICBpZiAodG9Gb3JtYXQpIGFyZ3MucHVzaCgnLS10bycsIHRvRm9ybWF0KTtcblxuICAgICAgY29uc3QgcXVhcnRvUHJvY2VzcyA9IHNwYXduKHRoaXMuc2V0dGluZ3MucXVhcnRvUGF0aCwgYXJncywge1xuICAgICAgICBjd2Q6IHdvcmtpbmdEaXIsXG4gICAgICAgIGVudjogZW52VmFycyxcbiAgICAgIH0pO1xuXG4gICAgICBsZXQgZGV0ZWN0ZWRPdXRwdXRCYXNlbmFtZTogc3RyaW5nIHwgbnVsbCA9IG51bGw7XG4gICAgICAvLyBRdWFydG8gcHJpbnRzIHRoZSBodW1hbi1yZWFkYWJsZSBjYXVzZSBvbiBcIkVSUk9SOlwiIGxpbmVzIChiYWQgWUFNTCxcbiAgICAgIC8vIG1pc3NpbmcgZW5naW5lLCBldGMuKS4gS2VlcCB0aGVtIHNvIGEgZmFpbGluZyBjbG9zZSBjYW4gc3VyZmFjZSB0aGVcbiAgICAgIC8vIHJlYWwgcmVhc29uIGluIHRoZSBOb3RpY2UgaW5zdGVhZCBvZiBhIGJhcmUgZXhpdCBjb2RlLlxuICAgICAgY29uc3QgZXJyb3JMaW5lczogc3RyaW5nW10gPSBbXTtcblxuICAgICAgLy8gUGVyLWxpbmUgaGFuZGxlcjogbG9nIHRoZSBsaW5lLCB0aGVuIHdhdGNoIGZvciBcIk91dHB1dCBjcmVhdGVkOlwiLlxuICAgICAgY29uc3QgaGFuZGxlUmVuZGVyTGluZSA9IChsaW5lOiBzdHJpbmcpID0+IHtcbiAgICAgICAgbG9nUXVhcnRvTGluZSgnUXVhcnRvJywgbGluZSk7XG4gICAgICAgIGNvbnN0IG1hdGNoID0gbGluZS5tYXRjaCgvT3V0cHV0IGNyZWF0ZWQ6XFxzKiguKz8pXFxzKiQvKTtcbiAgICAgICAgaWYgKG1hdGNoKSB7XG4gICAgICAgICAgZGV0ZWN0ZWRPdXRwdXRCYXNlbmFtZSA9IHBhdGguYmFzZW5hbWUobWF0Y2hbMV0udHJpbSgpKTtcbiAgICAgICAgfVxuICAgICAgICBpZiAoL15FUlJPUjovLnRlc3QobGluZSkpIHtcbiAgICAgICAgICBlcnJvckxpbmVzLnB1c2gobGluZSk7XG4gICAgICAgIH1cbiAgICAgIH07XG5cbiAgICAgIC8vIE9uZSBidWZmZXJlZCBwcm9jZXNzb3IgcGVyIHN0cmVhbSDigJQgc3Rkb3V0IGFuZCBzdGRlcnIgZWFjaFxuICAgICAgLy8gbmVlZCB0aGVpciBvd24gcGFydGlhbC1saW5lIGJ1ZmZlciwgb3IgaW50ZXJsZWF2ZWQgZnJhZ21lbnRzXG4gICAgICAvLyBmcm9tIHRoZSB0d28gc3RyZWFtcyB3b3VsZCBiZSBzcGxpY2VkIGludG8gc3ludGhldGljIGxpbmVzLlxuICAgICAgY29uc3QgcmVuZGVyU3Rkb3V0ID0gbWFrZUxpbmVQcm9jZXNzb3IoaGFuZGxlUmVuZGVyTGluZSk7XG4gICAgICBjb25zdCByZW5kZXJTdGRlcnIgPSBtYWtlTGluZVByb2Nlc3NvcihoYW5kbGVSZW5kZXJMaW5lKTtcbiAgICAgIHF1YXJ0b1Byb2Nlc3Muc3Rkb3V0Py5vbignZGF0YScsIChkYXRhOiBCdWZmZXIpID0+IHJlbmRlclN0ZG91dChkYXRhLnRvU3RyaW5nKCkpKTtcbiAgICAgIHF1YXJ0b1Byb2Nlc3Muc3RkZXJyPy5vbignZGF0YScsIChkYXRhOiBCdWZmZXIpID0+IHJlbmRlclN0ZGVycihkYXRhLnRvU3RyaW5nKCkpKTtcblxuICAgICAgLy8gY2hpbGRfcHJvY2Vzcy5zcGF3biBkb2VzIG5vdCB0aHJvdyBvbiBhIG1pc3NpbmcgYmluYXJ5OyBpdCBlbWl0c1xuICAgICAgLy8gYW4gJ2Vycm9yJyBldmVudCBsYXRlci4gV2l0aG91dCB0aGlzIGxpc3RlbmVyIGFuIEVOT0VOVCBqdXN0XG4gICAgICAvLyBwcm9kdWNlZCBhIHNpbGVudCBcImV4aXQgMVwiIGNsb3NlIHdpdGggbm8gb3V0cHV0IHRvIGNvbnNvbGUuXG4gICAgICBxdWFydG9Qcm9jZXNzLm9uKCdlcnJvcicsIChlcnIpID0+IHtcbiAgICAgICAgY29uc29sZS5lcnJvcignW3FtZC1hcy1tZF0gRmFpbGVkIHRvIHNwYXduIHF1YXJ0byBmb3IgcmVuZGVyOicsIGVycik7XG4gICAgICAgIG5ldyBOb3RpY2UoXG4gICAgICAgICAgYEZhaWxlZCB0byBzcGF3biAnJHt0aGlzLnNldHRpbmdzLnF1YXJ0b1BhdGh9JzogJHtlcnIubWVzc2FnZX0uIGAgK1xuICAgICAgICAgICAgJ0NoZWNrIHRoZSBRdWFydG8gcGF0aCBzZXR0aW5nIGFuZCB0aGF0IFF1YXJ0byBpcyBvbiBQQVRILidcbiAgICAgICAgKTtcbiAgICAgIH0pO1xuXG4gICAgICBxdWFydG9Qcm9jZXNzLm9uKCdjbG9zZScsIChjb2RlOiBudW1iZXIgfCBudWxsLCBzaWduYWw6IE5vZGVKUy5TaWduYWxzIHwgbnVsbCkgPT4ge1xuICAgICAgICB2b2lkIChhc3luYyAoKSA9PiB7XG4gICAgICAgICAgcmVuZGVyU3Rkb3V0LmZsdXNoKCk7IC8vIHJlbGVhc2UgYW55IGZpbmFsIHBhcnRpYWwgbGluZVxuICAgICAgICAgIHJlbmRlclN0ZGVyci5mbHVzaCgpO1xuXG4gICAgICAgICAgLy8gQSBjbGVhbiBleGl0IGlzIGNvZGUgMC4gQW55dGhpbmcgZWxzZSBpcyBhIGZhaWx1cmUsIGV4Y2VwdCBhXG4gICAgICAgICAgLy8gdGVybWluYXRpb24gYnkgU0lHVEVSTS9TSUdLSUxMIOKAlCB0aGF0IG1lYW5zIHRoZSBwcm9jZXNzIHdhc1xuICAgICAgICAgIC8vIGludGVudGlvbmFsbHkgY2FuY2VsbGVkIChtYXRjaGluZyB0aGUgcHJldmlldyBoYW5kbGVyLCB3aGljaFxuICAgICAgICAgIC8vIHN1cHByZXNzZXMgbm90aWNlcyBmb3IgdGhvc2Ugc2lnbmFscykuIFN0YXkgcXVpZXQgdGhlbi5cbiAgICAgICAgICBpZiAoY29kZSA9PT0gMCkge1xuICAgICAgICAgICAgLy8gZmFsbCB0aHJvdWdoIHRvIHRoZSBzdWNjZXNzIHBhdGggYmVsb3dcbiAgICAgICAgICB9IGVsc2UgaWYgKGNvZGUgPT09IG51bGwgJiYgKHNpZ25hbCA9PT0gJ1NJR1RFUk0nIHx8IHNpZ25hbCA9PT0gJ1NJR0tJTEwnKSkge1xuICAgICAgICAgICAgY29uc29sZS5lcnJvcihgW3FtZC1hcy1tZF0gUXVhcnRvIHJlbmRlciBjYW5jZWxsZWQgKCR7c2lnbmFsfSkuYCk7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIGNvbnN0IGV4aXRMYWJlbCA9IGNvZGUgIT09IG51bGxcbiAgICAgICAgICAgICAgPyBgZXhpdCAke2NvZGV9YFxuICAgICAgICAgICAgICA6IHNpZ25hbFxuICAgICAgICAgICAgICAgID8gYHRlcm1pbmF0ZWQgYnkgJHtzaWduYWx9YFxuICAgICAgICAgICAgICAgIDogJ3Rlcm1pbmF0ZWQnO1xuICAgICAgICAgICAgLy8gVGhlIGZ1bGwgb3V0cHV0IHdhcyBhbHJlYWR5IHN0cmVhbWVkIGxpbmUtYnktbGluZSB0aHJvdWdoXG4gICAgICAgICAgICAvLyBjb25zb2xlLmxvZyAvIGNvbnNvbGUuZXJyb3IgYXMgaXQgYXJyaXZlZCDigJQgbm8gbmVlZCB0b1xuICAgICAgICAgICAgLy8gcmUtZHVtcCBpdC4gU3VyZmFjZSB0aGUgYWN0dWFsIEVSUk9SOiBsaW5lKHMpIGluIHRoZSBOb3RpY2Ugc29cbiAgICAgICAgICAgIC8vIHRoZSB1c2VyIHNlZXMgdGhlIGNhdXNlIChiYWQgWUFNTCwgbWlzc2luZyBlbmdpbmUsIC4uLikgd2l0aG91dFxuICAgICAgICAgICAgLy8gaGF2aW5nIHRvIG9wZW4gdGhlIGRldmVsb3BlciBjb25zb2xlLlxuICAgICAgICAgICAgY29uc29sZS5lcnJvcihgW3FtZC1hcy1tZF0gUXVhcnRvIHJlbmRlciBmYWlsZWQgKCR7ZXhpdExhYmVsfSkuYCk7XG4gICAgICAgICAgICBjb25zdCByZWFzb24gPSBlcnJvckxpbmVzLmxlbmd0aCA+IDBcbiAgICAgICAgICAgICAgPyBlcnJvckxpbmVzLmpvaW4oJ1xcbicpXG4gICAgICAgICAgICAgIDogJ0NoZWNrIHRoZSBkZXZlbG9wZXIgY29uc29sZSBmb3IgZGV0YWlscy4nO1xuICAgICAgICAgICAgbmV3IE5vdGljZShgUXVhcnRvIHJlbmRlciBmYWlsZWQgKCR7ZXhpdExhYmVsfSkuXFxuJHtyZWFzb259YCwgMTUwMDApO1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgIH1cblxuICAgICAgICAgIGNvbnN0IHNvdXJjZURpciA9IGZpbGUucGFyZW50Py5wYXRoID8/ICcnO1xuICAgICAgICAgIGNvbnN0IG91dHB1dFZhdWx0UGF0aCA9IG5vcm1hbGl6ZVBhdGgoXG4gICAgICAgICAgICBkZXRlY3RlZE91dHB1dEJhc2VuYW1lXG4gICAgICAgICAgICAgID8gKHNvdXJjZURpciA/IGAke3NvdXJjZURpcn0vJHtkZXRlY3RlZE91dHB1dEJhc2VuYW1lfWAgOiBkZXRlY3RlZE91dHB1dEJhc2VuYW1lKVxuICAgICAgICAgICAgICA6IGd1ZXNzZWRQZGZQYXRoXG4gICAgICAgICAgKTtcblxuICAgICAgICAgIGNvbnN0IG91dHB1dFRGaWxlID0gYXdhaXQgdGhpcy53YWl0Rm9yVmF1bHRGaWxlKG91dHB1dFZhdWx0UGF0aCk7XG5cbiAgICAgICAgICBpZiAoIW91dHB1dFRGaWxlKSB7XG4gICAgICAgICAgICBuZXcgTm90aWNlKFxuICAgICAgICAgICAgICBgUXVhcnRvIHJlbmRlcmVkLCBidXQgJHtvdXRwdXRWYXVsdFBhdGh9IGRpZCBub3QgYXBwZWFyIGluIHRoZSB2YXVsdCB3aXRoaW4gdGhlIHRpbWVvdXQuIENoZWNrIFF1YXJ0bydzIG91dHB1dC1kaXIgb3IgdmF1bHQgc3luYy5gXG4gICAgICAgICAgICApO1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgIH1cblxuICAgICAgICAgIGNvbnN0IGlzUGRmID0gb3V0cHV0VmF1bHRQYXRoLnRvTG93ZXJDYXNlKCkuZW5kc1dpdGgoJy5wZGYnKTtcblxuICAgICAgICAgIGlmICghdGhpcy5zZXR0aW5ncy5vcGVuUGRmSW5PYnNpZGlhbiB8fCAhaXNQZGYpIHtcbiAgICAgICAgICAgIG5ldyBOb3RpY2UoXG4gICAgICAgICAgICAgIGlzUGRmXG4gICAgICAgICAgICAgICAgPyBgUERGIHJlbmRlcmVkOiAke291dHB1dFZhdWx0UGF0aH1gXG4gICAgICAgICAgICAgICAgOiBgUmVuZGVyZWQ6ICR7b3V0cHV0VmF1bHRQYXRofSAoT2JzaWRpYW4ncyBidWlsdC1pbiB2aWV3ZXIgb25seSBoYW5kbGVzIFBERnMpLmBcbiAgICAgICAgICAgICk7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgfVxuXG4gICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIGNvbnN0IGxlYWYgPSBleGlzdGluZ0xlYWY/LnBhcmVudCAhPSBudWxsXG4gICAgICAgICAgICAgID8gZXhpc3RpbmdMZWFmXG4gICAgICAgICAgICAgIDogdGhpcy5hcHAud29ya3NwYWNlLmdldExlYWYoJ3NwbGl0JywgJ3ZlcnRpY2FsJyk7XG4gICAgICAgICAgICBhd2FpdCBsZWFmLm9wZW5GaWxlKG91dHB1dFRGaWxlLCB7IGFjdGl2ZTogZmFsc2UgfSk7XG4gICAgICAgICAgICBhd2FpdCB0aGlzLmFwcC53b3Jrc3BhY2UucmV2ZWFsTGVhZihsZWFmKTtcbiAgICAgICAgICAgIG5ldyBOb3RpY2UoYE9wZW5lZCAke291dHB1dFZhdWx0UGF0aH1gKTtcbiAgICAgICAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoJ0ZhaWxlZCB0byBvcGVuIFBERiBpbiBPYnNpZGlhbjonLCBlcnIpO1xuICAgICAgICAgICAgbmV3IE5vdGljZShcbiAgICAgICAgICAgICAgYFBERiByZW5kZXJlZCBhdCAke291dHB1dFZhdWx0UGF0aH0sIGJ1dCBPYnNpZGlhbiBjb3VsZCBub3Qgb3BlbiBpdCAobm8gUERGIHZpZXdlciByZWdpc3RlcmVkPykuYFxuICAgICAgICAgICAgKTtcbiAgICAgICAgICB9XG4gICAgICAgIH0pKCk7XG4gICAgICB9KTtcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgY29uc29sZS5lcnJvcignRmFpbGVkIHRvIHJlbmRlciBRdWFydG8gUERGOicsIGVycm9yKTtcbiAgICAgIG5ldyBOb3RpY2UoJ0ZhaWxlZCB0byByZW5kZXIgUXVhcnRvIFBERicpO1xuICAgIH1cbiAgfVxuXG4gIGFzeW5jIHdhaXRGb3JWYXVsdEZpbGUodmF1bHRQYXRoOiBzdHJpbmcsIHRpbWVvdXRNcyA9IDUwMDApOiBQcm9taXNlPFRGaWxlIHwgbnVsbD4ge1xuICAgIGNvbnN0IHN0YXJ0ID0gRGF0ZS5ub3coKTtcbiAgICB3aGlsZSAoRGF0ZS5ub3coKSAtIHN0YXJ0IDwgdGltZW91dE1zKSB7XG4gICAgICBjb25zdCBmID0gdGhpcy5hcHAudmF1bHQuZ2V0QWJzdHJhY3RGaWxlQnlQYXRoKHZhdWx0UGF0aCk7XG4gICAgICBpZiAoZiBpbnN0YW5jZW9mIFRGaWxlKSByZXR1cm4gZjtcbiAgICAgIGF3YWl0IG5ldyBQcm9taXNlKChyKSA9PiBhY3RpdmVXaW5kb3cuc2V0VGltZW91dChyLCAyMDApKTtcbiAgICB9XG4gICAgcmV0dXJuIG51bGw7XG4gIH1cbn1cblxuLy8gU2lkZWJhciBvdXRsaW5lIGZvciB0aGUgYWN0aXZlIC5xbWQgZmlsZS4gUmUtcmVuZGVycyBvbiBkZW1hbmQgKHRoZVxuLy8gcGx1Z2luIHdpcmVzIGl0IHRvIGFjdGl2ZS1sZWFmLWNoYW5nZSBhbmQgZWRpdG9yLWNoYW5nZSkuIEFjdGl2ZS1maWxlXG4vLyBvbmx5IGJ5IGRlc2lnbiDigJQgUXVhcnRvIGB7ezwgaW5jbHVkZSA+fX1gIHRhcmdldHMgYXJlIG5vdCByZXNvbHZlZC5cbmNsYXNzIFFtZE91dGxpbmVWaWV3IGV4dGVuZHMgSXRlbVZpZXcge1xuICBwbHVnaW46IFFtZEFzTWRQbHVnaW47XG5cbiAgY29uc3RydWN0b3IobGVhZjogV29ya3NwYWNlTGVhZiwgcGx1Z2luOiBRbWRBc01kUGx1Z2luKSB7XG4gICAgc3VwZXIobGVhZik7XG4gICAgdGhpcy5wbHVnaW4gPSBwbHVnaW47XG4gIH1cblxuICBnZXRWaWV3VHlwZSgpOiBzdHJpbmcge1xuICAgIHJldHVybiBRTURfT1VUTElORV9WSUVXO1xuICB9XG5cbiAgZ2V0RGlzcGxheVRleHQoKTogc3RyaW5nIHtcbiAgICByZXR1cm4gJ1F1YXJ0byBvdXRsaW5lJztcbiAgfVxuXG4gIGdldEljb24oKTogc3RyaW5nIHtcbiAgICByZXR1cm4gJ2xpc3QnO1xuICB9XG5cbiAgYXN5bmMgb25PcGVuKCk6IFByb21pc2U8dm9pZD4ge1xuICAgIC8vIFRoZSBvdXRsaW5lIG1heSBhbHJlYWR5IGJlIHRoZSBhY3RpdmUgbGVhZiBhdCB0aGlzIHBvaW50IChvcGVuZWQgdmlhXG4gICAgLy8gY29tbWFuZC9zZXR0aW5nKSwgc28gY2FwdHVyZSB0aGUgdW5kZXJseWluZyAucW1kIGJlZm9yZSByZW5kZXJpbmcuXG4gICAgdGhpcy5wbHVnaW4udHJhY2tBY3RpdmVRdWFydG9GaWxlKCk7XG4gICAgdGhpcy5yZW5kZXIoKTtcbiAgfVxuXG4gIC8vIEZpbmQgdGhlIG9wZW4gbWFya2Rvd24gdmlldyBmb3IgYSBmaWxlLCByZWdhcmRsZXNzIG9mIHdoaWNoIGxlYWYgaXNcbiAgLy8gYWN0aXZlLiAucW1kIGZpbGVzIG9wZW4gYXMgJ21hcmtkb3duJyBsZWF2ZXMgKHJlZ2lzdGVyRXh0ZW5zaW9ucykuXG4gIHByaXZhdGUgbWFya2Rvd25WaWV3Rm9yKGZpbGU6IFRGaWxlKTogTWFya2Rvd25WaWV3IHwgbnVsbCB7XG4gICAgZm9yIChjb25zdCBsZWFmIG9mIHRoaXMuYXBwLndvcmtzcGFjZS5nZXRMZWF2ZXNPZlR5cGUoJ21hcmtkb3duJykpIHtcbiAgICAgIGlmIChsZWFmLnZpZXcgaW5zdGFuY2VvZiBNYXJrZG93blZpZXcgJiYgbGVhZi52aWV3LmZpbGU/LnBhdGggPT09IGZpbGUucGF0aCkge1xuICAgICAgICByZXR1cm4gbGVhZi52aWV3O1xuICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gbnVsbDtcbiAgfVxuXG4gIHJlbmRlcigpOiB2b2lkIHtcbiAgICBjb25zdCBjb250YWluZXIgPSB0aGlzLmNvbnRlbnRFbDtcbiAgICBjb250YWluZXIuZW1wdHkoKTtcbiAgICBjb250YWluZXIuYWRkQ2xhc3MoJ3FtZC1vdXRsaW5lJyk7XG5cbiAgICBjb25zdCBmaWxlID0gdGhpcy5wbHVnaW4ubGFzdEFjdGl2ZVF1YXJ0b0ZpbGU7XG4gICAgaWYgKCFmaWxlKSB7XG4gICAgICBjb250YWluZXIuY3JlYXRlRGl2KHtcbiAgICAgICAgY2xzOiAncW1kLW91dGxpbmUtZW1wdHknLFxuICAgICAgICB0ZXh0OiAnTm8gUXVhcnRvICgucW1kKSBmaWxlIGlzIGFjdGl2ZS4nLFxuICAgICAgfSk7XG4gICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgLy8gUmVhZCBsaXZlIGNvbnRlbnQgZnJvbSB0aGUgb3BlbiBlZGl0b3IgcmF0aGVyIHRoYW4gdGhlIGFjdGl2ZSBsZWFmIOKAlFxuICAgIC8vIGNsaWNraW5nIGluc2lkZSB0aGlzIHNpZGViYXIgbWFrZXMgaXQgdGhlIGFjdGl2ZSBsZWFmLlxuICAgIGNvbnN0IG1kVmlldyA9IHRoaXMubWFya2Rvd25WaWV3Rm9yKGZpbGUpO1xuICAgIGlmICghbWRWaWV3KSB7XG4gICAgICBjb250YWluZXIuY3JlYXRlRGl2KHtcbiAgICAgICAgY2xzOiAncW1kLW91dGxpbmUtZW1wdHknLFxuICAgICAgICB0ZXh0OiBgT3BlbiAke2ZpbGUubmFtZX0gdG8gc2VlIGl0cyBvdXRsaW5lLmAsXG4gICAgICB9KTtcbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICBjb25zdCBoZWFkaW5ncyA9IHBhcnNlUW1kSGVhZGluZ3MobWRWaWV3LmVkaXRvci5nZXRWYWx1ZSgpKTtcbiAgICBpZiAoaGVhZGluZ3MubGVuZ3RoID09PSAwKSB7XG4gICAgICBjb250YWluZXIuY3JlYXRlRGl2KHtcbiAgICAgICAgY2xzOiAncW1kLW91dGxpbmUtZW1wdHknLFxuICAgICAgICB0ZXh0OiAnTm8gaGVhZGluZ3MgaW4gdGhpcyBmaWxlLicsXG4gICAgICB9KTtcbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICBjb25zdCBsaXN0ID0gY29udGFpbmVyLmNyZWF0ZURpdih7IGNsczogJ3FtZC1vdXRsaW5lLWxpc3QnIH0pO1xuICAgIGZvciAoY29uc3QgaGVhZGluZyBvZiBoZWFkaW5ncykge1xuICAgICAgY29uc3QgaXRlbSA9IGxpc3QuY3JlYXRlRGl2KHtcbiAgICAgICAgY2xzOiAncW1kLW91dGxpbmUtaXRlbScsXG4gICAgICAgIHRleHQ6IGhlYWRpbmcudGV4dCxcbiAgICAgICAgLy8gS2V5Ym9hcmQtYWNjZXNzaWJsZTogZm9jdXNhYmxlLCBhbm5vdW5jZWQgYXMgYSBsaW5rLCBhbmQgdGhlXG4gICAgICAgIC8vIGtleWRvd24gaGFuZGxlciBiZWxvdyBtYWtlcyBFbnRlci9TcGFjZSBhY3RpdmF0ZSBpdC5cbiAgICAgICAgYXR0cjogeyB0YWJpbmRleDogJzAnLCByb2xlOiAnbGluaycgfSxcbiAgICAgIH0pO1xuICAgICAgLy8gSW5kZW50YXRpb24gaXMgZHJpdmVuIGJ5IENTUyBvZmYgdGhpcyBhdHRyaWJ1dGUg4oCUIG5vIGlubGluZSBzdHlsZXMuXG4gICAgICBpdGVtLmRhdGFzZXQubGV2ZWwgPSBTdHJpbmcoaGVhZGluZy5sZXZlbCk7XG5cbiAgICAgIGNvbnN0IGp1bXBUbyA9ICgpID0+IHtcbiAgICAgICAgLy8gUmVzb2x2ZSB0aGUgZWRpdG9yIGJ5IGZpbGUsIG5vdCBieSBcImFjdGl2ZSBsZWFmXCIg4oCUIHRoZSBjbGlja1xuICAgICAgICAvLyBpdHNlbGYganVzdCBtb3ZlZCBmb2N1cyB0byB0aGlzIHNpZGViYXIuXG4gICAgICAgIGNvbnN0IHZpZXcgPSB0aGlzLm1hcmtkb3duVmlld0ZvcihmaWxlKTtcbiAgICAgICAgaWYgKCF2aWV3KSByZXR1cm47XG4gICAgICAgIGNvbnN0IHBvcyA9IHsgbGluZTogaGVhZGluZy5saW5lLCBjaDogMCB9O1xuICAgICAgICB0aGlzLmFwcC53b3Jrc3BhY2Uuc2V0QWN0aXZlTGVhZih2aWV3LmxlYWYsIHsgZm9jdXM6IHRydWUgfSk7XG4gICAgICAgIHZpZXcuZWRpdG9yLnNldEN1cnNvcihwb3MpO1xuICAgICAgICB2aWV3LmVkaXRvci5zY3JvbGxJbnRvVmlldyh7IGZyb206IHBvcywgdG86IHBvcyB9LCB0cnVlKTtcbiAgICAgICAgdmlldy5lZGl0b3IuZm9jdXMoKTtcbiAgICAgIH07XG5cbiAgICAgIGl0ZW0uYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCBqdW1wVG8pO1xuICAgICAgaXRlbS5hZGRFdmVudExpc3RlbmVyKCdrZXlkb3duJywgKGV2dCkgPT4ge1xuICAgICAgICBpZiAoZXZ0LmtleSA9PT0gJ0VudGVyJyB8fCBldnQua2V5ID09PSAnICcpIHtcbiAgICAgICAgICBldnQucHJldmVudERlZmF1bHQoKTtcbiAgICAgICAgICBqdW1wVG8oKTtcbiAgICAgICAgfVxuICAgICAgfSk7XG4gICAgfVxuICB9XG59XG5cbmNvbnN0IHlhbWxIaWdobGlnaHRGaWVsZCA9IFN0YXRlRmllbGQuZGVmaW5lPERlY29yYXRpb25TZXQ+KHtcbiAgY3JlYXRlKHN0YXRlKTogRGVjb3JhdGlvblNldCB7XG4gICAgcmV0dXJuIGJ1aWxkWWFtbERlY29yYXRpb25zKHN0YXRlLmRvYyk7XG4gIH0sXG4gIHVwZGF0ZShkZWNvcmF0aW9ucywgdHJhbnNhY3Rpb24pOiBEZWNvcmF0aW9uU2V0IHtcbiAgICBpZiAodHJhbnNhY3Rpb24uZG9jQ2hhbmdlZCkge1xuICAgICAgcmV0dXJuIGJ1aWxkWWFtbERlY29yYXRpb25zKHRyYW5zYWN0aW9uLnN0YXRlLmRvYyk7XG4gICAgfVxuICAgIHJldHVybiBkZWNvcmF0aW9ucy5tYXAodHJhbnNhY3Rpb24uY2hhbmdlcyk7XG4gIH0sXG4gIHByb3ZpZGU6IChmaWVsZCkgPT4gRWRpdG9yVmlldy5kZWNvcmF0aW9ucy5mcm9tKGZpZWxkKSxcbn0pO1xuXG5mdW5jdGlvbiBidWlsZFlhbWxEZWNvcmF0aW9ucyhkb2M6IFRleHQpOiBEZWNvcmF0aW9uU2V0IHtcbiAgY29uc3QgYnVpbGRlciA9IG5ldyBSYW5nZVNldEJ1aWxkZXI8RGVjb3JhdGlvbj4oKTtcbiAgZm9yIChsZXQgbGluZU51bWJlciA9IDE7IGxpbmVOdW1iZXIgPD0gZG9jLmxpbmVzOyBsaW5lTnVtYmVyKyspIHtcbiAgICBjb25zdCBsaW5lID0gZG9jLmxpbmUobGluZU51bWJlcik7XG4gICAgZGVjb3JhdGVZYW1sTGluZShidWlsZGVyLCBsaW5lLmZyb20sIGxpbmUudGV4dCk7XG4gIH1cbiAgcmV0dXJuIGJ1aWxkZXIuZmluaXNoKCk7XG59XG5cbmZ1bmN0aW9uIGRlY29yYXRlWWFtbExpbmUoYnVpbGRlcjogUmFuZ2VTZXRCdWlsZGVyPERlY29yYXRpb24+LCBsaW5lU3RhcnQ6IG51bWJlciwgbGluZTogc3RyaW5nKTogdm9pZCB7XG4gIGNvbnN0IGluZGVudCA9IGxpbmUubWF0Y2goL15cXHMqLyk/LlswXSA/PyAnJztcbiAgY29uc3QgY29udGVudCA9IGxpbmUuc2xpY2UoaW5kZW50Lmxlbmd0aCk7XG4gIGNvbnN0IGNvbnRlbnRTdGFydCA9IGxpbmVTdGFydCArIGluZGVudC5sZW5ndGg7XG4gIGlmICghY29udGVudCkgcmV0dXJuO1xuXG4gIGlmIChjb250ZW50LnN0YXJ0c1dpdGgoJyMnKSkge1xuICAgIG1hcmtZYW1sVG9rZW4oYnVpbGRlciwgY29udGVudFN0YXJ0LCBsaW5lU3RhcnQgKyBsaW5lLmxlbmd0aCwgJ3FtZC15YW1sLWNvbW1lbnQnKTtcbiAgICByZXR1cm47XG4gIH1cblxuICBjb25zdCBtYXJrZXJNYXRjaCA9IGNvbnRlbnQubWF0Y2goL14oLVxccyspKC4qKSQvKTtcbiAgaWYgKG1hcmtlck1hdGNoKSB7XG4gICAgY29uc3QgbWFya2VyTGVuZ3RoID0gbWFya2VyTWF0Y2hbMV0ubGVuZ3RoO1xuICAgIG1hcmtZYW1sVG9rZW4oYnVpbGRlciwgY29udGVudFN0YXJ0LCBjb250ZW50U3RhcnQgKyBtYXJrZXJMZW5ndGgsICdxbWQteWFtbC1saXN0LW1hcmtlcicpO1xuICAgIGRlY29yYXRlWWFtbFNlZ21lbnQoYnVpbGRlciwgY29udGVudFN0YXJ0ICsgbWFya2VyTGVuZ3RoLCBtYXJrZXJNYXRjaFsyXSk7XG4gICAgcmV0dXJuO1xuICB9XG5cbiAgZGVjb3JhdGVZYW1sU2VnbWVudChidWlsZGVyLCBjb250ZW50U3RhcnQsIGNvbnRlbnQpO1xufVxuXG5mdW5jdGlvbiBkZWNvcmF0ZVlhbWxTZWdtZW50KGJ1aWxkZXI6IFJhbmdlU2V0QnVpbGRlcjxEZWNvcmF0aW9uPiwgc2VnbWVudFN0YXJ0OiBudW1iZXIsIHNlZ21lbnQ6IHN0cmluZyk6IHZvaWQge1xuICBjb25zdCBkb2NNYXRjaCA9IHNlZ21lbnQubWF0Y2goL14oXFwuezN9fC17M30pKFxccyooIy4qKT8pJC8pO1xuICBpZiAoZG9jTWF0Y2gpIHtcbiAgICBjb25zdCBtYXJrZXJMZW5ndGggPSBkb2NNYXRjaFsxXS5sZW5ndGg7XG4gICAgbWFya1lhbWxUb2tlbihidWlsZGVyLCBzZWdtZW50U3RhcnQsIHNlZ21lbnRTdGFydCArIG1hcmtlckxlbmd0aCwgJ3FtZC15YW1sLWRvYy1tYXJrZXInKTtcbiAgICBkZWNvcmF0ZVlhbWxWYWx1ZShidWlsZGVyLCBzZWdtZW50U3RhcnQgKyBtYXJrZXJMZW5ndGgsIGRvY01hdGNoWzJdID8/ICcnKTtcbiAgICByZXR1cm47XG4gIH1cblxuICBjb25zdCBjb2xvbiA9IGZpbmRZYW1sS2V5Q29sb24oc2VnbWVudCk7XG4gIGlmIChjb2xvbiAhPT0gLTEpIHtcbiAgICBtYXJrWWFtbFRva2VuKGJ1aWxkZXIsIHNlZ21lbnRTdGFydCwgc2VnbWVudFN0YXJ0ICsgY29sb24sICdxbWQteWFtbC1rZXknKTtcbiAgICBtYXJrWWFtbFRva2VuKGJ1aWxkZXIsIHNlZ21lbnRTdGFydCArIGNvbG9uLCBzZWdtZW50U3RhcnQgKyBjb2xvbiArIDEsICdxbWQteWFtbC1jb2xvbicpO1xuICAgIGRlY29yYXRlWWFtbFZhbHVlKGJ1aWxkZXIsIHNlZ21lbnRTdGFydCArIGNvbG9uICsgMSwgc2VnbWVudC5zbGljZShjb2xvbiArIDEpKTtcbiAgICByZXR1cm47XG4gIH1cblxuICBkZWNvcmF0ZVlhbWxWYWx1ZShidWlsZGVyLCBzZWdtZW50U3RhcnQsIHNlZ21lbnQpO1xufVxuXG5mdW5jdGlvbiBkZWNvcmF0ZVlhbWxWYWx1ZShidWlsZGVyOiBSYW5nZVNldEJ1aWxkZXI8RGVjb3JhdGlvbj4sIHZhbHVlU3RhcnQ6IG51bWJlciwgdmFsdWU6IHN0cmluZyk6IHZvaWQge1xuICBjb25zdCBsZWFkaW5nID0gdmFsdWUubWF0Y2goL15cXHMqLyk/LlswXSA/PyAnJztcbiAgY29uc3QgcmVzdCA9IHZhbHVlLnNsaWNlKGxlYWRpbmcubGVuZ3RoKTtcbiAgY29uc3QgcmVzdFN0YXJ0ID0gdmFsdWVTdGFydCArIGxlYWRpbmcubGVuZ3RoO1xuICBpZiAoIXJlc3QpIHJldHVybjtcblxuICBjb25zdCBjb21tZW50SW5kZXggPSBmaW5kWWFtbENvbW1lbnQocmVzdCk7XG4gIGNvbnN0IHNjYWxhciA9IGNvbW1lbnRJbmRleCA9PT0gLTEgPyByZXN0IDogcmVzdC5zbGljZSgwLCBjb21tZW50SW5kZXgpO1xuICBkZWNvcmF0ZVlhbWxTY2FsYXIoYnVpbGRlciwgcmVzdFN0YXJ0LCBzY2FsYXIpO1xuICBpZiAoY29tbWVudEluZGV4ICE9PSAtMSkge1xuICAgIG1hcmtZYW1sVG9rZW4oYnVpbGRlciwgcmVzdFN0YXJ0ICsgY29tbWVudEluZGV4LCByZXN0U3RhcnQgKyByZXN0Lmxlbmd0aCwgJ3FtZC15YW1sLWNvbW1lbnQnKTtcbiAgfVxufVxuXG5mdW5jdGlvbiBkZWNvcmF0ZVlhbWxTY2FsYXIoYnVpbGRlcjogUmFuZ2VTZXRCdWlsZGVyPERlY29yYXRpb24+LCBzY2FsYXJTdGFydDogbnVtYmVyLCBzY2FsYXI6IHN0cmluZyk6IHZvaWQge1xuICBjb25zdCB0cmFpbGluZyA9IHNjYWxhci5tYXRjaCgvXFxzKiQvKT8uWzBdID8/ICcnO1xuICBjb25zdCB0b2tlbiA9IHRyYWlsaW5nID8gc2NhbGFyLnNsaWNlKDAsIHNjYWxhci5sZW5ndGggLSB0cmFpbGluZy5sZW5ndGgpIDogc2NhbGFyO1xuICBpZiAoIXRva2VuKSByZXR1cm47XG5cbiAgY29uc3QgY2xhc3NOYW1lID0geWFtbFNjYWxhckNsYXNzKHRva2VuKTtcbiAgbWFya1lhbWxUb2tlbihidWlsZGVyLCBzY2FsYXJTdGFydCwgc2NhbGFyU3RhcnQgKyB0b2tlbi5sZW5ndGgsIGNsYXNzTmFtZSk7XG59XG5cbmZ1bmN0aW9uIHlhbWxTY2FsYXJDbGFzcyh0b2tlbjogc3RyaW5nKTogc3RyaW5nIHtcbiAgaWYgKC9eWydcIl0uKlsnXCJdJC8udGVzdCh0b2tlbikpIHJldHVybiAncW1kLXlhbWwtc3RyaW5nJztcbiAgaWYgKC9eWyYqXVtBLVphLXowLTlfLV0rJC8udGVzdCh0b2tlbikpIHJldHVybiAncW1kLXlhbWwtYW5jaG9yJztcbiAgaWYgKC9eKHRydWV8ZmFsc2V8eWVzfG5vfG9ufG9mZnxudWxsfH4pJC9pLnRlc3QodG9rZW4pKSByZXR1cm4gJ3FtZC15YW1sLWJvb2xlYW4nO1xuICBpZiAoL15bLStdPyg/OlxcZCtcXC4/XFxkKnxcXC5cXGQrKSg/OmVbLStdP1xcZCspPyQvaS50ZXN0KHRva2VuKSkgcmV0dXJuICdxbWQteWFtbC1udW1iZXInO1xuICBpZiAoL15bPnxdWystXT8kLy50ZXN0KHRva2VuKSkgcmV0dXJuICdxbWQteWFtbC1ibG9jayc7XG4gIGlmICgvXihodG1sfHBkZnx0eXBzdHxsYXRleHxiZWFtZXJ8cmV2ZWFsanN8ZG9jeHxvZHR8ZXB1YnxnZm18amF0c3xkYXNoYm9hcmQpJC9pLnRlc3QodG9rZW4pKSB7XG4gICAgcmV0dXJuICdxbWQteWFtbC1xdWFydG8tZm9ybWF0JztcbiAgfVxuICByZXR1cm4gJ3FtZC15YW1sLXNjYWxhcic7XG59XG5cbmZ1bmN0aW9uIGZpbmRZYW1sS2V5Q29sb24oc2VnbWVudDogc3RyaW5nKTogbnVtYmVyIHtcbiAgbGV0IHNpbmdsZVF1b3RlZCA9IGZhbHNlO1xuICBsZXQgZG91YmxlUXVvdGVkID0gZmFsc2U7XG4gIGZvciAobGV0IGkgPSAwOyBpIDwgc2VnbWVudC5sZW5ndGg7IGkrKykge1xuICAgIGNvbnN0IGNoYXIgPSBzZWdtZW50W2ldO1xuICAgIGNvbnN0IHByZXYgPSBpID4gMCA/IHNlZ21lbnRbaSAtIDFdIDogJyc7XG4gICAgaWYgKGNoYXIgPT09IFwiJ1wiICYmICFkb3VibGVRdW90ZWQpIHtcbiAgICAgIHNpbmdsZVF1b3RlZCA9ICFzaW5nbGVRdW90ZWQ7XG4gICAgfSBlbHNlIGlmIChjaGFyID09PSAnXCInICYmICFzaW5nbGVRdW90ZWQgJiYgcHJldiAhPT0gJ1xcXFwnKSB7XG4gICAgICBkb3VibGVRdW90ZWQgPSAhZG91YmxlUXVvdGVkO1xuICAgIH0gZWxzZSBpZiAoY2hhciA9PT0gJzonICYmICFzaW5nbGVRdW90ZWQgJiYgIWRvdWJsZVF1b3RlZCkge1xuICAgICAgY29uc3QgbmV4dCA9IHNlZ21lbnRbaSArIDFdID8/ICcnO1xuICAgICAgY29uc3Qga2V5ID0gc2VnbWVudC5zbGljZSgwLCBpKS50cmltKCk7XG4gICAgICBpZiAoa2V5ICYmICghbmV4dCB8fCAvXFxzLy50ZXN0KG5leHQpKSkgcmV0dXJuIGk7XG4gICAgfVxuICB9XG4gIHJldHVybiAtMTtcbn1cblxuZnVuY3Rpb24gZmluZFlhbWxDb21tZW50KHZhbHVlOiBzdHJpbmcpOiBudW1iZXIge1xuICBsZXQgc2luZ2xlUXVvdGVkID0gZmFsc2U7XG4gIGxldCBkb3VibGVRdW90ZWQgPSBmYWxzZTtcbiAgZm9yIChsZXQgaSA9IDA7IGkgPCB2YWx1ZS5sZW5ndGg7IGkrKykge1xuICAgIGNvbnN0IGNoYXIgPSB2YWx1ZVtpXTtcbiAgICBjb25zdCBwcmV2ID0gaSA+IDAgPyB2YWx1ZVtpIC0gMV0gOiAnJztcbiAgICBpZiAoY2hhciA9PT0gXCInXCIgJiYgIWRvdWJsZVF1b3RlZCkge1xuICAgICAgc2luZ2xlUXVvdGVkID0gIXNpbmdsZVF1b3RlZDtcbiAgICB9IGVsc2UgaWYgKGNoYXIgPT09ICdcIicgJiYgIXNpbmdsZVF1b3RlZCAmJiBwcmV2ICE9PSAnXFxcXCcpIHtcbiAgICAgIGRvdWJsZVF1b3RlZCA9ICFkb3VibGVRdW90ZWQ7XG4gICAgfSBlbHNlIGlmIChjaGFyID09PSAnIycgJiYgIXNpbmdsZVF1b3RlZCAmJiAhZG91YmxlUXVvdGVkICYmIChpID09PSAwIHx8IC9cXHMvLnRlc3QocHJldikpKSB7XG4gICAgICByZXR1cm4gaTtcbiAgICB9XG4gIH1cbiAgcmV0dXJuIC0xO1xufVxuXG5mdW5jdGlvbiBtYXJrWWFtbFRva2VuKFxuICBidWlsZGVyOiBSYW5nZVNldEJ1aWxkZXI8RGVjb3JhdGlvbj4sXG4gIGZyb206IG51bWJlcixcbiAgdG86IG51bWJlcixcbiAgY2xhc3NOYW1lOiBzdHJpbmdcbik6IHZvaWQge1xuICBpZiAodG8gPD0gZnJvbSkgcmV0dXJuO1xuICBidWlsZGVyLmFkZChmcm9tLCB0bywgRGVjb3JhdGlvbi5tYXJrKHsgY2xhc3M6IGNsYXNzTmFtZSB9KSk7XG59XG5cbmNsYXNzIFFtZFlhbWxWaWV3IGV4dGVuZHMgVGV4dEZpbGVWaWV3IHtcbiAgcHJpdmF0ZSBlZGl0b3JWaWV3OiBFZGl0b3JWaWV3IHwgbnVsbCA9IG51bGw7XG4gIHByaXZhdGUgc2V0dGluZ1ZpZXdEYXRhID0gZmFsc2U7XG5cbiAgZ2V0Vmlld1R5cGUoKTogc3RyaW5nIHtcbiAgICByZXR1cm4gUU1EX1lBTUxfVklFVztcbiAgfVxuXG4gIGdldERpc3BsYXlUZXh0KCk6IHN0cmluZyB7XG4gICAgcmV0dXJuIHRoaXMuZmlsZT8ubmFtZSA/PyAnWUFNTCBmaWxlJztcbiAgfVxuXG4gIGdldEljb24oKTogc3RyaW5nIHtcbiAgICByZXR1cm4gJ2ZpbGUtY29kZSc7XG4gIH1cblxuICBvbmxvYWQoKTogdm9pZCB7XG4gICAgc3VwZXIub25sb2FkKCk7XG4gICAgdGhpcy5jb250ZW50RWwuZW1wdHkoKTtcbiAgICB0aGlzLmNvbnRlbnRFbC5hZGRDbGFzcygncW1kLXlhbWwtdmlldycpO1xuICAgIHRoaXMuZWRpdG9yVmlldyA9IG5ldyBFZGl0b3JWaWV3KHtcbiAgICAgIHBhcmVudDogdGhpcy5jb250ZW50RWwsXG4gICAgICBzdGF0ZTogRWRpdG9yU3RhdGUuY3JlYXRlKHtcbiAgICAgICAgZG9jOiB0aGlzLmRhdGEgPz8gJycsXG4gICAgICAgIGV4dGVuc2lvbnM6IFtcbiAgICAgICAgICBFZGl0b3JTdGF0ZS50YWJTaXplLm9mKDIpLFxuICAgICAgICAgIHlhbWxIaWdobGlnaHRGaWVsZCxcbiAgICAgICAgICBFZGl0b3JWaWV3LmNvbnRlbnRBdHRyaWJ1dGVzLm9mKHtcbiAgICAgICAgICAgICdhcmlhLWxhYmVsJzogJ1lBTUwgZmlsZSBjb250ZW50cycsXG4gICAgICAgICAgICBhdXRvY2FwaXRhbGl6ZTogJ29mZicsXG4gICAgICAgICAgICBhdXRvY29tcGxldGU6ICdvZmYnLFxuICAgICAgICAgICAgc3BlbGxjaGVjazogJ2ZhbHNlJyxcbiAgICAgICAgICB9KSxcbiAgICAgICAgICBrZXltYXAub2YoW1xuICAgICAgICAgICAgeyBrZXk6ICdUYWInLCBydW46IGluZGVudE1vcmUgfSxcbiAgICAgICAgICAgIHsga2V5OiAnU2hpZnQtVGFiJywgcnVuOiBpbmRlbnRMZXNzIH0sXG4gICAgICAgICAgXSksXG4gICAgICAgICAgRWRpdG9yVmlldy51cGRhdGVMaXN0ZW5lci5vZigodXBkYXRlKSA9PiB7XG4gICAgICAgICAgICBpZiAoIXVwZGF0ZS5kb2NDaGFuZ2VkIHx8IHRoaXMuc2V0dGluZ1ZpZXdEYXRhKSByZXR1cm47XG4gICAgICAgICAgICB0aGlzLmRhdGEgPSB1cGRhdGUuc3RhdGUuZG9jLnRvU3RyaW5nKCk7XG4gICAgICAgICAgICB0aGlzLnJlcXVlc3RTYXZlKCk7XG4gICAgICAgICAgfSksXG4gICAgICAgIF0sXG4gICAgICB9KSxcbiAgICB9KTtcbiAgICB0aGlzLnJlZ2lzdGVyKCgpID0+IHtcbiAgICAgIHRoaXMuZWRpdG9yVmlldz8uZGVzdHJveSgpO1xuICAgICAgdGhpcy5lZGl0b3JWaWV3ID0gbnVsbDtcbiAgICB9KTtcbiAgfVxuXG4gIGdldFZpZXdEYXRhKCk6IHN0cmluZyB7XG4gICAgcmV0dXJuIHRoaXMuZWRpdG9yVmlldz8uc3RhdGUuZG9jLnRvU3RyaW5nKCkgPz8gdGhpcy5kYXRhID8/ICcnO1xuICB9XG5cbiAgc2V0Vmlld0RhdGEoZGF0YTogc3RyaW5nKTogdm9pZCB7XG4gICAgdGhpcy5kYXRhID0gZGF0YTtcbiAgICBjb25zdCB2aWV3ID0gdGhpcy5lZGl0b3JWaWV3O1xuICAgIGlmICghdmlldykgcmV0dXJuO1xuICAgIGNvbnN0IGN1cnJlbnQgPSB2aWV3LnN0YXRlLmRvYy50b1N0cmluZygpO1xuICAgIGlmIChjdXJyZW50ID09PSBkYXRhKSByZXR1cm47XG4gICAgdGhpcy5zZXR0aW5nVmlld0RhdGEgPSB0cnVlO1xuICAgIHRyeSB7XG4gICAgICB2aWV3LmRpc3BhdGNoKHtcbiAgICAgICAgY2hhbmdlczoge1xuICAgICAgICAgIGZyb206IDAsXG4gICAgICAgICAgdG86IGN1cnJlbnQubGVuZ3RoLFxuICAgICAgICAgIGluc2VydDogZGF0YSxcbiAgICAgICAgfSxcbiAgICAgIH0pO1xuICAgIH0gZmluYWxseSB7XG4gICAgICB0aGlzLnNldHRpbmdWaWV3RGF0YSA9IGZhbHNlO1xuICAgIH1cbiAgfVxuXG4gIGNsZWFyKCk6IHZvaWQge1xuICAgIHRoaXMuc2V0Vmlld0RhdGEoJycpO1xuICB9XG59XG5cbmNsYXNzIFFtZFNldHRpbmdUYWIgZXh0ZW5kcyBQbHVnaW5TZXR0aW5nVGFiIHtcbiAgcGx1Z2luOiBRbWRBc01kUGx1Z2luO1xuXG4gIGNvbnN0cnVjdG9yKGFwcDogQXBwLCBwbHVnaW46IFFtZEFzTWRQbHVnaW4pIHtcbiAgICBzdXBlcihhcHAsIHBsdWdpbik7XG4gICAgdGhpcy5wbHVnaW4gPSBwbHVnaW47XG4gIH1cblxuICBkaXNwbGF5KCk6IHZvaWQge1xuICAgIGNvbnN0IHsgY29udGFpbmVyRWwgfSA9IHRoaXM7XG4gICAgY29udGFpbmVyRWwuZW1wdHkoKTtcblxuICAgIG5ldyBTZXR0aW5nKGNvbnRhaW5lckVsKVxuICAgICAgLnNldE5hbWUoJ1F1YXJ0byBwYXRoJylcbiAgICAgIC5zZXREZXNjKCdQYXRoIHRvIHRoZSBRdWFydG8gZXhlY3V0YWJsZSAoZS5nLiBxdWFydG8sIC91c3IvbG9jYWwvYmluL3F1YXJ0byknKVxuICAgICAgLmFkZFRleHQoKHRleHQpID0+XG4gICAgICAgIHRleHRcbiAgICAgICAgICAuc2V0UGxhY2Vob2xkZXIoJ3F1YXJ0bycpXG4gICAgICAgICAgLnNldFZhbHVlKHRoaXMucGx1Z2luLnNldHRpbmdzLnF1YXJ0b1BhdGgpXG4gICAgICAgICAgLm9uQ2hhbmdlKGFzeW5jICh2YWx1ZSkgPT4ge1xuICAgICAgICAgICAgdGhpcy5wbHVnaW4uc2V0dGluZ3MucXVhcnRvUGF0aCA9IHZhbHVlO1xuICAgICAgICAgICAgYXdhaXQgdGhpcy5wbHVnaW4uc2F2ZVNldHRpbmdzKCk7XG4gICAgICAgICAgfSlcbiAgICAgICk7XG5cbiAgICBuZXcgU2V0dGluZyhjb250YWluZXJFbClcbiAgICAgIC5zZXROYW1lKCdFbmFibGUgZWRpdGluZyBRdWFydG8gZmlsZXMnKVxuICAgICAgLnNldERlc2MoXG4gICAgICAgICdXaGVuIG9uLCAucW1kIGZpbGVzIG9wZW4gaW4gdGhlIE1hcmtkb3duIGVkaXRvci4gVHVybiBvZmYgaWYgYW5vdGhlciBwbHVnaW4gaGFuZGxlcyAucW1kIGVkaXRpbmcuJ1xuICAgICAgKVxuICAgICAgLmFkZFRvZ2dsZSgodG9nZ2xlKSA9PlxuICAgICAgICB0b2dnbGVcbiAgICAgICAgICAuc2V0VmFsdWUodGhpcy5wbHVnaW4uc2V0dGluZ3MuZW5hYmxlUW1kTGlua2luZylcbiAgICAgICAgICAub25DaGFuZ2UoYXN5bmMgKHZhbHVlKSA9PiB7XG4gICAgICAgICAgICB0aGlzLnBsdWdpbi5zZXR0aW5ncy5lbmFibGVRbWRMaW5raW5nID0gdmFsdWU7XG4gICAgICAgICAgICBpZiAodmFsdWUpIHtcbiAgICAgICAgICAgICAgdGhpcy5wbHVnaW4ucmVnaXN0ZXJRbWRFeHRlbnNpb24oKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGF3YWl0IHRoaXMucGx1Z2luLnNhdmVTZXR0aW5ncygpO1xuICAgICAgICAgIH0pXG4gICAgICApO1xuXG4gICAgbmV3IFNldHRpbmcoY29udGFpbmVyRWwpXG4gICAgICAuc2V0TmFtZSgnUVVBUlRPX1RZUFNUIHZhcmlhYmxlJylcbiAgICAgIC5zZXREZXNjKCdWYWx1ZSBmb3IgdGhlIFFVQVJUT19UWVBTVCBlbnZpcm9ubWVudCB2YXJpYWJsZSAobGVhdmUgZW1wdHkgdG8gdW5zZXQpLicpXG4gICAgICAuYWRkVGV4dCgodGV4dCkgPT5cbiAgICAgICAgdGV4dFxuICAgICAgICAgIC5zZXRQbGFjZWhvbGRlcignZS5nLiB0eXBzdF9wYXRoJylcbiAgICAgICAgICAuc2V0VmFsdWUodGhpcy5wbHVnaW4uc2V0dGluZ3MucXVhcnRvVHlwc3QpXG4gICAgICAgICAgLm9uQ2hhbmdlKGFzeW5jICh2YWx1ZSkgPT4ge1xuICAgICAgICAgICAgdGhpcy5wbHVnaW4uc2V0dGluZ3MucXVhcnRvVHlwc3QgPSB2YWx1ZTtcbiAgICAgICAgICAgIGF3YWl0IHRoaXMucGx1Z2luLnNhdmVTZXR0aW5ncygpO1xuICAgICAgICAgIH0pXG4gICAgICApO1xuXG4gICAgbmV3IFNldHRpbmcoY29udGFpbmVyRWwpXG4gICAgICAuc2V0TmFtZSgnT3BlbiBjb21waWxlZCBQREYgaW4gT2JzaWRpYW4nKVxuICAgICAgLnNldERlc2MoXG4gICAgICAgIFwiV2hlbiByZW5kZXJpbmcgdG8gUERGLCBvcGVuIHRoZSByZXN1bHRpbmcgZmlsZSBpbnNpZGUgT2JzaWRpYW4gdXNpbmcgdGhlIGJ1aWx0LWluIFBERiB2aWV3ZXIuIFRoZSAucW1kIHNvdXJjZSBtdXN0IGxpdmUgaW4gdGhlIHZhdWx0IHNvIHRoZSByZW5kZXJlZCBQREYgaXMgYWNjZXNzaWJsZS5cIlxuICAgICAgKVxuICAgICAgLmFkZFRvZ2dsZSgodG9nZ2xlKSA9PlxuICAgICAgICB0b2dnbGVcbiAgICAgICAgICAuc2V0VmFsdWUodGhpcy5wbHVnaW4uc2V0dGluZ3Mub3BlblBkZkluT2JzaWRpYW4pXG4gICAgICAgICAgLm9uQ2hhbmdlKGFzeW5jICh2YWx1ZSkgPT4ge1xuICAgICAgICAgICAgdGhpcy5wbHVnaW4uc2V0dGluZ3Mub3BlblBkZkluT2JzaWRpYW4gPSB2YWx1ZTtcbiAgICAgICAgICAgIGF3YWl0IHRoaXMucGx1Z2luLnNhdmVTZXR0aW5ncygpO1xuICAgICAgICAgIH0pXG4gICAgICApO1xuXG4gICAgbmV3IFNldHRpbmcoY29udGFpbmVyRWwpXG4gICAgICAuc2V0TmFtZSgnT3BlbiBRdWFydG8gcHJldmlldyBpbiBPYnNpZGlhbicpXG4gICAgICAuc2V0RGVzYyhcbiAgICAgICAgJ0RlZmF1bHQgdGFyZ2V0IGZvciB0aGUgZ2VuZXJpYyBUb2dnbGUgUXVhcnRvIHByZXZpZXcgY29tbWFuZCBhbmQgcmliYm9uIGljb24uICcgK1xuICAgICAgICAgIFwiV2hlbiBvbjogUERGIHByZXZpZXdzIChmb3JtYXQ6IHR5cHN0IC8gcGRmKSBvcGVuIGluIE9ic2lkaWFuJ3MgbmF0aXZlIFBERiB2aWV3ZXI7IFwiICtcbiAgICAgICAgICBcIm5vbi1QREYgcHJldmlld3MgKEhUTUwsIGV0Yy4pIG9wZW4gaW4gT2JzaWRpYW4gMS44J3MgYnVpbHQtaW4gd2ViIHZpZXdlci4gXCIgK1xuICAgICAgICAgICdXaGVuIG9mZiwgdGhlIHBsdWdpbiBvcGVucyBRdWFydG9cXCdzIHByZXZpZXcgVVJMIGluIHlvdXIgZGVmYXVsdCBleHRlcm5hbCBicm93c2VyLiAnICtcbiAgICAgICAgICAnVXNlIHRoZSBleHBsaWNpdCBwcmV2aWV3IGNvbW1hbmRzIHRvIGNob29zZSBhIHRhcmdldCB3aXRob3V0IGNoYW5naW5nIHRoaXMgc2V0dGluZy4nXG4gICAgICApXG4gICAgICAuYWRkVG9nZ2xlKCh0b2dnbGUpID0+XG4gICAgICAgIHRvZ2dsZVxuICAgICAgICAgIC5zZXRWYWx1ZSh0aGlzLnBsdWdpbi5zZXR0aW5ncy5wcmV2aWV3SW5PYnNpZGlhbilcbiAgICAgICAgICAub25DaGFuZ2UoYXN5bmMgKHZhbHVlKSA9PiB7XG4gICAgICAgICAgICB0aGlzLnBsdWdpbi5zZXR0aW5ncy5wcmV2aWV3SW5PYnNpZGlhbiA9IHZhbHVlO1xuICAgICAgICAgICAgYXdhaXQgdGhpcy5wbHVnaW4uc2F2ZVNldHRpbmdzKCk7XG4gICAgICAgICAgfSlcbiAgICAgICk7XG5cbiAgICBuZXcgU2V0dGluZyhjb250YWluZXJFbClcbiAgICAgIC5zZXROYW1lKCdQcmV2aWV3IGFuZCByZW5kZXIgTWFya2Rvd24gZmlsZXMgd2l0aCBRdWFydG8nKVxuICAgICAgLnNldERlc2MoXG4gICAgICAgICdXaGVuIG9uLCBRdWFydG8gcHJldmlldyBhbmQgcmVuZGVyIGNvbW1hbmRzIGFsc28gYWNjZXB0IC5tZCBmaWxlcyB0aGF0IGhhdmUgX3F1YXJ0by55bWwgaW4gdGhlaXIgZm9sZGVyIG9yIGFuIGFuY2VzdG9yIHVwIHRvIHRoZSB2YXVsdCByb290LiBMZWF2ZSBvZmYgdG8gcmVzdHJpY3QgY29tbWFuZHMgdG8gLnFtZCBmaWxlcy4nXG4gICAgICApXG4gICAgICAuYWRkVG9nZ2xlKCh0b2dnbGUpID0+XG4gICAgICAgIHRvZ2dsZVxuICAgICAgICAgIC5zZXRWYWx1ZSh0aGlzLnBsdWdpbi5zZXR0aW5ncy5wcmV2aWV3TWFya2Rvd25GaWxlcylcbiAgICAgICAgICAub25DaGFuZ2UoYXN5bmMgKHZhbHVlKSA9PiB7XG4gICAgICAgICAgICB0aGlzLnBsdWdpbi5zZXR0aW5ncy5wcmV2aWV3TWFya2Rvd25GaWxlcyA9IHZhbHVlO1xuICAgICAgICAgICAgYXdhaXQgdGhpcy5wbHVnaW4uc2F2ZVNldHRpbmdzKCk7XG4gICAgICAgICAgfSlcbiAgICAgICk7XG5cbiAgICBuZXcgU2V0dGluZyhjb250YWluZXJFbClcbiAgICAgIC5zZXROYW1lKCdTaG93IFlBTUwgZmlsZXMnKVxuICAgICAgLnNldERlc2MoXG4gICAgICAgICdXaGVuIG9uLCAueW1sIGFuZCAueWFtbCBmaWxlcyBhcHBlYXIgaW4gT2JzaWRpYW4gdXNpbmcgYSBDb2RlTWlycm9yIGVkaXRvciB3aXRoIFF1YXJ0by1vcmllbnRlZCBZQU1MIGhpZ2hsaWdodGluZy4gVHVybiBvZmYgYW5kIHJlbG9hZCB0aGUgcGx1Z2luIHRvIGhpZGUgdGhlbSBhZ2Fpbi4nXG4gICAgICApXG4gICAgICAuYWRkVG9nZ2xlKCh0b2dnbGUpID0+XG4gICAgICAgIHRvZ2dsZVxuICAgICAgICAgIC5zZXRWYWx1ZSh0aGlzLnBsdWdpbi5zZXR0aW5ncy5zaG93WWFtbEZpbGVzKVxuICAgICAgICAgIC5vbkNoYW5nZShhc3luYyAodmFsdWUpID0+IHtcbiAgICAgICAgICAgIHRoaXMucGx1Z2luLnNldHRpbmdzLnNob3dZYW1sRmlsZXMgPSB2YWx1ZTtcbiAgICAgICAgICAgIGlmICh2YWx1ZSkge1xuICAgICAgICAgICAgICB0aGlzLnBsdWdpbi5yZWdpc3RlcllhbWxFeHRlbnNpb25zKCk7XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICBuZXcgTm90aWNlKCdSZWxvYWQgdGhlIHBsdWdpbiB0byBoaWRlIFlBTUwgZmlsZXMgYWdhaW4uJyk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBhd2FpdCB0aGlzLnBsdWdpbi5zYXZlU2V0dGluZ3MoKTtcbiAgICAgICAgICB9KVxuICAgICAgKTtcblxuICAgIG5ldyBTZXR0aW5nKGNvbnRhaW5lckVsKVxuICAgICAgLnNldE5hbWUoJ1Nob3cgUXVhcnRvIG91dGxpbmUnKVxuICAgICAgLnNldERlc2MoXG4gICAgICAgIFwiQWRkIGEgc2lkZWJhciBvdXRsaW5lIG9mIHRoZSBhY3RpdmUgLnFtZCBmaWxlJ3MgaGVhZGluZ3MgKE9ic2lkaWFuJ3MgXCIgK1xuICAgICAgICAgICdjb3JlIE91dGxpbmUgcGFuZWwgY2Fubm90IHJlYWQgLnFtZCBmaWxlcykuIEFjdGl2ZSBmaWxlIG9ubHkg4oCUICcgK1xuICAgICAgICAgICdoZWFkaW5ncyBmcm9tIGluY2x1ZGVkIGZpbGVzIGFyZSBub3QgbGlzdGVkLiBUaGUgXCJPcGVuIFF1YXJ0byAnICtcbiAgICAgICAgICAnb3V0bGluZVwiIGNvbW1hbmQgd29ya3MgcmVnYXJkbGVzcyBvZiB0aGlzIHRvZ2dsZS4nXG4gICAgICApXG4gICAgICAuYWRkVG9nZ2xlKCh0b2dnbGUpID0+XG4gICAgICAgIHRvZ2dsZVxuICAgICAgICAgIC5zZXRWYWx1ZSh0aGlzLnBsdWdpbi5zZXR0aW5ncy5zaG93T3V0bGluZSlcbiAgICAgICAgICAub25DaGFuZ2UoYXN5bmMgKHZhbHVlKSA9PiB7XG4gICAgICAgICAgICB0aGlzLnBsdWdpbi5zZXR0aW5ncy5zaG93T3V0bGluZSA9IHZhbHVlO1xuICAgICAgICAgICAgYXdhaXQgdGhpcy5wbHVnaW4uc2F2ZVNldHRpbmdzKCk7XG4gICAgICAgICAgICBpZiAodmFsdWUpIHtcbiAgICAgICAgICAgICAgYXdhaXQgdGhpcy5wbHVnaW4uYWN0aXZhdGVPdXRsaW5lVmlldygpO1xuICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgdGhpcy5wbHVnaW4uZGV0YWNoT3V0bGluZVZpZXdzKCk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfSlcbiAgICAgICk7XG4gIH1cbn1cbiJdLCJuYW1lcyI6WyJQbHVnaW4iLCJkZWJvdW5jZSIsIk5vdGljZSIsIm5vcm1hbGl6ZVBhdGgiLCJURmlsZSIsIk1hcmtkb3duVmlldyIsIkZpbGVTeXN0ZW1BZGFwdGVyIiwiRmlsZVZpZXciLCJzaGVsbCIsInBhdGgiLCJzcGF3biIsIkl0ZW1WaWV3IiwiU3RhdGVGaWVsZCIsIkVkaXRvclZpZXciLCJSYW5nZVNldEJ1aWxkZXIiLCJEZWNvcmF0aW9uIiwiVGV4dEZpbGVWaWV3IiwiRWRpdG9yU3RhdGUiLCJrZXltYXAiLCJpbmRlbnRNb3JlIiwiaW5kZW50TGVzcyIsIlBsdWdpblNldHRpbmdUYWIiLCJTZXR0aW5nIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQXVCQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQSxTQUFTLGFBQWEsQ0FBQyxNQUFjLEVBQUUsSUFBWSxFQUFBO0FBQ2pELElBQUEsSUFBSSxTQUFTLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxFQUFFO1FBQ3hCLE9BQU8sQ0FBQyxLQUFLLENBQUMsQ0FBQSxFQUFHLE1BQU0sQ0FBSyxFQUFBLEVBQUEsSUFBSSxDQUFFLENBQUEsQ0FBQyxDQUFDO0tBQ3JDO0FBQU0sU0FBQSxJQUFJLGNBQWMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEVBQUU7UUFDcEMsT0FBTyxDQUFDLElBQUksQ0FBQyxDQUFBLEVBQUcsTUFBTSxDQUFLLEVBQUEsRUFBQSxJQUFJLENBQUUsQ0FBQSxDQUFDLENBQUM7S0FDcEM7U0FBTTtRQUNMLE9BQU8sQ0FBQyxHQUFHLENBQUMsQ0FBQSxFQUFHLE1BQU0sQ0FBSyxFQUFBLEVBQUEsSUFBSSxDQUFFLENBQUEsQ0FBQyxDQUFDO0tBQ25DO0FBQ0gsQ0FBQztBQU9ELFNBQVMsaUJBQWlCLENBQUMsTUFBOEIsRUFBQTtJQUN2RCxJQUFJLE1BQU0sR0FBRyxFQUFFLENBQUM7QUFDaEIsSUFBQSxNQUFNLElBQUksSUFBSSxDQUFDLEtBQWEsS0FBSTtRQUM5QixNQUFNLElBQUksS0FBSyxDQUFDO1FBQ2hCLE1BQU0sS0FBSyxHQUFHLE1BQU0sQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLENBQUM7Ozs7QUFJcEMsUUFBQSxNQUFNLEdBQUcsS0FBSyxDQUFDLEdBQUcsRUFBRSxJQUFJLEVBQUUsQ0FBQztBQUMzQixRQUFBLEtBQUssTUFBTSxJQUFJLElBQUksS0FBSyxFQUFFO0FBQ3hCLFlBQUEsSUFBSSxJQUFJO2dCQUFFLE1BQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQztTQUN4QjtBQUNILEtBQUMsQ0FBa0IsQ0FBQztBQUNwQixJQUFBLElBQUksQ0FBQyxLQUFLLEdBQUcsTUFBSztRQUNoQixJQUFJLE1BQU0sRUFBRTtZQUNWLE1BQU0sQ0FBQyxNQUFNLENBQUMsQ0FBQztZQUNmLE1BQU0sR0FBRyxFQUFFLENBQUM7U0FDYjtBQUNILEtBQUMsQ0FBQztBQUNGLElBQUEsT0FBTyxJQUFJLENBQUM7QUFDZCxDQUFDO0FBRUQsU0FBUyxjQUFjLENBQUMsSUFBWSxFQUFBO0lBQ2xDLE9BQU8sSUFBSSxDQUFDLE9BQU8sQ0FBQywwQkFBMEIsRUFBRSxFQUFFLENBQUMsQ0FBQztBQUN0RCxDQUFDO0FBRUQsU0FBUyxrQkFBa0IsQ0FBQyxJQUFZLEVBQUE7SUFDdEMsTUFBTSxLQUFLLEdBQUcsY0FBYyxDQUFDLElBQUksQ0FBQyxDQUFDLEtBQUssQ0FBQyw4QkFBOEIsQ0FBQyxDQUFDO0FBQ3pFLElBQUEsT0FBTyxLQUFLLEdBQUcsQ0FBQyxDQUFDLElBQUksSUFBSSxDQUFDO0FBQzVCLENBQUM7QUFFRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUEsTUFBTSxnQkFBZ0IsR0FBRyxrQkFBa0IsQ0FBQztBQUM1QyxNQUFNLGFBQWEsR0FBRyxlQUFlLENBQUM7QUFRdEMsU0FBUyxnQkFBZ0IsQ0FBQyxPQUFlLEVBQUE7SUFDdkMsTUFBTSxLQUFLLEdBQUcsT0FBTyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQztJQUNyQyxNQUFNLFFBQVEsR0FBaUIsRUFBRSxDQUFDO0lBQ2xDLElBQUksYUFBYSxHQUFHLEtBQUssQ0FBQzs7OztBQUkxQixJQUFBLElBQUksV0FBVyxHQUFrQixJQUFJLENBQUM7QUFDdEMsSUFBQSxJQUFJLFdBQVcsR0FBRyxDQUFDLENBQUM7QUFFcEIsSUFBQSxLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsS0FBSyxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRTtBQUNyQyxRQUFBLE1BQU0sSUFBSSxHQUFHLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQzs7UUFHdEIsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLFVBQVUsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEVBQUU7WUFDcEMsYUFBYSxHQUFHLElBQUksQ0FBQztZQUNyQixTQUFTO1NBQ1Y7UUFDRCxJQUFJLGFBQWEsRUFBRTtBQUNqQixZQUFBLElBQUksbUJBQW1CLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQztnQkFBRSxhQUFhLEdBQUcsS0FBSyxDQUFDO1lBQzFELFNBQVM7U0FDVjs7O1FBSUQsTUFBTSxLQUFLLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyx1QkFBdUIsQ0FBQyxDQUFDO1FBQ2xELElBQUksS0FBSyxFQUFFO0FBQ1QsWUFBQSxNQUFNLEdBQUcsR0FBRyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDckIsWUFBQSxNQUFNLE1BQU0sR0FBRyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDdEIsWUFBQSxJQUFJLFdBQVcsS0FBSyxJQUFJLEVBQUU7Z0JBQ3hCLFdBQVcsR0FBRyxNQUFNLENBQUM7QUFDckIsZ0JBQUEsV0FBVyxHQUFHLEdBQUcsQ0FBQyxNQUFNLENBQUM7YUFDMUI7aUJBQU0sSUFBSSxNQUFNLEtBQUssV0FBVyxJQUFJLEdBQUcsQ0FBQyxNQUFNLElBQUksV0FBVyxFQUFFO2dCQUM5RCxXQUFXLEdBQUcsSUFBSSxDQUFDO2dCQUNuQixXQUFXLEdBQUcsQ0FBQyxDQUFDO2FBQ2pCO1lBQ0QsU0FBUztTQUNWO1FBQ0QsSUFBSSxXQUFXLEtBQUssSUFBSTtZQUFFLFNBQVM7UUFFbkMsTUFBTSxDQUFDLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyw4QkFBOEIsQ0FBQyxDQUFDO1FBQ3JELElBQUksQ0FBQyxFQUFFOztBQUVMLFlBQUEsTUFBTSxJQUFJLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxrQkFBa0IsRUFBRSxFQUFFLENBQUMsQ0FBQyxJQUFJLEVBQUUsQ0FBQztBQUN6RCxZQUFBLElBQUksSUFBSTtnQkFBRSxRQUFRLENBQUMsSUFBSSxDQUFDLEVBQUUsS0FBSyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLEVBQUUsSUFBSSxFQUFFLElBQUksRUFBRSxDQUFDLEVBQUUsQ0FBQyxDQUFDO1NBQ2hFO0tBQ0Y7QUFDRCxJQUFBLE9BQU8sUUFBUSxDQUFDO0FBQ2xCLENBQUM7QUFvQkQsTUFBTSxnQkFBZ0IsR0FBc0I7QUFDMUMsSUFBQSxVQUFVLEVBQUUsUUFBUTtBQUNwQixJQUFBLGdCQUFnQixFQUFFLElBQUk7QUFDdEIsSUFBQSxXQUFXLEVBQUUsRUFBRTtBQUNmLElBQUEsaUJBQWlCLEVBQUUsS0FBSztBQUN4QixJQUFBLGlCQUFpQixFQUFFLElBQUk7QUFDdkIsSUFBQSxvQkFBb0IsRUFBRSxLQUFLO0FBQzNCLElBQUEsYUFBYSxFQUFFLEtBQUs7QUFDcEIsSUFBQSxXQUFXLEVBQUUsS0FBSztDQUNuQixDQUFDO0FBRW1CLE1BQUEsYUFBYyxTQUFRQSxlQUFNLENBQUE7QUFBakQsSUFBQSxXQUFBLEdBQUE7O0FBRUUsUUFBQSxJQUFBLENBQUEsc0JBQXNCLEdBQStCLElBQUksR0FBRyxFQUFFLENBQUM7Ozs7O1FBSy9ELElBQW9CLENBQUEsb0JBQUEsR0FBaUIsSUFBSSxDQUFDO0tBeXdCM0M7QUF2d0JDLElBQUEsTUFBTSxNQUFNLEdBQUE7QUFDVixRQUFBLElBQUk7QUFDRixZQUFBLE1BQU0sSUFBSSxDQUFDLFlBQVksRUFBRSxDQUFDO0FBRTFCLFlBQUEsSUFBSSxDQUFDLFlBQVksQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDLElBQUksS0FBSyxJQUFJLGNBQWMsQ0FBQyxJQUFJLEVBQUUsSUFBSSxDQUFDLENBQUMsQ0FBQztBQUM5RSxZQUFBLElBQUksQ0FBQyxZQUFZLENBQUMsYUFBYSxFQUFFLENBQUMsSUFBSSxLQUFLLElBQUksV0FBVyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7QUFFbEUsWUFBQSxJQUFJLElBQUksQ0FBQyxRQUFRLENBQUMsZ0JBQWdCLEVBQUU7Z0JBQ2xDLElBQUksQ0FBQyxvQkFBb0IsRUFBRSxDQUFDO2FBQzdCO0FBQ0QsWUFBQSxJQUFJLElBQUksQ0FBQyxRQUFRLENBQUMsYUFBYSxFQUFFO2dCQUMvQixJQUFJLENBQUMsc0JBQXNCLEVBQUUsQ0FBQzthQUMvQjtBQUVELFlBQUEsSUFBSSxDQUFDLGFBQWEsQ0FBQyxJQUFJLGFBQWEsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFLElBQUksQ0FBQyxDQUFDLENBQUM7WUFFdEQsSUFBSSxDQUFDLGFBQWEsQ0FBQyxLQUFLLEVBQUUsdUJBQXVCLEVBQUUsWUFBVztBQUM1RCxnQkFBQSxNQUFNLElBQUksR0FBRyxJQUFJLENBQUMsMEJBQTBCLEVBQUUsQ0FBQztBQUMvQyxnQkFBQSxJQUFJLElBQUk7QUFBRSxvQkFBQSxNQUFNLElBQUksQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDM0MsYUFBQyxDQUFDLENBQUM7WUFFSCxJQUFJLENBQUMsVUFBVSxDQUFDO0FBQ2QsZ0JBQUEsRUFBRSxFQUFFLHVCQUF1QjtBQUMzQixnQkFBQSxJQUFJLEVBQUUsdUJBQXVCO2dCQUM3QixRQUFRLEVBQUUsWUFBVztBQUNuQixvQkFBQSxNQUFNLElBQUksR0FBRyxJQUFJLENBQUMsMEJBQTBCLEVBQUUsQ0FBQztBQUMvQyxvQkFBQSxJQUFJLElBQUk7QUFBRSx3QkFBQSxNQUFNLElBQUksQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLENBQUM7aUJBQzFDO0FBQ0YsYUFBQSxDQUFDLENBQUM7WUFFSCxJQUFJLENBQUMsVUFBVSxDQUFDO0FBQ2QsZ0JBQUEsRUFBRSxFQUFFLG1DQUFtQztBQUN2QyxnQkFBQSxJQUFJLEVBQUUsbUNBQW1DO2dCQUN6QyxRQUFRLEVBQUUsWUFBVztBQUNuQixvQkFBQSxNQUFNLElBQUksR0FBRyxJQUFJLENBQUMsMEJBQTBCLEVBQUUsQ0FBQztBQUMvQyxvQkFBQSxJQUFJLElBQUk7d0JBQUUsTUFBTSxJQUFJLENBQUMsYUFBYSxDQUFDLElBQUksRUFBRSxVQUFVLENBQUMsQ0FBQztpQkFDdEQ7QUFDRixhQUFBLENBQUMsQ0FBQztZQUVILElBQUksQ0FBQyxVQUFVLENBQUM7QUFDZCxnQkFBQSxFQUFFLEVBQUUsZ0NBQWdDO0FBQ3BDLGdCQUFBLElBQUksRUFBRSwyQ0FBMkM7Z0JBQ2pELFFBQVEsRUFBRSxZQUFXO0FBQ25CLG9CQUFBLE1BQU0sSUFBSSxHQUFHLElBQUksQ0FBQywwQkFBMEIsRUFBRSxDQUFDO0FBQy9DLG9CQUFBLElBQUksSUFBSTt3QkFBRSxNQUFNLElBQUksQ0FBQyxhQUFhLENBQUMsSUFBSSxFQUFFLFVBQVUsQ0FBQyxDQUFDO2lCQUN0RDtBQUNGLGFBQUEsQ0FBQyxDQUFDO1lBRUgsSUFBSSxDQUFDLGFBQWEsQ0FBQyxhQUFhLEVBQUUsc0JBQXNCLEVBQUUsWUFBVztBQUNuRSxnQkFBQSxNQUFNLElBQUksR0FBRyxJQUFJLENBQUMsMEJBQTBCLEVBQUUsQ0FBQztBQUMvQyxnQkFBQSxJQUFJLElBQUk7QUFBRSxvQkFBQSxNQUFNLElBQUksQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDdkMsYUFBQyxDQUFDLENBQUM7QUFFSCxZQUFBLElBQUksQ0FBQyxxQkFBcUIsQ0FBQyxtQkFBbUIsRUFBRSw0Q0FBNEMsQ0FBQyxDQUFDO1lBQzlGLElBQUksQ0FBQyxxQkFBcUIsQ0FBQyx5QkFBeUIsRUFBRSxxQ0FBcUMsRUFBRSxPQUFPLENBQUMsQ0FBQztZQUN0RyxJQUFJLENBQUMscUJBQXFCLENBQUMseUJBQXlCLEVBQUUscUNBQXFDLEVBQUUsS0FBSyxDQUFDLENBQUM7WUFFcEcsSUFBSSxDQUFDLFVBQVUsQ0FBQztBQUNkLGdCQUFBLEVBQUUsRUFBRSxxQkFBcUI7QUFDekIsZ0JBQUEsSUFBSSxFQUFFLHFCQUFxQjtBQUMzQixnQkFBQSxRQUFRLEVBQUUsTUFBTSxJQUFJLENBQUMsbUJBQW1CLEVBQUU7QUFDM0MsYUFBQSxDQUFDLENBQUM7OztBQUlILFlBQUEsTUFBTSxPQUFPLEdBQUdDLGlCQUFRLENBQUMsTUFBSztnQkFDNUIsSUFBSSxDQUFDLHFCQUFxQixFQUFFLENBQUM7Z0JBQzdCLElBQUksQ0FBQyxtQkFBbUIsRUFBRSxDQUFDO0FBQzdCLGFBQUMsRUFBRSxHQUFHLEVBQUUsSUFBSSxDQUFDLENBQUM7QUFDZCxZQUFBLElBQUksQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxTQUFTLENBQUMsRUFBRSxDQUFDLG9CQUFvQixFQUFFLE9BQU8sQ0FBQyxDQUFDLENBQUM7QUFDekUsWUFBQSxJQUFJLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsU0FBUyxDQUFDLEVBQUUsQ0FBQyxlQUFlLEVBQUUsT0FBTyxDQUFDLENBQUMsQ0FBQzs7O0FBSXBFLFlBQUEsSUFBSSxJQUFJLENBQUMsUUFBUSxDQUFDLFdBQVcsRUFBRTtBQUM3QixnQkFBQSxJQUFJLENBQUMsR0FBRyxDQUFDLFNBQVMsQ0FBQyxhQUFhLENBQUMsTUFBTSxJQUFJLENBQUMsbUJBQW1CLEVBQUUsQ0FBQyxDQUFDO2FBQ3BFO1NBQ0Y7UUFBQyxPQUFPLEtBQUssRUFBRTtBQUNkLFlBQUEsT0FBTyxDQUFDLEtBQUssQ0FBQyx1QkFBdUIsRUFBRSxLQUFLLENBQUMsQ0FBQztBQUM5QyxZQUFBLElBQUlDLGVBQU0sQ0FBQywrRUFBK0UsQ0FBQyxDQUFDO1NBQzdGO0tBQ0Y7SUFFRCxRQUFRLEdBQUE7UUFDTixJQUFJLENBQUMsZUFBZSxFQUFFLENBQUM7S0FDeEI7QUFFRCxJQUFBLE1BQU0sWUFBWSxHQUFBO1FBQ2hCLE1BQU0sTUFBTSxJQUFJLE1BQU0sSUFBSSxDQUFDLFFBQVEsRUFBRSxDQUFzQyxDQUFDO0FBQzVFLFFBQUEsSUFBSSxDQUFDLFFBQVEsR0FBRyxNQUFNLENBQUMsTUFBTSxDQUFDLEVBQUUsRUFBRSxnQkFBZ0IsRUFBRSxNQUFNLENBQUMsQ0FBQztLQUM3RDtBQUVELElBQUEsTUFBTSxZQUFZLEdBQUE7UUFDaEIsTUFBTSxJQUFJLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQztLQUNwQztBQUVELElBQUEsWUFBWSxDQUFDLElBQVcsRUFBQTtBQUN0QixRQUFBLE9BQU8sSUFBSSxDQUFDLFNBQVMsS0FBSyxLQUFLLENBQUM7S0FDakM7QUFFRCxJQUFBLGNBQWMsQ0FBQyxJQUFXLEVBQUE7QUFDeEIsUUFBQSxPQUFPLElBQUksQ0FBQyxTQUFTLEtBQUssSUFBSSxDQUFDO0tBQ2hDO0FBRUQsSUFBQSw0QkFBNEIsQ0FBQyxJQUFXLEVBQUE7UUFDdEMsSUFBSSxHQUFHLEdBQUcsSUFBSSxDQUFDLE1BQU0sRUFBRSxJQUFJLElBQUksRUFBRSxDQUFDO1FBQ2xDLE9BQU8sSUFBSSxFQUFFO0FBQ1gsWUFBQSxNQUFNLFVBQVUsR0FBR0Msc0JBQWEsQ0FBQyxHQUFHLEdBQUcsQ0FBRyxFQUFBLEdBQUcsY0FBYyxHQUFHLGFBQWEsQ0FBQyxDQUFDO0FBQzdFLFlBQUEsSUFBSSxJQUFJLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxxQkFBcUIsQ0FBQyxVQUFVLENBQUMsWUFBWUMsY0FBSyxFQUFFO0FBQ3JFLGdCQUFBLE9BQU8sSUFBSSxDQUFDO2FBQ2I7QUFDRCxZQUFBLElBQUksQ0FBQyxHQUFHO0FBQUUsZ0JBQUEsT0FBTyxLQUFLLENBQUM7WUFDdkIsTUFBTSxLQUFLLEdBQUcsR0FBRyxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsQ0FBQztZQUNuQyxHQUFHLEdBQUcsS0FBSyxLQUFLLENBQUMsQ0FBQyxHQUFHLEVBQUUsR0FBRyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUMsRUFBRSxLQUFLLENBQUMsQ0FBQztTQUMvQztLQUNGO0lBRUQsMEJBQTBCLEdBQUE7QUFDeEIsUUFBQSxNQUFNLFVBQVUsR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLFNBQVMsQ0FBQyxtQkFBbUIsQ0FBQ0MscUJBQVksQ0FBQyxDQUFDO0FBQ3hFLFFBQUEsTUFBTSxJQUFJLEdBQUcsVUFBVSxFQUFFLElBQUksQ0FBQztRQUM5QixJQUFJLENBQUMsSUFBSSxFQUFFO0FBQ1QsWUFBQSxJQUFJSCxlQUFNLENBQUMsOENBQThDLENBQUMsQ0FBQztBQUMzRCxZQUFBLE9BQU8sSUFBSSxDQUFDO1NBQ2I7QUFFRCxRQUFBLElBQUksSUFBSSxDQUFDLFlBQVksQ0FBQyxJQUFJLENBQUMsRUFBRTtBQUMzQixZQUFBLE9BQU8sSUFBSSxDQUFDO1NBQ2I7QUFFRCxRQUFBLElBQUksSUFBSSxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsRUFBRTtBQUM3QixZQUFBLElBQUksQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLG9CQUFvQixFQUFFO0FBQ3ZDLGdCQUFBLElBQUlBLGVBQU0sQ0FBQyw0RkFBNEYsQ0FBQyxDQUFDO0FBQ3pHLGdCQUFBLE9BQU8sSUFBSSxDQUFDO2FBQ2I7WUFDRCxJQUFJLENBQUMsSUFBSSxDQUFDLDRCQUE0QixDQUFDLElBQUksQ0FBQyxFQUFFO0FBQzVDLGdCQUFBLElBQUlBLGVBQU0sQ0FBQyx1R0FBdUcsQ0FBQyxDQUFDO0FBQ3BILGdCQUFBLE9BQU8sSUFBSSxDQUFDO2FBQ2I7QUFDRCxZQUFBLE9BQU8sSUFBSSxDQUFDO1NBQ2I7QUFFRCxRQUFBLElBQUksSUFBSSxDQUFDLFFBQVEsQ0FBQyxvQkFBb0IsRUFBRTtBQUN0QyxZQUFBLElBQUlBLGVBQU0sQ0FBQyxxREFBcUQsQ0FBQyxDQUFDO1NBQ25FO2FBQU07QUFDTCxZQUFBLElBQUlBLGVBQU0sQ0FBQyw4Q0FBOEMsQ0FBQyxDQUFDO1NBQzVEO0FBQ0QsUUFBQSxPQUFPLElBQUksQ0FBQztLQUNiO0FBRUQsSUFBQSxnQkFBZ0IsQ0FBQyxJQUFXLEVBQUE7UUFDMUIsTUFBTSxPQUFPLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDO0FBQ3ZDLFFBQUEsSUFBSSxPQUFPLFlBQVlJLDBCQUFpQixFQUFFO1lBQ3hDLE9BQU8sT0FBTyxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7U0FDdkM7QUFDRCxRQUFBLElBQUlKLGVBQU0sQ0FBQyx3REFBd0QsQ0FBQyxDQUFDO0FBQ3JFLFFBQUEsT0FBTyxJQUFJLENBQUM7S0FDYjtBQUVELElBQUEsVUFBVSxDQUFDLElBQVcsRUFBQTtRQUNwQixPQUFPLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLGNBQWMsRUFBRSxNQUFNLENBQUMsQ0FBQztLQUNsRDs7OztBQUtPLElBQUEsUUFBUSxDQUFDLElBQW1CLEVBQUE7QUFDbEMsUUFBQSxPQUFPLElBQUksQ0FBQyxJQUFJLFlBQVlLLGlCQUFRLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLEdBQUcsSUFBSSxDQUFDO0tBQzlEOzs7Ozs7Ozs7O0FBV0QsSUFBQSxNQUFNLHVCQUF1QixDQUMzQixTQUFpQixFQUNqQixZQUFrQyxFQUFBO1FBRWxDLE1BQU0sUUFBUSxHQUFHLE1BQU0sSUFBSSxDQUFDLGdCQUFnQixDQUFDLFNBQVMsQ0FBQyxDQUFDO1FBQ3hELElBQUksQ0FBQyxRQUFRLEVBQUU7QUFDYixZQUFBLElBQUlMLGVBQU0sQ0FDUixDQUFBLHdCQUFBLEVBQTJCLFNBQVMsQ0FBQSx1REFBQSxDQUF5RCxDQUM5RixDQUFDO0FBQ0YsWUFBQSxPQUFPLElBQUksQ0FBQztTQUNiO0FBQ0QsUUFBQSxJQUFJO0FBQ0YsWUFBQSxNQUFNLFFBQVEsR0FDWixZQUFZLEVBQUUsTUFBTSxJQUFJLElBQUk7QUFDMUIsa0JBQUUsWUFBWTtBQUNkLGtCQUFFLElBQUksQ0FBQyxHQUFHLENBQUMsU0FBUztxQkFDZixlQUFlLENBQUMsS0FBSyxDQUFDO3FCQUN0QixJQUFJLENBQUMsQ0FBQyxDQUFDLEtBQUssSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsRUFBRSxJQUFJLEtBQUssUUFBUSxDQUFDLElBQUksQ0FBQyxJQUFJLElBQUksQ0FBQztBQUN2RSxZQUFBLE1BQU0sSUFBSSxHQUFHLFFBQVEsSUFBSSxJQUFJLENBQUMsR0FBRyxDQUFDLFNBQVMsQ0FBQyxPQUFPLENBQUMsT0FBTyxFQUFFLFVBQVUsQ0FBQyxDQUFDOzs7Ozs7WUFNekUsTUFBTSxXQUFXLEdBQUcsSUFBSSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsQ0FBQztZQUN4QyxJQUFJLENBQUMsV0FBVyxJQUFJLFdBQVcsQ0FBQyxJQUFJLEtBQUssUUFBUSxDQUFDLElBQUksRUFBRTtBQUN0RCxnQkFBQSxNQUFNLElBQUksQ0FBQyxRQUFRLENBQUMsUUFBUSxFQUFFLEVBQUUsTUFBTSxFQUFFLEtBQUssRUFBRSxDQUFDLENBQUM7YUFDbEQ7WUFDRCxNQUFNLElBQUksQ0FBQyxHQUFHLENBQUMsU0FBUyxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUMxQyxZQUFBLE9BQU8sSUFBSSxDQUFDO1NBQ2I7UUFBQyxPQUFPLEdBQUcsRUFBRTtBQUNaLFlBQUEsT0FBTyxDQUFDLEtBQUssQ0FBQywwREFBMEQsRUFBRSxHQUFHLENBQUMsQ0FBQztBQUMvRSxZQUFBLElBQUlBLGVBQU0sQ0FBQyxDQUFBLGVBQUEsRUFBa0IsU0FBUyxDQUFBLDBCQUFBLENBQTRCLENBQUMsQ0FBQztBQUNwRSxZQUFBLE9BQU8sSUFBSSxDQUFDO1NBQ2I7S0FDRjtBQUVELElBQUEsTUFBTSxjQUFjLENBQUMsR0FBVyxFQUFFLElBQWlCLEVBQUE7UUFDakQsT0FBTyxDQUFDLEdBQUcsQ0FBQywrQ0FBK0MsRUFBRSxHQUFHLEVBQUUsT0FBTyxFQUFFLElBQUksQ0FBQyxDQUFDO0FBQ2pGLFFBQUEsSUFBSUEsZUFBTSxDQUFDLENBQUEscUJBQUEsRUFBd0IsR0FBRyxDQUFBLENBQUUsQ0FBQyxDQUFDO0FBRTFDLFFBQUEsSUFBSSxJQUFJLEtBQUssVUFBVSxFQUFFOzs7O0FBSXZCLFlBQUEsSUFBSTtBQUNGLGdCQUFBLE1BQU1NLGNBQUssQ0FBQyxZQUFZLENBQUMsR0FBRyxDQUFDLENBQUM7YUFDL0I7WUFBQyxPQUFPLEdBQUcsRUFBRTtBQUNaLGdCQUFBLE9BQU8sQ0FBQyxLQUFLLENBQUMsOENBQThDLEVBQUUsR0FBRyxDQUFDLENBQUM7Z0JBQ25FLElBQUlOLGVBQU0sQ0FBQyxDQUFpRCw4Q0FBQSxFQUFBLEdBQUcsRUFBRSxFQUFFLEtBQUssQ0FBQyxDQUFDO2FBQzNFO1lBQ0QsT0FBTztTQUNSOzs7OztBQU1ELFFBQUEsTUFBTSxlQUFlLEdBQ25CLElBQUksQ0FBQyxHQU1OLENBQUMsZUFBZSxDQUFDO1FBQ2xCLE1BQU0sV0FBVyxHQUNmLGVBQWUsRUFBRSxvQkFBb0IsR0FBRyxXQUFXLENBQUMsSUFBSSxJQUFJO1lBQzVELGVBQWUsRUFBRSxPQUFPLEVBQUUsU0FBUyxFQUFFLE9BQU8sS0FBSyxJQUFJLENBQUM7UUFFeEQsSUFBSSxDQUFDLFdBQVcsRUFBRTtZQUNoQixJQUFJQSxlQUFNLENBQ1IsOEVBQThFO2dCQUM1RSxvR0FBb0c7Z0JBQ3BHLHdDQUF3QyxFQUMxQyxLQUFLLENBQ04sQ0FBQztBQUNGLFlBQUEsT0FBTyxDQUFDLElBQUksQ0FDViw4REFBOEQsRUFDOUQsR0FBRyxDQUNKLENBQUM7QUFDRixZQUFBLEtBQUtNLGNBQUssQ0FBQyxZQUFZLENBQUMsR0FBRyxDQUFDLENBQUM7WUFDN0IsT0FBTztTQUNSO0FBRUQsUUFBQSxJQUFJO0FBQ0YsWUFBQSxNQUFNLElBQUksR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLFNBQVMsQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLENBQUM7WUFDL0MsTUFBTSxJQUFJLENBQUMsWUFBWSxDQUFDO0FBQ3RCLGdCQUFBLElBQUksRUFBRSxXQUFXO0FBQ2pCLGdCQUFBLE1BQU0sRUFBRSxJQUFJO2dCQUNaLEtBQUssRUFBRSxFQUFFLEdBQUcsRUFBRTtBQUNmLGFBQUEsQ0FBQyxDQUFDO1lBQ0gsTUFBTSxJQUFJLENBQUMsR0FBRyxDQUFDLFNBQVMsQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLENBQUM7U0FDM0M7UUFBQyxPQUFPLEdBQUcsRUFBRTtBQUNaLFlBQUEsT0FBTyxDQUFDLEtBQUssQ0FBQyxrREFBa0QsRUFBRSxHQUFHLENBQUMsQ0FBQztBQUN2RSxZQUFBLElBQUlOLGVBQU0sQ0FDUixvRkFBb0YsQ0FDckYsQ0FBQztBQUNGLFlBQUEsS0FBS00sY0FBSyxDQUFDLFlBQVksQ0FBQyxHQUFHLENBQUMsQ0FBQztTQUM5QjtLQUNGO0FBRUQsSUFBQSxxQkFBcUIsQ0FBQyxFQUFVLEVBQUUsSUFBWSxFQUFFLFFBQTBCLEVBQUE7UUFDeEUsSUFBSSxDQUFDLFVBQVUsQ0FBQztZQUNkLEVBQUU7WUFDRixJQUFJO0FBQ0osWUFBQSxJQUFJLEVBQUUsYUFBYTtZQUNuQixRQUFRLEVBQUUsWUFBVztBQUNuQixnQkFBQSxNQUFNLElBQUksR0FBRyxJQUFJLENBQUMsMEJBQTBCLEVBQUUsQ0FBQztBQUMvQyxnQkFBQSxJQUFJLElBQUk7b0JBQUUsTUFBTSxJQUFJLENBQUMsU0FBUyxDQUFDLElBQUksRUFBRSxRQUFRLENBQUMsQ0FBQzthQUNoRDtBQUNGLFNBQUEsQ0FBQyxDQUFDO0tBQ0o7SUFFRCxvQkFBb0IsR0FBQTtRQUNsQixJQUFJLENBQUMsa0JBQWtCLENBQUMsQ0FBQyxLQUFLLENBQUMsRUFBRSxVQUFVLENBQUMsQ0FBQztLQUM5QztJQUVELHNCQUFzQixHQUFBO1FBQ3BCLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDLEtBQUssRUFBRSxNQUFNLENBQUMsRUFBRSxhQUFhLENBQUMsQ0FBQztLQUN6RDs7O0FBSUQsSUFBQSxNQUFNLG1CQUFtQixHQUFBO0FBQ3ZCLFFBQUEsTUFBTSxFQUFFLFNBQVMsRUFBRSxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUM7Ozs7UUFJL0IsSUFBSSxDQUFDLHFCQUFxQixFQUFFLENBQUM7QUFDN0IsUUFBQSxJQUFJLElBQUksR0FBeUIsU0FBUyxDQUFDLGVBQWUsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLElBQUksQ0FBQztRQUN4RixJQUFJLENBQUMsSUFBSSxFQUFFO0FBQ1QsWUFBQSxJQUFJLEdBQUcsU0FBUyxDQUFDLFlBQVksQ0FBQyxLQUFLLENBQUMsQ0FBQztBQUNyQyxZQUFBLE1BQU0sSUFBSSxFQUFFLFlBQVksQ0FBQyxFQUFFLElBQUksRUFBRSxnQkFBZ0IsRUFBRSxNQUFNLEVBQUUsSUFBSSxFQUFFLENBQUMsQ0FBQztTQUNwRTtBQUNELFFBQUEsSUFBSSxJQUFJO0FBQUUsWUFBQSxNQUFNLFNBQVMsQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLENBQUM7UUFDM0MsSUFBSSxDQUFDLG1CQUFtQixFQUFFLENBQUM7S0FDNUI7Ozs7SUFLRCxxQkFBcUIsR0FBQTtBQUNuQixRQUFBLE1BQU0sSUFBSSxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsU0FBUyxDQUFDLG1CQUFtQixDQUFDSCxxQkFBWSxDQUFDLENBQUM7QUFDbEUsUUFBQSxJQUFJLElBQUksRUFBRSxJQUFJLElBQUksSUFBSSxDQUFDLFlBQVksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEVBQUU7QUFDOUMsWUFBQSxJQUFJLENBQUMsb0JBQW9CLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQztTQUN2QztLQUNGOztJQUdELG1CQUFtQixHQUFBO0FBQ2pCLFFBQUEsS0FBSyxNQUFNLElBQUksSUFBSSxJQUFJLENBQUMsR0FBRyxDQUFDLFNBQVMsQ0FBQyxlQUFlLENBQUMsZ0JBQWdCLENBQUMsRUFBRTtBQUN2RSxZQUFBLElBQUksSUFBSSxDQUFDLElBQUksWUFBWSxjQUFjLEVBQUU7QUFDdkMsZ0JBQUEsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLEVBQUUsQ0FBQzthQUNwQjtTQUNGO0tBQ0Y7O0lBR0Qsa0JBQWtCLEdBQUE7QUFDaEIsUUFBQSxLQUFLLE1BQU0sSUFBSSxJQUFJLElBQUksQ0FBQyxHQUFHLENBQUMsU0FBUyxDQUFDLGVBQWUsQ0FBQyxnQkFBZ0IsQ0FBQyxFQUFFO1lBQ3ZFLElBQUksQ0FBQyxNQUFNLEVBQUUsQ0FBQztTQUNmO0tBQ0Y7SUFFTyxrQkFBa0IsR0FBQTtBQUN4QixRQUFBLE9BQU8sSUFBSSxDQUFDLFFBQVEsQ0FBQyxpQkFBaUIsR0FBRyxVQUFVLEdBQUcsVUFBVSxDQUFDO0tBQ2xFO0lBRUQsTUFBTSxhQUFhLENBQUMsSUFBVyxFQUFFLElBQW9CLEdBQUEsSUFBSSxDQUFDLGtCQUFrQixFQUFFLEVBQUE7QUFDNUUsUUFBQSxNQUFNLGFBQWEsR0FBRyxJQUFJLENBQUMsc0JBQXNCLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUNqRSxRQUFBLElBQUksYUFBYSxFQUFFLElBQUksS0FBSyxJQUFJLEVBQUU7QUFDaEMsWUFBQSxNQUFNLElBQUksQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLENBQUM7U0FDOUI7YUFBTTtZQUNMLElBQUksYUFBYSxFQUFFO0FBQ2pCLGdCQUFBLE1BQU0sSUFBSSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsQ0FBQzthQUM5QjtZQUNELE1BQU0sSUFBSSxDQUFDLFlBQVksQ0FBQyxJQUFJLEVBQUUsSUFBSSxDQUFDLENBQUM7U0FDckM7S0FDRjtJQUVELE1BQU0sWUFBWSxDQUFDLElBQVcsRUFBRSxJQUFvQixHQUFBLElBQUksQ0FBQyxrQkFBa0IsRUFBRSxFQUFBO0FBQzNFLFFBQUEsTUFBTSxhQUFhLEdBQUcsSUFBSSxDQUFDLHNCQUFzQixDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDakUsUUFBQSxJQUFJLGFBQWEsRUFBRSxJQUFJLEtBQUssSUFBSSxFQUFFO0FBQ2hDLFlBQUEsT0FBTztTQUNSO1FBQ0QsSUFBSSxhQUFhLEVBQUU7QUFDakIsWUFBQSxNQUFNLElBQUksQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLENBQUM7U0FDOUI7QUFFRCxRQUFBLElBQUk7QUFDRixZQUFBLE1BQU0sWUFBWSxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLHFCQUFxQixDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztZQUNyRSxJQUFJLENBQUMsWUFBWSxJQUFJLEVBQUUsWUFBWSxZQUFZRCxjQUFLLENBQUMsRUFBRTtnQkFDckQsSUFBSUYsZUFBTSxDQUFDLENBQVEsS0FBQSxFQUFBLElBQUksQ0FBQyxJQUFJLENBQUEsVUFBQSxDQUFZLENBQUMsQ0FBQztnQkFDMUMsT0FBTzthQUNSO1lBQ0QsTUFBTSxRQUFRLEdBQUcsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFlBQVksQ0FBQyxDQUFDO0FBQ3JELFlBQUEsSUFBSSxDQUFDLFFBQVE7Z0JBQUUsT0FBTztZQUN0QixNQUFNLFVBQVUsR0FBR08sZUFBSSxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsQ0FBQztZQUUxQyxNQUFNLE9BQU8sR0FBc0IsRUFBRSxHQUFHLE9BQU8sQ0FBQyxHQUFHLEVBQUUsQ0FBQztZQUN0RCxJQUFJLElBQUksQ0FBQyxRQUFRLENBQUMsV0FBVyxDQUFDLElBQUksRUFBRSxFQUFFO2dCQUNwQyxPQUFPLENBQUMsWUFBWSxHQUFHLElBQUksQ0FBQyxRQUFRLENBQUMsV0FBVyxDQUFDLElBQUksRUFBRSxDQUFDO2FBQ3pEOzs7OztZQU1ELE1BQU0sSUFBSSxHQUFHLENBQUMsU0FBUyxFQUFFLFFBQVEsRUFBRSxjQUFjLENBQUMsQ0FBQzs7Ozs7OztZQVFuRCxNQUFNLGFBQWEsR0FBR0MsbUJBQUssQ0FDekIsSUFBSSxDQUFDLFFBQVEsQ0FBQyxVQUFVLEVBQ3hCLElBQUksRUFDSjtBQUNFLGdCQUFBLEdBQUcsRUFBRSxVQUFVO0FBQ2YsZ0JBQUEsR0FBRyxFQUFFLE9BQU87QUFDWixnQkFBQSxRQUFRLEVBQUUsT0FBTyxDQUFDLFFBQVEsS0FBSyxPQUFPO0FBQ3ZDLGFBQUEsQ0FDRixDQUFDO1lBRUYsSUFBSSxVQUFVLEdBQWtCLElBQUksQ0FBQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztZQXVCckMsSUFBSSxjQUFjLEdBQXlCLElBQUksQ0FBQztZQUNoRCxJQUFJLGNBQWMsR0FBa0IsSUFBSSxDQUFDO1lBQ3pDLElBQUksY0FBYyxHQUFHLEtBQUssQ0FBQztBQUUzQixZQUFBLE1BQU0sa0JBQWtCLEdBQUcsQ0FBQyxTQUFpQixLQUFVO0FBQ3JELGdCQUFBLElBQUksY0FBYztvQkFBRSxPQUFPO0FBQzNCLGdCQUFBLE1BQU0sWUFBWSxHQUFHLGNBQWMsRUFBRSxNQUFNLElBQUksSUFBSSxDQUFDO0FBQ3BELGdCQUFBLE1BQU0sUUFBUSxHQUFHLGNBQWMsS0FBSyxTQUFTLENBQUM7Z0JBQzlDLElBQUksWUFBWSxJQUFJLFFBQVE7b0JBQUUsT0FBTztnQkFFckMsY0FBYyxHQUFHLElBQUksQ0FBQztnQkFDdEIsY0FBYyxHQUFHLFNBQVMsQ0FBQztBQUMzQixnQkFBQSxJQUFJLENBQUMsdUJBQXVCLENBQUMsU0FBUyxFQUFFLGNBQWMsQ0FBQztBQUNwRCxxQkFBQSxJQUFJLENBQUMsQ0FBQyxJQUFJLEtBQUk7QUFDYixvQkFBQSxJQUFJLElBQUk7d0JBQUUsY0FBYyxHQUFHLElBQUksQ0FBQztBQUNsQyxpQkFBQyxDQUFDO0FBQ0QscUJBQUEsS0FBSyxDQUFDLENBQUMsR0FBRyxLQUFJO0FBQ2Isb0JBQUEsT0FBTyxDQUFDLEtBQUssQ0FBQyxzQ0FBc0MsRUFBRSxHQUFHLENBQUMsQ0FBQztvQkFDM0QsY0FBYyxHQUFHLElBQUksQ0FBQztvQkFDdEIsY0FBYyxHQUFHLElBQUksQ0FBQztBQUN4QixpQkFBQyxDQUFDO3FCQUNELE9BQU8sQ0FBQyxNQUFLO29CQUNaLGNBQWMsR0FBRyxLQUFLLENBQUM7QUFDekIsaUJBQUMsQ0FBQyxDQUFDO0FBQ1AsYUFBQyxDQUFDOzs7O1lBS0YsTUFBTSxVQUFVLEdBQWEsRUFBRSxDQUFDOzs7WUFHaEMsSUFBSSxjQUFjLEdBQUcsRUFBRSxDQUFDOzs7QUFJeEIsWUFBQSxNQUFNLGlCQUFpQixHQUFHLENBQUMsSUFBWSxLQUFJO0FBQ3pDLGdCQUFBLGFBQWEsQ0FBQyxnQkFBZ0IsRUFBRSxJQUFJLENBQUMsQ0FBQztBQUV0QyxnQkFBQSxJQUFJLFNBQVMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEVBQUU7QUFDeEIsb0JBQUEsVUFBVSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUN0QixvQkFBQSxJQUFJLElBQUksS0FBSyxjQUFjLEVBQUU7d0JBQzNCLGNBQWMsR0FBRyxJQUFJLENBQUM7d0JBQ3RCLElBQUlSLGVBQU0sQ0FBQyxDQUEwQix1QkFBQSxFQUFBLElBQUksRUFBRSxFQUFFLEtBQUssQ0FBQyxDQUFDO3FCQUNyRDtvQkFDRCxPQUFPO2lCQUNSOzs7QUFHRCxnQkFBQSxJQUFJLElBQUksQ0FBQyxRQUFRLENBQUMsaUJBQWlCLENBQUMsRUFBRTtvQkFDcEMsY0FBYyxHQUFHLEVBQUUsQ0FBQztpQkFDckI7Ozs7OztnQkFPRCxNQUFNLFFBQVEsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLDZCQUE2QixDQUFDLENBQUM7QUFDM0QsZ0JBQUEsSUFBSSxRQUFRLElBQUksU0FBUyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxFQUFFLENBQUMsSUFBSSxJQUFJLEtBQUssVUFBVSxFQUFFO0FBQ3pFLG9CQUFBLE1BQU0sV0FBVyxHQUFHTyxlQUFJLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLEVBQUUsQ0FBQyxDQUFDO29CQUN0RCxNQUFNLFNBQVMsR0FBRyxJQUFJLENBQUMsTUFBTSxFQUFFLElBQUksSUFBSSxFQUFFLENBQUM7QUFDMUMsb0JBQUEsTUFBTSxTQUFTLEdBQUdOLHNCQUFhLENBQUMsU0FBUyxHQUFHLENBQUEsRUFBRyxTQUFTLENBQUEsQ0FBQSxFQUFJLFdBQVcsQ0FBRSxDQUFBLEdBQUcsV0FBVyxDQUFDLENBQUM7b0JBQ3pGLGtCQUFrQixDQUFDLFNBQVMsQ0FBQyxDQUFDO29CQUM5QixPQUFPO2lCQUNSO0FBRUQsZ0JBQUEsTUFBTSxpQkFBaUIsR0FBRyxrQkFBa0IsQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUNuRCxnQkFBQSxJQUFJLENBQUMsVUFBVSxJQUFJLGlCQUFpQixFQUFFO0FBQ3BDLG9CQUFBLE9BQU8sQ0FBQyxHQUFHLENBQ1Qsd0NBQXdDLEVBQ3hDLFVBQVUsRUFBRSxpQkFBaUIsRUFDN0IsaUJBQWlCLEVBQUUsY0FBYyxFQUNqQyxPQUFPLEVBQUUsSUFBSSxDQUNkLENBQUM7b0JBQ0YsVUFBVSxHQUFHLGlCQUFpQixDQUFDOzs7O29CQUkvQixJQUFJLGNBQWMsRUFBRTtBQUNsQix3QkFBQSxJQUFJRCxlQUFNLENBQUMsQ0FBQSx5Q0FBQSxFQUE0QyxVQUFVLENBQUEsQ0FBRSxDQUFDLENBQUM7cUJBQ3RFO3lCQUFNO3dCQUNMLEtBQUssSUFBSSxDQUFDLGNBQWMsQ0FBQyxVQUFVLEVBQUUsSUFBSSxDQUFDLENBQUM7cUJBQzVDO2lCQUNGO0FBQ0gsYUFBQyxDQUFDOzs7O0FBS0YsWUFBQSxNQUFNLGFBQWEsR0FBRyxpQkFBaUIsQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDO0FBQzNELFlBQUEsTUFBTSxhQUFhLEdBQUcsaUJBQWlCLENBQUMsaUJBQWlCLENBQUMsQ0FBQztZQUMzRCxhQUFhLENBQUMsTUFBTSxFQUFFLEVBQUUsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxJQUFZLEtBQUssYUFBYSxDQUFDLElBQUksQ0FBQyxRQUFRLEVBQUUsQ0FBQyxDQUFDLENBQUM7WUFDbkYsYUFBYSxDQUFDLE1BQU0sRUFBRSxFQUFFLENBQUMsTUFBTSxFQUFFLENBQUMsSUFBWSxLQUFLLGFBQWEsQ0FBQyxJQUFJLENBQUMsUUFBUSxFQUFFLENBQUMsQ0FBQyxDQUFDOzs7O1lBS25GLGFBQWEsQ0FBQyxFQUFFLENBQUMsT0FBTyxFQUFFLENBQUMsR0FBRyxLQUFJO0FBQ2hDLGdCQUFBLE9BQU8sQ0FBQyxLQUFLLENBQUMsaURBQWlELEVBQUUsR0FBRyxDQUFDLENBQUM7QUFDdEUsZ0JBQUEsSUFBSUEsZUFBTSxDQUNSLENBQW9CLGlCQUFBLEVBQUEsSUFBSSxDQUFDLFFBQVEsQ0FBQyxVQUFVLENBQU0sR0FBQSxFQUFBLEdBQUcsQ0FBQyxPQUFPLENBQUksRUFBQSxDQUFBO0FBQy9ELG9CQUFBLDJEQUEyRCxDQUM5RCxDQUFDO0FBQ0YsZ0JBQUEsSUFBSSxJQUFJLENBQUMsc0JBQXNCLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsRUFBRSxPQUFPLEtBQUssYUFBYSxFQUFFO29CQUN6RSxJQUFJLENBQUMsc0JBQXNCLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztpQkFDL0M7QUFDSCxhQUFDLENBQUMsQ0FBQztZQUVILGFBQWEsQ0FBQyxFQUFFLENBQUMsT0FBTyxFQUFFLENBQUMsSUFBbUIsRUFBRSxNQUE2QixLQUFJO0FBQy9FLGdCQUFBLGFBQWEsQ0FBQyxLQUFLLEVBQUUsQ0FBQztnQkFDdEIsYUFBYSxDQUFDLEtBQUssRUFBRSxDQUFDO2dCQUN0QixJQUFJLElBQUksS0FBSyxJQUFJLElBQUksSUFBSSxLQUFLLENBQUMsRUFBRTtBQUMvQixvQkFBQSxNQUFNLE1BQU0sR0FBRyxVQUFVLENBQUMsTUFBTSxHQUFHLENBQUM7QUFDbEMsMEJBQUUsVUFBVSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUM7MEJBQ3JCLDBDQUEwQyxDQUFDO29CQUMvQyxJQUFJQSxlQUFNLENBQUMsQ0FBQSxnQ0FBQSxFQUFtQyxJQUFJLENBQUEsR0FBQSxFQUFNLE1BQU0sQ0FBRSxDQUFBLEVBQUUsS0FBSyxDQUFDLENBQUM7aUJBQzFFO0FBQU0scUJBQUEsSUFBSSxJQUFJLEtBQUssSUFBSSxJQUFJLE1BQU0sSUFBSSxNQUFNLEtBQUssU0FBUyxJQUFJLE1BQU0sS0FBSyxTQUFTLEVBQUU7O0FBRWxGLG9CQUFBLElBQUlBLGVBQU0sQ0FBQyxDQUFBLHlDQUFBLEVBQTRDLE1BQU0sQ0FBQSxDQUFFLENBQUMsQ0FBQztpQkFDbEU7QUFDRCxnQkFBQSxJQUFJLElBQUksQ0FBQyxzQkFBc0IsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxFQUFFLE9BQU8sS0FBSyxhQUFhLEVBQUU7b0JBQ3pFLElBQUksQ0FBQyxzQkFBc0IsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO2lCQUMvQztBQUNILGFBQUMsQ0FBQyxDQUFDO0FBRUgsWUFBQSxJQUFJLENBQUMsc0JBQXNCLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxJQUFJLEVBQUUsRUFBRSxPQUFPLEVBQUUsYUFBYSxFQUFFLElBQUksRUFBRSxDQUFDLENBQUM7QUFDN0UsWUFBQSxJQUFJQSxlQUFNLENBQUMsQ0FBQSx3QkFBQSxFQUEyQixJQUFJLEtBQUssVUFBVSxHQUFHLFVBQVUsR0FBRyxrQkFBa0IsQ0FBQSxDQUFBLENBQUcsQ0FBQyxDQUFDO1NBQ2pHO1FBQUMsT0FBTyxLQUFLLEVBQUU7QUFDZCxZQUFBLE9BQU8sQ0FBQyxLQUFLLENBQUMsaUNBQWlDLEVBQUUsS0FBSyxDQUFDLENBQUM7QUFDeEQsWUFBQSxJQUFJQSxlQUFNLENBQUMsZ0NBQWdDLENBQUMsQ0FBQztTQUM5QztLQUNGOzs7OztBQU1PLElBQUEsa0JBQWtCLENBQUMsYUFBMkIsRUFBQTtRQUNwRCxJQUFJLGFBQWEsQ0FBQyxNQUFNLElBQUksYUFBYSxDQUFDLEdBQUcsS0FBSyxTQUFTO1lBQUUsT0FBTztBQUNwRSxRQUFBLElBQUksT0FBTyxDQUFDLFFBQVEsS0FBSyxPQUFPLEVBQUU7QUFDaEMsWUFBQVEsbUJBQUssQ0FBQyxVQUFVLEVBQUUsQ0FBQyxNQUFNLEVBQUUsTUFBTSxDQUFDLGFBQWEsQ0FBQyxHQUFHLENBQUMsRUFBRSxJQUFJLEVBQUUsSUFBSSxDQUFDLENBQUMsQ0FBQztZQUNuRSxPQUFPO1NBQ1I7QUFDRCxRQUFBLElBQUk7O1lBRUYsT0FBTyxDQUFDLElBQUksQ0FBQyxDQUFDLGFBQWEsQ0FBQyxHQUFHLEVBQUUsU0FBUyxDQUFDLENBQUM7U0FDN0M7QUFBQyxRQUFBLE1BQU07O0FBRU4sWUFBQSxJQUFJO0FBQ0YsZ0JBQUEsYUFBYSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQzthQUMvQjtBQUFDLFlBQUEsTUFBTTs7YUFFUDtTQUNGO0tBQ0Y7SUFFRCxNQUFNLFdBQVcsQ0FBQyxJQUFXLEVBQUE7QUFDM0IsUUFBQSxNQUFNLGFBQWEsR0FBRyxJQUFJLENBQUMsc0JBQXNCLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUNqRSxJQUFJLGFBQWEsRUFBRTtBQUNqQixZQUFBLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxhQUFhLENBQUMsT0FBTyxDQUFDLENBQUM7WUFDL0MsSUFBSSxDQUFDLHNCQUFzQixDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDOUMsWUFBQSxJQUFJUixlQUFNLENBQUMsd0JBQXdCLENBQUMsQ0FBQztTQUN0QztLQUNGO0lBRUQsZUFBZSxHQUFBO1FBQ2IsTUFBTSxXQUFXLEdBQUcsSUFBSSxDQUFDLHNCQUFzQixDQUFDLElBQUksR0FBRyxDQUFDLENBQUM7UUFDekQsSUFBSSxDQUFDLHNCQUFzQixDQUFDLE9BQU8sQ0FBQyxDQUFDLGFBQWEsRUFBRSxRQUFRLEtBQUk7QUFDOUQsWUFBQSxJQUFJLENBQUMsa0JBQWtCLENBQUMsYUFBYSxDQUFDLE9BQU8sQ0FBQyxDQUFDO0FBQy9DLFlBQUEsSUFBSSxDQUFDLHNCQUFzQixDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsQ0FBQztBQUMvQyxTQUFDLENBQUMsQ0FBQztRQUNILElBQUksV0FBVyxFQUFFO0FBQ2YsWUFBQSxJQUFJQSxlQUFNLENBQUMsNkJBQTZCLENBQUMsQ0FBQztTQUMzQztLQUNGO0FBRUQsSUFBQSxNQUFNLFNBQVMsQ0FBQyxJQUFXLEVBQUUsUUFBMEIsRUFBQTtBQUNyRCxRQUFBLElBQUk7QUFDRixZQUFBLE1BQU0sWUFBWSxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLHFCQUFxQixDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztZQUNyRSxJQUFJLENBQUMsWUFBWSxJQUFJLEVBQUUsWUFBWSxZQUFZRSxjQUFLLENBQUMsRUFBRTtnQkFDckQsSUFBSUYsZUFBTSxDQUFDLENBQVEsS0FBQSxFQUFBLElBQUksQ0FBQyxJQUFJLENBQUEsVUFBQSxDQUFZLENBQUMsQ0FBQztnQkFDMUMsT0FBTzthQUNSOzs7O1lBS0QsSUFBSSxJQUFJLENBQUMsc0JBQXNCLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsRUFBRTtBQUM5QyxnQkFBQSxNQUFNLElBQUksQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLENBQUM7YUFDOUI7WUFFRCxNQUFNLFFBQVEsR0FBRyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsWUFBWSxDQUFDLENBQUM7QUFDckQsWUFBQSxJQUFJLENBQUMsUUFBUTtnQkFBRSxPQUFPO1lBQ3RCLE1BQU0sVUFBVSxHQUFHTyxlQUFJLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxDQUFDO1lBRTFDLE1BQU0sT0FBTyxHQUFzQixFQUFFLEdBQUcsT0FBTyxDQUFDLEdBQUcsRUFBRSxDQUFDO1lBQ3RELElBQUksSUFBSSxDQUFDLFFBQVEsQ0FBQyxXQUFXLENBQUMsSUFBSSxFQUFFLEVBQUU7Z0JBQ3BDLE9BQU8sQ0FBQyxZQUFZLEdBQUcsSUFBSSxDQUFDLFFBQVEsQ0FBQyxXQUFXLENBQUMsSUFBSSxFQUFFLENBQUM7YUFDekQ7WUFFRCxNQUFNLFdBQVcsR0FBRyxRQUFRLEtBQUssT0FBTyxHQUFHLE9BQU8sR0FBRyxRQUFRLEtBQUssS0FBSyxHQUFHLE9BQU8sR0FBRyx3QkFBd0IsQ0FBQztBQUM3RyxZQUFBLElBQUlQLGVBQU0sQ0FBQyxDQUFBLGtCQUFBLEVBQXFCLFdBQVcsQ0FBQSxJQUFBLENBQU0sQ0FBQyxDQUFDOzs7O1lBS25ELE1BQU0sY0FBYyxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDN0MsWUFBQSxNQUFNLFlBQVksR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLFNBQVM7aUJBQ3BDLGVBQWUsQ0FBQyxLQUFLLENBQUM7QUFDdEIsaUJBQUEsSUFBSSxDQUFDLENBQUMsQ0FBQyxLQUFLLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLEVBQUUsSUFBSSxLQUFLLGNBQWMsQ0FBQyxDQUFDO0FBRTFELFlBQUEsTUFBTSxJQUFJLEdBQUcsQ0FBQyxRQUFRLEVBQUUsUUFBUSxDQUFDLENBQUM7QUFDbEMsWUFBQSxJQUFJLFFBQVE7QUFBRSxnQkFBQSxJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sRUFBRSxRQUFRLENBQUMsQ0FBQztZQUUxQyxNQUFNLGFBQWEsR0FBR1EsbUJBQUssQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLFVBQVUsRUFBRSxJQUFJLEVBQUU7QUFDMUQsZ0JBQUEsR0FBRyxFQUFFLFVBQVU7QUFDZixnQkFBQSxHQUFHLEVBQUUsT0FBTztBQUNiLGFBQUEsQ0FBQyxDQUFDO1lBRUgsSUFBSSxzQkFBc0IsR0FBa0IsSUFBSSxDQUFDOzs7O1lBSWpELE1BQU0sVUFBVSxHQUFhLEVBQUUsQ0FBQzs7QUFHaEMsWUFBQSxNQUFNLGdCQUFnQixHQUFHLENBQUMsSUFBWSxLQUFJO0FBQ3hDLGdCQUFBLGFBQWEsQ0FBQyxRQUFRLEVBQUUsSUFBSSxDQUFDLENBQUM7Z0JBQzlCLE1BQU0sS0FBSyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsNkJBQTZCLENBQUMsQ0FBQztnQkFDeEQsSUFBSSxLQUFLLEVBQUU7QUFDVCxvQkFBQSxzQkFBc0IsR0FBR0QsZUFBSSxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxFQUFFLENBQUMsQ0FBQztpQkFDekQ7QUFDRCxnQkFBQSxJQUFJLFNBQVMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEVBQUU7QUFDeEIsb0JBQUEsVUFBVSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztpQkFDdkI7QUFDSCxhQUFDLENBQUM7Ozs7QUFLRixZQUFBLE1BQU0sWUFBWSxHQUFHLGlCQUFpQixDQUFDLGdCQUFnQixDQUFDLENBQUM7QUFDekQsWUFBQSxNQUFNLFlBQVksR0FBRyxpQkFBaUIsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDO1lBQ3pELGFBQWEsQ0FBQyxNQUFNLEVBQUUsRUFBRSxDQUFDLE1BQU0sRUFBRSxDQUFDLElBQVksS0FBSyxZQUFZLENBQUMsSUFBSSxDQUFDLFFBQVEsRUFBRSxDQUFDLENBQUMsQ0FBQztZQUNsRixhQUFhLENBQUMsTUFBTSxFQUFFLEVBQUUsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxJQUFZLEtBQUssWUFBWSxDQUFDLElBQUksQ0FBQyxRQUFRLEVBQUUsQ0FBQyxDQUFDLENBQUM7Ozs7WUFLbEYsYUFBYSxDQUFDLEVBQUUsQ0FBQyxPQUFPLEVBQUUsQ0FBQyxHQUFHLEtBQUk7QUFDaEMsZ0JBQUEsT0FBTyxDQUFDLEtBQUssQ0FBQyxnREFBZ0QsRUFBRSxHQUFHLENBQUMsQ0FBQztBQUNyRSxnQkFBQSxJQUFJUCxlQUFNLENBQ1IsQ0FBb0IsaUJBQUEsRUFBQSxJQUFJLENBQUMsUUFBUSxDQUFDLFVBQVUsQ0FBTSxHQUFBLEVBQUEsR0FBRyxDQUFDLE9BQU8sQ0FBSSxFQUFBLENBQUE7QUFDL0Qsb0JBQUEsMkRBQTJELENBQzlELENBQUM7QUFDSixhQUFDLENBQUMsQ0FBQztZQUVILGFBQWEsQ0FBQyxFQUFFLENBQUMsT0FBTyxFQUFFLENBQUMsSUFBbUIsRUFBRSxNQUE2QixLQUFJO2dCQUMvRSxLQUFLLENBQUMsWUFBVztBQUNmLG9CQUFBLFlBQVksQ0FBQyxLQUFLLEVBQUUsQ0FBQztvQkFDckIsWUFBWSxDQUFDLEtBQUssRUFBRSxDQUFDOzs7OztBQU1yQixvQkFBQSxJQUFJLElBQUksS0FBSyxDQUFDLEVBQUU7O3FCQUVmO0FBQU0seUJBQUEsSUFBSSxJQUFJLEtBQUssSUFBSSxLQUFLLE1BQU0sS0FBSyxTQUFTLElBQUksTUFBTSxLQUFLLFNBQVMsQ0FBQyxFQUFFO0FBQzFFLHdCQUFBLE9BQU8sQ0FBQyxLQUFLLENBQUMsd0NBQXdDLE1BQU0sQ0FBQSxFQUFBLENBQUksQ0FBQyxDQUFDO3dCQUNsRSxPQUFPO3FCQUNSO3lCQUFNO0FBQ0wsd0JBQUEsTUFBTSxTQUFTLEdBQUcsSUFBSSxLQUFLLElBQUk7OEJBQzNCLENBQVEsS0FBQSxFQUFBLElBQUksQ0FBRSxDQUFBO0FBQ2hCLDhCQUFFLE1BQU07a0NBQ0osQ0FBaUIsY0FBQSxFQUFBLE1BQU0sQ0FBRSxDQUFBO2tDQUN6QixZQUFZLENBQUM7Ozs7OztBQU1uQix3QkFBQSxPQUFPLENBQUMsS0FBSyxDQUFDLHFDQUFxQyxTQUFTLENBQUEsRUFBQSxDQUFJLENBQUMsQ0FBQztBQUNsRSx3QkFBQSxNQUFNLE1BQU0sR0FBRyxVQUFVLENBQUMsTUFBTSxHQUFHLENBQUM7QUFDbEMsOEJBQUUsVUFBVSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUM7OEJBQ3JCLDBDQUEwQyxDQUFDO3dCQUMvQyxJQUFJQSxlQUFNLENBQUMsQ0FBQSxzQkFBQSxFQUF5QixTQUFTLENBQUEsSUFBQSxFQUFPLE1BQU0sQ0FBRSxDQUFBLEVBQUUsS0FBSyxDQUFDLENBQUM7d0JBQ3JFLE9BQU87cUJBQ1I7b0JBRUQsTUFBTSxTQUFTLEdBQUcsSUFBSSxDQUFDLE1BQU0sRUFBRSxJQUFJLElBQUksRUFBRSxDQUFDO0FBQzFDLG9CQUFBLE1BQU0sZUFBZSxHQUFHQyxzQkFBYSxDQUNuQyxzQkFBc0I7QUFDcEIsMkJBQUcsU0FBUyxHQUFHLENBQUEsRUFBRyxTQUFTLENBQUEsQ0FBQSxFQUFJLHNCQUFzQixDQUFFLENBQUEsR0FBRyxzQkFBc0I7MEJBQzlFLGNBQWMsQ0FDbkIsQ0FBQztvQkFFRixNQUFNLFdBQVcsR0FBRyxNQUFNLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxlQUFlLENBQUMsQ0FBQztvQkFFakUsSUFBSSxDQUFDLFdBQVcsRUFBRTtBQUNoQix3QkFBQSxJQUFJRCxlQUFNLENBQ1IsQ0FBQSxxQkFBQSxFQUF3QixlQUFlLENBQUEseUZBQUEsQ0FBMkYsQ0FDbkksQ0FBQzt3QkFDRixPQUFPO3FCQUNSO29CQUVELE1BQU0sS0FBSyxHQUFHLGVBQWUsQ0FBQyxXQUFXLEVBQUUsQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLENBQUM7b0JBRTdELElBQUksQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLGlCQUFpQixJQUFJLENBQUMsS0FBSyxFQUFFO3dCQUM5QyxJQUFJQSxlQUFNLENBQ1IsS0FBSzs4QkFDRCxDQUFpQixjQUFBLEVBQUEsZUFBZSxDQUFFLENBQUE7QUFDcEMsOEJBQUUsQ0FBQSxVQUFBLEVBQWEsZUFBZSxDQUFBLGdEQUFBLENBQWtELENBQ25GLENBQUM7d0JBQ0YsT0FBTztxQkFDUjtBQUVELG9CQUFBLElBQUk7QUFDRix3QkFBQSxNQUFNLElBQUksR0FBRyxZQUFZLEVBQUUsTUFBTSxJQUFJLElBQUk7QUFDdkMsOEJBQUUsWUFBWTtBQUNkLDhCQUFFLElBQUksQ0FBQyxHQUFHLENBQUMsU0FBUyxDQUFDLE9BQU8sQ0FBQyxPQUFPLEVBQUUsVUFBVSxDQUFDLENBQUM7QUFDcEQsd0JBQUEsTUFBTSxJQUFJLENBQUMsUUFBUSxDQUFDLFdBQVcsRUFBRSxFQUFFLE1BQU0sRUFBRSxLQUFLLEVBQUUsQ0FBQyxDQUFDO3dCQUNwRCxNQUFNLElBQUksQ0FBQyxHQUFHLENBQUMsU0FBUyxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUMxQyx3QkFBQSxJQUFJQSxlQUFNLENBQUMsQ0FBQSxPQUFBLEVBQVUsZUFBZSxDQUFBLENBQUUsQ0FBQyxDQUFDO3FCQUN6QztvQkFBQyxPQUFPLEdBQUcsRUFBRTtBQUNaLHdCQUFBLE9BQU8sQ0FBQyxLQUFLLENBQUMsaUNBQWlDLEVBQUUsR0FBRyxDQUFDLENBQUM7QUFDdEQsd0JBQUEsSUFBSUEsZUFBTSxDQUNSLENBQUEsZ0JBQUEsRUFBbUIsZUFBZSxDQUFBLDZEQUFBLENBQStELENBQ2xHLENBQUM7cUJBQ0g7aUJBQ0YsR0FBRyxDQUFDO0FBQ1AsYUFBQyxDQUFDLENBQUM7U0FDSjtRQUFDLE9BQU8sS0FBSyxFQUFFO0FBQ2QsWUFBQSxPQUFPLENBQUMsS0FBSyxDQUFDLDhCQUE4QixFQUFFLEtBQUssQ0FBQyxDQUFDO0FBQ3JELFlBQUEsSUFBSUEsZUFBTSxDQUFDLDZCQUE2QixDQUFDLENBQUM7U0FDM0M7S0FDRjtBQUVELElBQUEsTUFBTSxnQkFBZ0IsQ0FBQyxTQUFpQixFQUFFLFNBQVMsR0FBRyxJQUFJLEVBQUE7QUFDeEQsUUFBQSxNQUFNLEtBQUssR0FBRyxJQUFJLENBQUMsR0FBRyxFQUFFLENBQUM7UUFDekIsT0FBTyxJQUFJLENBQUMsR0FBRyxFQUFFLEdBQUcsS0FBSyxHQUFHLFNBQVMsRUFBRTtBQUNyQyxZQUFBLE1BQU0sQ0FBQyxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLHFCQUFxQixDQUFDLFNBQVMsQ0FBQyxDQUFDO1lBQzFELElBQUksQ0FBQyxZQUFZRSxjQUFLO0FBQUUsZ0JBQUEsT0FBTyxDQUFDLENBQUM7QUFDakMsWUFBQSxNQUFNLElBQUksT0FBTyxDQUFDLENBQUMsQ0FBQyxLQUFLLFlBQVksQ0FBQyxVQUFVLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxDQUFDLENBQUM7U0FDM0Q7QUFDRCxRQUFBLE9BQU8sSUFBSSxDQUFDO0tBQ2I7QUFDRixDQUFBO0FBRUQ7QUFDQTtBQUNBO0FBQ0EsTUFBTSxjQUFlLFNBQVFPLGlCQUFRLENBQUE7SUFHbkMsV0FBWSxDQUFBLElBQW1CLEVBQUUsTUFBcUIsRUFBQTtRQUNwRCxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDWixRQUFBLElBQUksQ0FBQyxNQUFNLEdBQUcsTUFBTSxDQUFDO0tBQ3RCO0lBRUQsV0FBVyxHQUFBO0FBQ1QsUUFBQSxPQUFPLGdCQUFnQixDQUFDO0tBQ3pCO0lBRUQsY0FBYyxHQUFBO0FBQ1osUUFBQSxPQUFPLGdCQUFnQixDQUFDO0tBQ3pCO0lBRUQsT0FBTyxHQUFBO0FBQ0wsUUFBQSxPQUFPLE1BQU0sQ0FBQztLQUNmO0FBRUQsSUFBQSxNQUFNLE1BQU0sR0FBQTs7O0FBR1YsUUFBQSxJQUFJLENBQUMsTUFBTSxDQUFDLHFCQUFxQixFQUFFLENBQUM7UUFDcEMsSUFBSSxDQUFDLE1BQU0sRUFBRSxDQUFDO0tBQ2Y7OztBQUlPLElBQUEsZUFBZSxDQUFDLElBQVcsRUFBQTtBQUNqQyxRQUFBLEtBQUssTUFBTSxJQUFJLElBQUksSUFBSSxDQUFDLEdBQUcsQ0FBQyxTQUFTLENBQUMsZUFBZSxDQUFDLFVBQVUsQ0FBQyxFQUFFO0FBQ2pFLFlBQUEsSUFBSSxJQUFJLENBQUMsSUFBSSxZQUFZTixxQkFBWSxJQUFJLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxFQUFFLElBQUksS0FBSyxJQUFJLENBQUMsSUFBSSxFQUFFO2dCQUMzRSxPQUFPLElBQUksQ0FBQyxJQUFJLENBQUM7YUFDbEI7U0FDRjtBQUNELFFBQUEsT0FBTyxJQUFJLENBQUM7S0FDYjtJQUVELE1BQU0sR0FBQTtBQUNKLFFBQUEsTUFBTSxTQUFTLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQztRQUNqQyxTQUFTLENBQUMsS0FBSyxFQUFFLENBQUM7QUFDbEIsUUFBQSxTQUFTLENBQUMsUUFBUSxDQUFDLGFBQWEsQ0FBQyxDQUFDO0FBRWxDLFFBQUEsTUFBTSxJQUFJLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxvQkFBb0IsQ0FBQztRQUM5QyxJQUFJLENBQUMsSUFBSSxFQUFFO1lBQ1QsU0FBUyxDQUFDLFNBQVMsQ0FBQztBQUNsQixnQkFBQSxHQUFHLEVBQUUsbUJBQW1CO0FBQ3hCLGdCQUFBLElBQUksRUFBRSxrQ0FBa0M7QUFDekMsYUFBQSxDQUFDLENBQUM7WUFDSCxPQUFPO1NBQ1I7OztRQUlELE1BQU0sTUFBTSxHQUFHLElBQUksQ0FBQyxlQUFlLENBQUMsSUFBSSxDQUFDLENBQUM7UUFDMUMsSUFBSSxDQUFDLE1BQU0sRUFBRTtZQUNYLFNBQVMsQ0FBQyxTQUFTLENBQUM7QUFDbEIsZ0JBQUEsR0FBRyxFQUFFLG1CQUFtQjtBQUN4QixnQkFBQSxJQUFJLEVBQUUsQ0FBQSxLQUFBLEVBQVEsSUFBSSxDQUFDLElBQUksQ0FBc0Isb0JBQUEsQ0FBQTtBQUM5QyxhQUFBLENBQUMsQ0FBQztZQUNILE9BQU87U0FDUjtRQUVELE1BQU0sUUFBUSxHQUFHLGdCQUFnQixDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsUUFBUSxFQUFFLENBQUMsQ0FBQztBQUM1RCxRQUFBLElBQUksUUFBUSxDQUFDLE1BQU0sS0FBSyxDQUFDLEVBQUU7WUFDekIsU0FBUyxDQUFDLFNBQVMsQ0FBQztBQUNsQixnQkFBQSxHQUFHLEVBQUUsbUJBQW1CO0FBQ3hCLGdCQUFBLElBQUksRUFBRSwyQkFBMkI7QUFDbEMsYUFBQSxDQUFDLENBQUM7WUFDSCxPQUFPO1NBQ1I7QUFFRCxRQUFBLE1BQU0sSUFBSSxHQUFHLFNBQVMsQ0FBQyxTQUFTLENBQUMsRUFBRSxHQUFHLEVBQUUsa0JBQWtCLEVBQUUsQ0FBQyxDQUFDO0FBQzlELFFBQUEsS0FBSyxNQUFNLE9BQU8sSUFBSSxRQUFRLEVBQUU7QUFDOUIsWUFBQSxNQUFNLElBQUksR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDO0FBQzFCLGdCQUFBLEdBQUcsRUFBRSxrQkFBa0I7Z0JBQ3ZCLElBQUksRUFBRSxPQUFPLENBQUMsSUFBSTs7O2dCQUdsQixJQUFJLEVBQUUsRUFBRSxRQUFRLEVBQUUsR0FBRyxFQUFFLElBQUksRUFBRSxNQUFNLEVBQUU7QUFDdEMsYUFBQSxDQUFDLENBQUM7O1lBRUgsSUFBSSxDQUFDLE9BQU8sQ0FBQyxLQUFLLEdBQUcsTUFBTSxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsQ0FBQztZQUUzQyxNQUFNLE1BQU0sR0FBRyxNQUFLOzs7Z0JBR2xCLE1BQU0sSUFBSSxHQUFHLElBQUksQ0FBQyxlQUFlLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDeEMsZ0JBQUEsSUFBSSxDQUFDLElBQUk7b0JBQUUsT0FBTztBQUNsQixnQkFBQSxNQUFNLEdBQUcsR0FBRyxFQUFFLElBQUksRUFBRSxPQUFPLENBQUMsSUFBSSxFQUFFLEVBQUUsRUFBRSxDQUFDLEVBQUUsQ0FBQztBQUMxQyxnQkFBQSxJQUFJLENBQUMsR0FBRyxDQUFDLFNBQVMsQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLElBQUksRUFBRSxFQUFFLEtBQUssRUFBRSxJQUFJLEVBQUUsQ0FBQyxDQUFDO0FBQzdELGdCQUFBLElBQUksQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FBQyxDQUFDO0FBQzNCLGdCQUFBLElBQUksQ0FBQyxNQUFNLENBQUMsY0FBYyxDQUFDLEVBQUUsSUFBSSxFQUFFLEdBQUcsRUFBRSxFQUFFLEVBQUUsR0FBRyxFQUFFLEVBQUUsSUFBSSxDQUFDLENBQUM7QUFDekQsZ0JBQUEsSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLEVBQUUsQ0FBQztBQUN0QixhQUFDLENBQUM7QUFFRixZQUFBLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxPQUFPLEVBQUUsTUFBTSxDQUFDLENBQUM7WUFDdkMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFNBQVMsRUFBRSxDQUFDLEdBQUcsS0FBSTtBQUN2QyxnQkFBQSxJQUFJLEdBQUcsQ0FBQyxHQUFHLEtBQUssT0FBTyxJQUFJLEdBQUcsQ0FBQyxHQUFHLEtBQUssR0FBRyxFQUFFO29CQUMxQyxHQUFHLENBQUMsY0FBYyxFQUFFLENBQUM7QUFDckIsb0JBQUEsTUFBTSxFQUFFLENBQUM7aUJBQ1Y7QUFDSCxhQUFDLENBQUMsQ0FBQztTQUNKO0tBQ0Y7QUFDRixDQUFBO0FBRUQsTUFBTSxrQkFBa0IsR0FBR08sZ0JBQVUsQ0FBQyxNQUFNLENBQWdCO0FBQzFELElBQUEsTUFBTSxDQUFDLEtBQUssRUFBQTtBQUNWLFFBQUEsT0FBTyxvQkFBb0IsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUM7S0FDeEM7SUFDRCxNQUFNLENBQUMsV0FBVyxFQUFFLFdBQVcsRUFBQTtBQUM3QixRQUFBLElBQUksV0FBVyxDQUFDLFVBQVUsRUFBRTtZQUMxQixPQUFPLG9CQUFvQixDQUFDLFdBQVcsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUM7U0FDcEQ7UUFDRCxPQUFPLFdBQVcsQ0FBQyxHQUFHLENBQUMsV0FBVyxDQUFDLE9BQU8sQ0FBQyxDQUFDO0tBQzdDO0FBQ0QsSUFBQSxPQUFPLEVBQUUsQ0FBQyxLQUFLLEtBQUtDLGVBQVUsQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQztBQUN2RCxDQUFBLENBQUMsQ0FBQztBQUVILFNBQVMsb0JBQW9CLENBQUMsR0FBUyxFQUFBO0FBQ3JDLElBQUEsTUFBTSxPQUFPLEdBQUcsSUFBSUMscUJBQWUsRUFBYyxDQUFDO0FBQ2xELElBQUEsS0FBSyxJQUFJLFVBQVUsR0FBRyxDQUFDLEVBQUUsVUFBVSxJQUFJLEdBQUcsQ0FBQyxLQUFLLEVBQUUsVUFBVSxFQUFFLEVBQUU7UUFDOUQsTUFBTSxJQUFJLEdBQUcsR0FBRyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQztRQUNsQyxnQkFBZ0IsQ0FBQyxPQUFPLEVBQUUsSUFBSSxDQUFDLElBQUksRUFBRSxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7S0FDakQ7QUFDRCxJQUFBLE9BQU8sT0FBTyxDQUFDLE1BQU0sRUFBRSxDQUFDO0FBQzFCLENBQUM7QUFFRCxTQUFTLGdCQUFnQixDQUFDLE9BQW9DLEVBQUUsU0FBaUIsRUFBRSxJQUFZLEVBQUE7QUFDN0YsSUFBQSxNQUFNLE1BQU0sR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLEVBQUUsQ0FBQztJQUM3QyxNQUFNLE9BQU8sR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsQ0FBQztBQUMxQyxJQUFBLE1BQU0sWUFBWSxHQUFHLFNBQVMsR0FBRyxNQUFNLENBQUMsTUFBTSxDQUFDO0FBQy9DLElBQUEsSUFBSSxDQUFDLE9BQU87UUFBRSxPQUFPO0FBRXJCLElBQUEsSUFBSSxPQUFPLENBQUMsVUFBVSxDQUFDLEdBQUcsQ0FBQyxFQUFFO0FBQzNCLFFBQUEsYUFBYSxDQUFDLE9BQU8sRUFBRSxZQUFZLEVBQUUsU0FBUyxHQUFHLElBQUksQ0FBQyxNQUFNLEVBQUUsa0JBQWtCLENBQUMsQ0FBQztRQUNsRixPQUFPO0tBQ1I7SUFFRCxNQUFNLFdBQVcsR0FBRyxPQUFPLENBQUMsS0FBSyxDQUFDLGNBQWMsQ0FBQyxDQUFDO0lBQ2xELElBQUksV0FBVyxFQUFFO1FBQ2YsTUFBTSxZQUFZLEdBQUcsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQztRQUMzQyxhQUFhLENBQUMsT0FBTyxFQUFFLFlBQVksRUFBRSxZQUFZLEdBQUcsWUFBWSxFQUFFLHNCQUFzQixDQUFDLENBQUM7QUFDMUYsUUFBQSxtQkFBbUIsQ0FBQyxPQUFPLEVBQUUsWUFBWSxHQUFHLFlBQVksRUFBRSxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUMxRSxPQUFPO0tBQ1I7QUFFRCxJQUFBLG1CQUFtQixDQUFDLE9BQU8sRUFBRSxZQUFZLEVBQUUsT0FBTyxDQUFDLENBQUM7QUFDdEQsQ0FBQztBQUVELFNBQVMsbUJBQW1CLENBQUMsT0FBb0MsRUFBRSxZQUFvQixFQUFFLE9BQWUsRUFBQTtJQUN0RyxNQUFNLFFBQVEsR0FBRyxPQUFPLENBQUMsS0FBSyxDQUFDLDJCQUEyQixDQUFDLENBQUM7SUFDNUQsSUFBSSxRQUFRLEVBQUU7UUFDWixNQUFNLFlBQVksR0FBRyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDO1FBQ3hDLGFBQWEsQ0FBQyxPQUFPLEVBQUUsWUFBWSxFQUFFLFlBQVksR0FBRyxZQUFZLEVBQUUscUJBQXFCLENBQUMsQ0FBQztBQUN6RixRQUFBLGlCQUFpQixDQUFDLE9BQU8sRUFBRSxZQUFZLEdBQUcsWUFBWSxFQUFFLFFBQVEsQ0FBQyxDQUFDLENBQUMsSUFBSSxFQUFFLENBQUMsQ0FBQztRQUMzRSxPQUFPO0tBQ1I7QUFFRCxJQUFBLE1BQU0sS0FBSyxHQUFHLGdCQUFnQixDQUFDLE9BQU8sQ0FBQyxDQUFDO0FBQ3hDLElBQUEsSUFBSSxLQUFLLEtBQUssQ0FBQyxDQUFDLEVBQUU7UUFDaEIsYUFBYSxDQUFDLE9BQU8sRUFBRSxZQUFZLEVBQUUsWUFBWSxHQUFHLEtBQUssRUFBRSxjQUFjLENBQUMsQ0FBQztBQUMzRSxRQUFBLGFBQWEsQ0FBQyxPQUFPLEVBQUUsWUFBWSxHQUFHLEtBQUssRUFBRSxZQUFZLEdBQUcsS0FBSyxHQUFHLENBQUMsRUFBRSxnQkFBZ0IsQ0FBQyxDQUFDO0FBQ3pGLFFBQUEsaUJBQWlCLENBQUMsT0FBTyxFQUFFLFlBQVksR0FBRyxLQUFLLEdBQUcsQ0FBQyxFQUFFLE9BQU8sQ0FBQyxLQUFLLENBQUMsS0FBSyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDL0UsT0FBTztLQUNSO0FBRUQsSUFBQSxpQkFBaUIsQ0FBQyxPQUFPLEVBQUUsWUFBWSxFQUFFLE9BQU8sQ0FBQyxDQUFDO0FBQ3BELENBQUM7QUFFRCxTQUFTLGlCQUFpQixDQUFDLE9BQW9DLEVBQUUsVUFBa0IsRUFBRSxLQUFhLEVBQUE7QUFDaEcsSUFBQSxNQUFNLE9BQU8sR0FBRyxLQUFLLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLEVBQUUsQ0FBQztJQUMvQyxNQUFNLElBQUksR0FBRyxLQUFLLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQztBQUN6QyxJQUFBLE1BQU0sU0FBUyxHQUFHLFVBQVUsR0FBRyxPQUFPLENBQUMsTUFBTSxDQUFDO0FBQzlDLElBQUEsSUFBSSxDQUFDLElBQUk7UUFBRSxPQUFPO0FBRWxCLElBQUEsTUFBTSxZQUFZLEdBQUcsZUFBZSxDQUFDLElBQUksQ0FBQyxDQUFDO0lBQzNDLE1BQU0sTUFBTSxHQUFHLFlBQVksS0FBSyxDQUFDLENBQUMsR0FBRyxJQUFJLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDLEVBQUUsWUFBWSxDQUFDLENBQUM7QUFDeEUsSUFBQSxrQkFBa0IsQ0FBQyxPQUFPLEVBQUUsU0FBUyxFQUFFLE1BQU0sQ0FBQyxDQUFDO0FBQy9DLElBQUEsSUFBSSxZQUFZLEtBQUssQ0FBQyxDQUFDLEVBQUU7QUFDdkIsUUFBQSxhQUFhLENBQUMsT0FBTyxFQUFFLFNBQVMsR0FBRyxZQUFZLEVBQUUsU0FBUyxHQUFHLElBQUksQ0FBQyxNQUFNLEVBQUUsa0JBQWtCLENBQUMsQ0FBQztLQUMvRjtBQUNILENBQUM7QUFFRCxTQUFTLGtCQUFrQixDQUFDLE9BQW9DLEVBQUUsV0FBbUIsRUFBRSxNQUFjLEVBQUE7QUFDbkcsSUFBQSxNQUFNLFFBQVEsR0FBRyxNQUFNLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLEVBQUUsQ0FBQztJQUNqRCxNQUFNLEtBQUssR0FBRyxRQUFRLEdBQUcsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDLEVBQUUsTUFBTSxDQUFDLE1BQU0sR0FBRyxRQUFRLENBQUMsTUFBTSxDQUFDLEdBQUcsTUFBTSxDQUFDO0FBQ25GLElBQUEsSUFBSSxDQUFDLEtBQUs7UUFBRSxPQUFPO0FBRW5CLElBQUEsTUFBTSxTQUFTLEdBQUcsZUFBZSxDQUFDLEtBQUssQ0FBQyxDQUFDO0FBQ3pDLElBQUEsYUFBYSxDQUFDLE9BQU8sRUFBRSxXQUFXLEVBQUUsV0FBVyxHQUFHLEtBQUssQ0FBQyxNQUFNLEVBQUUsU0FBUyxDQUFDLENBQUM7QUFDN0UsQ0FBQztBQUVELFNBQVMsZUFBZSxDQUFDLEtBQWEsRUFBQTtBQUNwQyxJQUFBLElBQUksY0FBYyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUM7QUFBRSxRQUFBLE9BQU8saUJBQWlCLENBQUM7QUFDekQsSUFBQSxJQUFJLHNCQUFzQixDQUFDLElBQUksQ0FBQyxLQUFLLENBQUM7QUFBRSxRQUFBLE9BQU8saUJBQWlCLENBQUM7QUFDakUsSUFBQSxJQUFJLHNDQUFzQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUM7QUFBRSxRQUFBLE9BQU8sa0JBQWtCLENBQUM7QUFDbEYsSUFBQSxJQUFJLDJDQUEyQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUM7QUFBRSxRQUFBLE9BQU8saUJBQWlCLENBQUM7QUFDdEYsSUFBQSxJQUFJLGFBQWEsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDO0FBQUUsUUFBQSxPQUFPLGdCQUFnQixDQUFDO0FBQ3ZELElBQUEsSUFBSSw0RUFBNEUsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLEVBQUU7QUFDNUYsUUFBQSxPQUFPLHdCQUF3QixDQUFDO0tBQ2pDO0FBQ0QsSUFBQSxPQUFPLGlCQUFpQixDQUFDO0FBQzNCLENBQUM7QUFFRCxTQUFTLGdCQUFnQixDQUFDLE9BQWUsRUFBQTtJQUN2QyxJQUFJLFlBQVksR0FBRyxLQUFLLENBQUM7SUFDekIsSUFBSSxZQUFZLEdBQUcsS0FBSyxDQUFDO0FBQ3pCLElBQUEsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLE9BQU8sQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7QUFDdkMsUUFBQSxNQUFNLElBQUksR0FBRyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDeEIsUUFBQSxNQUFNLElBQUksR0FBRyxDQUFDLEdBQUcsQ0FBQyxHQUFHLE9BQU8sQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQUcsRUFBRSxDQUFDO0FBQ3pDLFFBQUEsSUFBSSxJQUFJLEtBQUssR0FBRyxJQUFJLENBQUMsWUFBWSxFQUFFO1lBQ2pDLFlBQVksR0FBRyxDQUFDLFlBQVksQ0FBQztTQUM5QjthQUFNLElBQUksSUFBSSxLQUFLLEdBQUcsSUFBSSxDQUFDLFlBQVksSUFBSSxJQUFJLEtBQUssSUFBSSxFQUFFO1lBQ3pELFlBQVksR0FBRyxDQUFDLFlBQVksQ0FBQztTQUM5QjthQUFNLElBQUksSUFBSSxLQUFLLEdBQUcsSUFBSSxDQUFDLFlBQVksSUFBSSxDQUFDLFlBQVksRUFBRTtZQUN6RCxNQUFNLElBQUksR0FBRyxPQUFPLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLEVBQUUsQ0FBQztBQUNsQyxZQUFBLE1BQU0sR0FBRyxHQUFHLE9BQU8sQ0FBQyxLQUFLLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLElBQUksRUFBRSxDQUFDO0FBQ3ZDLFlBQUEsSUFBSSxHQUFHLEtBQUssQ0FBQyxJQUFJLElBQUksSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUFFLGdCQUFBLE9BQU8sQ0FBQyxDQUFDO1NBQ2pEO0tBQ0Y7SUFDRCxPQUFPLENBQUMsQ0FBQyxDQUFDO0FBQ1osQ0FBQztBQUVELFNBQVMsZUFBZSxDQUFDLEtBQWEsRUFBQTtJQUNwQyxJQUFJLFlBQVksR0FBRyxLQUFLLENBQUM7SUFDekIsSUFBSSxZQUFZLEdBQUcsS0FBSyxDQUFDO0FBQ3pCLElBQUEsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLEtBQUssQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7QUFDckMsUUFBQSxNQUFNLElBQUksR0FBRyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDdEIsUUFBQSxNQUFNLElBQUksR0FBRyxDQUFDLEdBQUcsQ0FBQyxHQUFHLEtBQUssQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQUcsRUFBRSxDQUFDO0FBQ3ZDLFFBQUEsSUFBSSxJQUFJLEtBQUssR0FBRyxJQUFJLENBQUMsWUFBWSxFQUFFO1lBQ2pDLFlBQVksR0FBRyxDQUFDLFlBQVksQ0FBQztTQUM5QjthQUFNLElBQUksSUFBSSxLQUFLLEdBQUcsSUFBSSxDQUFDLFlBQVksSUFBSSxJQUFJLEtBQUssSUFBSSxFQUFFO1lBQ3pELFlBQVksR0FBRyxDQUFDLFlBQVksQ0FBQztTQUM5QjthQUFNLElBQUksSUFBSSxLQUFLLEdBQUcsSUFBSSxDQUFDLFlBQVksSUFBSSxDQUFDLFlBQVksS0FBSyxDQUFDLEtBQUssQ0FBQyxJQUFJLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsRUFBRTtBQUN6RixZQUFBLE9BQU8sQ0FBQyxDQUFDO1NBQ1Y7S0FDRjtJQUNELE9BQU8sQ0FBQyxDQUFDLENBQUM7QUFDWixDQUFDO0FBRUQsU0FBUyxhQUFhLENBQ3BCLE9BQW9DLEVBQ3BDLElBQVksRUFDWixFQUFVLEVBQ1YsU0FBaUIsRUFBQTtJQUVqQixJQUFJLEVBQUUsSUFBSSxJQUFJO1FBQUUsT0FBTztBQUN2QixJQUFBLE9BQU8sQ0FBQyxHQUFHLENBQUMsSUFBSSxFQUFFLEVBQUUsRUFBRUMsZUFBVSxDQUFDLElBQUksQ0FBQyxFQUFFLEtBQUssRUFBRSxTQUFTLEVBQUUsQ0FBQyxDQUFDLENBQUM7QUFDL0QsQ0FBQztBQUVELE1BQU0sV0FBWSxTQUFRQyxxQkFBWSxDQUFBO0FBQXRDLElBQUEsV0FBQSxHQUFBOztRQUNVLElBQVUsQ0FBQSxVQUFBLEdBQXNCLElBQUksQ0FBQztRQUNyQyxJQUFlLENBQUEsZUFBQSxHQUFHLEtBQUssQ0FBQztLQTRFakM7SUExRUMsV0FBVyxHQUFBO0FBQ1QsUUFBQSxPQUFPLGFBQWEsQ0FBQztLQUN0QjtJQUVELGNBQWMsR0FBQTtBQUNaLFFBQUEsT0FBTyxJQUFJLENBQUMsSUFBSSxFQUFFLElBQUksSUFBSSxXQUFXLENBQUM7S0FDdkM7SUFFRCxPQUFPLEdBQUE7QUFDTCxRQUFBLE9BQU8sV0FBVyxDQUFDO0tBQ3BCO0lBRUQsTUFBTSxHQUFBO1FBQ0osS0FBSyxDQUFDLE1BQU0sRUFBRSxDQUFDO0FBQ2YsUUFBQSxJQUFJLENBQUMsU0FBUyxDQUFDLEtBQUssRUFBRSxDQUFDO0FBQ3ZCLFFBQUEsSUFBSSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsZUFBZSxDQUFDLENBQUM7QUFDekMsUUFBQSxJQUFJLENBQUMsVUFBVSxHQUFHLElBQUlILGVBQVUsQ0FBQztZQUMvQixNQUFNLEVBQUUsSUFBSSxDQUFDLFNBQVM7QUFDdEIsWUFBQSxLQUFLLEVBQUVJLGlCQUFXLENBQUMsTUFBTSxDQUFDO0FBQ3hCLGdCQUFBLEdBQUcsRUFBRSxJQUFJLENBQUMsSUFBSSxJQUFJLEVBQUU7QUFDcEIsZ0JBQUEsVUFBVSxFQUFFO0FBQ1Ysb0JBQUFBLGlCQUFXLENBQUMsT0FBTyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7b0JBQ3pCLGtCQUFrQjtBQUNsQixvQkFBQUosZUFBVSxDQUFDLGlCQUFpQixDQUFDLEVBQUUsQ0FBQztBQUM5Qix3QkFBQSxZQUFZLEVBQUUsb0JBQW9CO0FBQ2xDLHdCQUFBLGNBQWMsRUFBRSxLQUFLO0FBQ3JCLHdCQUFBLFlBQVksRUFBRSxLQUFLO0FBQ25CLHdCQUFBLFVBQVUsRUFBRSxPQUFPO3FCQUNwQixDQUFDO29CQUNGSyxXQUFNLENBQUMsRUFBRSxDQUFDO0FBQ1Isd0JBQUEsRUFBRSxHQUFHLEVBQUUsS0FBSyxFQUFFLEdBQUcsRUFBRUMsbUJBQVUsRUFBRTtBQUMvQix3QkFBQSxFQUFFLEdBQUcsRUFBRSxXQUFXLEVBQUUsR0FBRyxFQUFFQyxtQkFBVSxFQUFFO3FCQUN0QyxDQUFDO29CQUNGUCxlQUFVLENBQUMsY0FBYyxDQUFDLEVBQUUsQ0FBQyxDQUFDLE1BQU0sS0FBSTtBQUN0Qyx3QkFBQSxJQUFJLENBQUMsTUFBTSxDQUFDLFVBQVUsSUFBSSxJQUFJLENBQUMsZUFBZTs0QkFBRSxPQUFPO3dCQUN2RCxJQUFJLENBQUMsSUFBSSxHQUFHLE1BQU0sQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLFFBQVEsRUFBRSxDQUFDO3dCQUN4QyxJQUFJLENBQUMsV0FBVyxFQUFFLENBQUM7QUFDckIscUJBQUMsQ0FBQztBQUNILGlCQUFBO2FBQ0YsQ0FBQztBQUNILFNBQUEsQ0FBQyxDQUFDO0FBQ0gsUUFBQSxJQUFJLENBQUMsUUFBUSxDQUFDLE1BQUs7QUFDakIsWUFBQSxJQUFJLENBQUMsVUFBVSxFQUFFLE9BQU8sRUFBRSxDQUFDO0FBQzNCLFlBQUEsSUFBSSxDQUFDLFVBQVUsR0FBRyxJQUFJLENBQUM7QUFDekIsU0FBQyxDQUFDLENBQUM7S0FDSjtJQUVELFdBQVcsR0FBQTtBQUNULFFBQUEsT0FBTyxJQUFJLENBQUMsVUFBVSxFQUFFLEtBQUssQ0FBQyxHQUFHLENBQUMsUUFBUSxFQUFFLElBQUksSUFBSSxDQUFDLElBQUksSUFBSSxFQUFFLENBQUM7S0FDakU7QUFFRCxJQUFBLFdBQVcsQ0FBQyxJQUFZLEVBQUE7QUFDdEIsUUFBQSxJQUFJLENBQUMsSUFBSSxHQUFHLElBQUksQ0FBQztBQUNqQixRQUFBLE1BQU0sSUFBSSxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUM7QUFDN0IsUUFBQSxJQUFJLENBQUMsSUFBSTtZQUFFLE9BQU87UUFDbEIsTUFBTSxPQUFPLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsUUFBUSxFQUFFLENBQUM7UUFDMUMsSUFBSSxPQUFPLEtBQUssSUFBSTtZQUFFLE9BQU87QUFDN0IsUUFBQSxJQUFJLENBQUMsZUFBZSxHQUFHLElBQUksQ0FBQztBQUM1QixRQUFBLElBQUk7WUFDRixJQUFJLENBQUMsUUFBUSxDQUFDO0FBQ1osZ0JBQUEsT0FBTyxFQUFFO0FBQ1Asb0JBQUEsSUFBSSxFQUFFLENBQUM7b0JBQ1AsRUFBRSxFQUFFLE9BQU8sQ0FBQyxNQUFNO0FBQ2xCLG9CQUFBLE1BQU0sRUFBRSxJQUFJO0FBQ2IsaUJBQUE7QUFDRixhQUFBLENBQUMsQ0FBQztTQUNKO2dCQUFTO0FBQ1IsWUFBQSxJQUFJLENBQUMsZUFBZSxHQUFHLEtBQUssQ0FBQztTQUM5QjtLQUNGO0lBRUQsS0FBSyxHQUFBO0FBQ0gsUUFBQSxJQUFJLENBQUMsV0FBVyxDQUFDLEVBQUUsQ0FBQyxDQUFDO0tBQ3RCO0FBQ0YsQ0FBQTtBQUVELE1BQU0sYUFBYyxTQUFRUSx5QkFBZ0IsQ0FBQTtJQUcxQyxXQUFZLENBQUEsR0FBUSxFQUFFLE1BQXFCLEVBQUE7QUFDekMsUUFBQSxLQUFLLENBQUMsR0FBRyxFQUFFLE1BQU0sQ0FBQyxDQUFDO0FBQ25CLFFBQUEsSUFBSSxDQUFDLE1BQU0sR0FBRyxNQUFNLENBQUM7S0FDdEI7SUFFRCxPQUFPLEdBQUE7QUFDTCxRQUFBLE1BQU0sRUFBRSxXQUFXLEVBQUUsR0FBRyxJQUFJLENBQUM7UUFDN0IsV0FBVyxDQUFDLEtBQUssRUFBRSxDQUFDO1FBRXBCLElBQUlDLGdCQUFPLENBQUMsV0FBVyxDQUFDO2FBQ3JCLE9BQU8sQ0FBQyxhQUFhLENBQUM7YUFDdEIsT0FBTyxDQUFDLG9FQUFvRSxDQUFDO0FBQzdFLGFBQUEsT0FBTyxDQUFDLENBQUMsSUFBSSxLQUNaLElBQUk7YUFDRCxjQUFjLENBQUMsUUFBUSxDQUFDO2FBQ3hCLFFBQVEsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxVQUFVLENBQUM7QUFDekMsYUFBQSxRQUFRLENBQUMsT0FBTyxLQUFLLEtBQUk7WUFDeEIsSUFBSSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsVUFBVSxHQUFHLEtBQUssQ0FBQztBQUN4QyxZQUFBLE1BQU0sSUFBSSxDQUFDLE1BQU0sQ0FBQyxZQUFZLEVBQUUsQ0FBQztTQUNsQyxDQUFDLENBQ0wsQ0FBQztRQUVKLElBQUlBLGdCQUFPLENBQUMsV0FBVyxDQUFDO2FBQ3JCLE9BQU8sQ0FBQyw2QkFBNkIsQ0FBQzthQUN0QyxPQUFPLENBQ04sbUdBQW1HLENBQ3BHO0FBQ0EsYUFBQSxTQUFTLENBQUMsQ0FBQyxNQUFNLEtBQ2hCLE1BQU07YUFDSCxRQUFRLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsZ0JBQWdCLENBQUM7QUFDL0MsYUFBQSxRQUFRLENBQUMsT0FBTyxLQUFLLEtBQUk7WUFDeEIsSUFBSSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsZ0JBQWdCLEdBQUcsS0FBSyxDQUFDO1lBQzlDLElBQUksS0FBSyxFQUFFO0FBQ1QsZ0JBQUEsSUFBSSxDQUFDLE1BQU0sQ0FBQyxvQkFBb0IsRUFBRSxDQUFDO2FBQ3BDO0FBQ0QsWUFBQSxNQUFNLElBQUksQ0FBQyxNQUFNLENBQUMsWUFBWSxFQUFFLENBQUM7U0FDbEMsQ0FBQyxDQUNMLENBQUM7UUFFSixJQUFJQSxnQkFBTyxDQUFDLFdBQVcsQ0FBQzthQUNyQixPQUFPLENBQUMsdUJBQXVCLENBQUM7YUFDaEMsT0FBTyxDQUFDLHlFQUF5RSxDQUFDO0FBQ2xGLGFBQUEsT0FBTyxDQUFDLENBQUMsSUFBSSxLQUNaLElBQUk7YUFDRCxjQUFjLENBQUMsaUJBQWlCLENBQUM7YUFDakMsUUFBUSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLFdBQVcsQ0FBQztBQUMxQyxhQUFBLFFBQVEsQ0FBQyxPQUFPLEtBQUssS0FBSTtZQUN4QixJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxXQUFXLEdBQUcsS0FBSyxDQUFDO0FBQ3pDLFlBQUEsTUFBTSxJQUFJLENBQUMsTUFBTSxDQUFDLFlBQVksRUFBRSxDQUFDO1NBQ2xDLENBQUMsQ0FDTCxDQUFDO1FBRUosSUFBSUEsZ0JBQU8sQ0FBQyxXQUFXLENBQUM7YUFDckIsT0FBTyxDQUFDLCtCQUErQixDQUFDO2FBQ3hDLE9BQU8sQ0FDTix5S0FBeUssQ0FDMUs7QUFDQSxhQUFBLFNBQVMsQ0FBQyxDQUFDLE1BQU0sS0FDaEIsTUFBTTthQUNILFFBQVEsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxpQkFBaUIsQ0FBQztBQUNoRCxhQUFBLFFBQVEsQ0FBQyxPQUFPLEtBQUssS0FBSTtZQUN4QixJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxpQkFBaUIsR0FBRyxLQUFLLENBQUM7QUFDL0MsWUFBQSxNQUFNLElBQUksQ0FBQyxNQUFNLENBQUMsWUFBWSxFQUFFLENBQUM7U0FDbEMsQ0FBQyxDQUNMLENBQUM7UUFFSixJQUFJQSxnQkFBTyxDQUFDLFdBQVcsQ0FBQzthQUNyQixPQUFPLENBQUMsaUNBQWlDLENBQUM7QUFDMUMsYUFBQSxPQUFPLENBQ04sZ0ZBQWdGO1lBQzlFLG9GQUFvRjtZQUNwRiw0RUFBNEU7WUFDNUUscUZBQXFGO0FBQ3JGLFlBQUEscUZBQXFGLENBQ3hGO0FBQ0EsYUFBQSxTQUFTLENBQUMsQ0FBQyxNQUFNLEtBQ2hCLE1BQU07YUFDSCxRQUFRLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsaUJBQWlCLENBQUM7QUFDaEQsYUFBQSxRQUFRLENBQUMsT0FBTyxLQUFLLEtBQUk7WUFDeEIsSUFBSSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsaUJBQWlCLEdBQUcsS0FBSyxDQUFDO0FBQy9DLFlBQUEsTUFBTSxJQUFJLENBQUMsTUFBTSxDQUFDLFlBQVksRUFBRSxDQUFDO1NBQ2xDLENBQUMsQ0FDTCxDQUFDO1FBRUosSUFBSUEsZ0JBQU8sQ0FBQyxXQUFXLENBQUM7YUFDckIsT0FBTyxDQUFDLCtDQUErQyxDQUFDO2FBQ3hELE9BQU8sQ0FDTiw0TEFBNEwsQ0FDN0w7QUFDQSxhQUFBLFNBQVMsQ0FBQyxDQUFDLE1BQU0sS0FDaEIsTUFBTTthQUNILFFBQVEsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxvQkFBb0IsQ0FBQztBQUNuRCxhQUFBLFFBQVEsQ0FBQyxPQUFPLEtBQUssS0FBSTtZQUN4QixJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxvQkFBb0IsR0FBRyxLQUFLLENBQUM7QUFDbEQsWUFBQSxNQUFNLElBQUksQ0FBQyxNQUFNLENBQUMsWUFBWSxFQUFFLENBQUM7U0FDbEMsQ0FBQyxDQUNMLENBQUM7UUFFSixJQUFJQSxnQkFBTyxDQUFDLFdBQVcsQ0FBQzthQUNyQixPQUFPLENBQUMsaUJBQWlCLENBQUM7YUFDMUIsT0FBTyxDQUNOLHVLQUF1SyxDQUN4SztBQUNBLGFBQUEsU0FBUyxDQUFDLENBQUMsTUFBTSxLQUNoQixNQUFNO2FBQ0gsUUFBUSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLGFBQWEsQ0FBQztBQUM1QyxhQUFBLFFBQVEsQ0FBQyxPQUFPLEtBQUssS0FBSTtZQUN4QixJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxhQUFhLEdBQUcsS0FBSyxDQUFDO1lBQzNDLElBQUksS0FBSyxFQUFFO0FBQ1QsZ0JBQUEsSUFBSSxDQUFDLE1BQU0sQ0FBQyxzQkFBc0IsRUFBRSxDQUFDO2FBQ3RDO2lCQUFNO0FBQ0wsZ0JBQUEsSUFBSXBCLGVBQU0sQ0FBQyw2Q0FBNkMsQ0FBQyxDQUFDO2FBQzNEO0FBQ0QsWUFBQSxNQUFNLElBQUksQ0FBQyxNQUFNLENBQUMsWUFBWSxFQUFFLENBQUM7U0FDbEMsQ0FBQyxDQUNMLENBQUM7UUFFSixJQUFJb0IsZ0JBQU8sQ0FBQyxXQUFXLENBQUM7YUFDckIsT0FBTyxDQUFDLHFCQUFxQixDQUFDO0FBQzlCLGFBQUEsT0FBTyxDQUNOLHVFQUF1RTtZQUNyRSxpRUFBaUU7WUFDakUsZ0VBQWdFO0FBQ2hFLFlBQUEsbURBQW1ELENBQ3REO0FBQ0EsYUFBQSxTQUFTLENBQUMsQ0FBQyxNQUFNLEtBQ2hCLE1BQU07YUFDSCxRQUFRLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsV0FBVyxDQUFDO0FBQzFDLGFBQUEsUUFBUSxDQUFDLE9BQU8sS0FBSyxLQUFJO1lBQ3hCLElBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLFdBQVcsR0FBRyxLQUFLLENBQUM7QUFDekMsWUFBQSxNQUFNLElBQUksQ0FBQyxNQUFNLENBQUMsWUFBWSxFQUFFLENBQUM7WUFDakMsSUFBSSxLQUFLLEVBQUU7QUFDVCxnQkFBQSxNQUFNLElBQUksQ0FBQyxNQUFNLENBQUMsbUJBQW1CLEVBQUUsQ0FBQzthQUN6QztpQkFBTTtBQUNMLGdCQUFBLElBQUksQ0FBQyxNQUFNLENBQUMsa0JBQWtCLEVBQUUsQ0FBQzthQUNsQztTQUNGLENBQUMsQ0FDTCxDQUFDO0tBQ0w7QUFDRjs7OzsifQ==
