'use strict';

var obsidian = require('obsidian');
var child_process = require('child_process');
var path = require('path');

function _interopNamespaceDefault(e) {
    var n = Object.create(null);
    if (e) {
        Object.keys(e).forEach(function (k) {
            if (k !== 'default') {
                var d = Object.getOwnPropertyDescriptor(e, k);
                Object.defineProperty(n, k, d.get ? d : {
                    enumerable: true,
                    get: function () { return e[k]; }
                });
            }
        });
    }
    n.default = e;
    return Object.freeze(n);
}

var path__namespace = /*#__PURE__*/_interopNamespaceDefault(path);

const DEFAULT_SETTINGS = {
    quartoPath: 'quarto',
    autoPreview: false,
    enableQmdLinking: false,
};
class QmdAsMdPlugin extends obsidian.Plugin {
    constructor() {
        super(...arguments);
        this.activePreviewProcesses = new Map();
    }
    async onload() {
        console.log('Plugin is loading...');
        try {
            await this.loadSettings();
            console.log('Settings loaded:', this.settings);
            if (this.settings.enableQmdLinking) {
                this.registerQmdExtension();
            }
            this.addSettingTab(new QmdSettingTab(this.app, this));
            console.log('Settings tab added successfully');
            this.addRibbonIcon('eye', 'Toggle Quarto Preview', async (evt) => {
                const activeView = this.app.workspace.getActiveViewOfType(obsidian.MarkdownView);
                if (activeView?.file && this.isQuartoFile(activeView.file)) {
                    console.log(`Toggling preview for: ${activeView.file.path}`);
                    await this.togglePreview(activeView.file);
                }
                else {
                    new obsidian.Notice('Current file is not a Quarto document');
                }
            });
            console.log('Ribbon icon added');
            this.addCommand({
                id: 'toggle-quarto-preview',
                name: 'Toggle Quarto Preview',
                callback: async () => {
                    const activeView = this.app.workspace.getActiveViewOfType(obsidian.MarkdownView);
                    if (activeView?.file && this.isQuartoFile(activeView.file)) {
                        console.log(`Command: Toggling preview for ${activeView.file.path}`);
                        await this.togglePreview(activeView.file);
                    }
                    else {
                        new obsidian.Notice('Current file is not a Quarto document');
                    }
                },
                hotkeys: [{ modifiers: ['Ctrl', 'Shift'], key: 'p' }],
            });
            console.log('Commands added');
        }
        catch (error) {
            console.error('Error loading plugin:', error);
            new obsidian.Notice('Failed to load QmdAsMdPlugin. Check the developer console for details.');
        }
    }
    onunload() {
        console.log('Plugin is unloading...');
        this.stopAllPreviews();
    }
    async loadSettings() {
        this.settings = Object.assign({}, DEFAULT_SETTINGS, await this.loadData());
    }
    async saveSettings() {
        await this.saveData(this.settings);
    }
    isQuartoFile(file) {
        return file.extension === 'qmd';
    }
    registerQmdExtension() {
        console.log('Registering .qmd as markdown...');
        this.registerExtensions(['qmd'], 'markdown');
        console.log('.qmd registered as markdown');
    }
    async togglePreview(file) {
        if (this.activePreviewProcesses.has(file.path)) {
            await this.stopPreview(file);
        }
        else {
            await this.startPreview(file);
        }
    }
    async startPreview(file) {
        if (this.activePreviewProcesses.has(file.path)) {
            console.log(`Preview already running for: ${file.path}`);
            return; // Preview already running
        }
        try {
            const abstractFile = this.app.vault.getAbstractFileByPath(file.path);
            if (!abstractFile || !(abstractFile instanceof obsidian.TFile)) {
                new obsidian.Notice(`File ${file.path} not found`);
                return;
            }
            const filePath = this.app.vault.adapter.getFullPath(abstractFile.path);
            const workingDir = path__namespace.dirname(filePath);
            console.log(`Resolved file path: ${filePath}`);
            console.log(`Working directory: ${workingDir}`);
            const process = child_process.spawn(this.settings.quartoPath, ['preview', filePath], {
                cwd: workingDir,
            });
            let previewUrl = null;
            process.stdout?.on('data', (data) => {
                const output = data.toString();
                console.log(`Quarto Preview Output: ${output}`);
                if (output.includes('Browse at')) {
                    const match = output.match(/Browse at\s+(http:\/\/[^\s]+)/);
                    if (match && match[1]) {
                        previewUrl = match[1];
                        new obsidian.Notice(`Preview available at ${previewUrl}`);
                        // Open the preview in a new tab
                        // Open the preview in a new tab
                        const leaf = this.app.workspace.getLeaf('tab');
                        leaf.setViewState({
                            type: 'webviewer',
                            active: true,
                            state: {
                                url: previewUrl,
                            },
                        });
                        // Reveal the tab
                        this.app.workspace.revealLeaf(leaf);
                    }
                }
            });
            process.stderr?.on('data', (data) => {
                console.error(`Quarto Preview Error: ${data}`);
                new obsidian.Notice(`Quarto Preview Error: ${data}`);
            });
            process.on('close', (code) => {
                if (code !== null && code !== 0) {
                    new obsidian.Notice(`Quarto preview process exited with code ${code}`);
                }
                this.activePreviewProcesses.delete(file.path);
            });
            this.activePreviewProcesses.set(file.path, process);
            new obsidian.Notice('Quarto preview started');
        }
        catch (error) {
            console.error('Failed to start Quarto preview:', error);
            new obsidian.Notice('Failed to start Quarto preview');
        }
    }
    async stopPreview(file) {
        const process = this.activePreviewProcesses.get(file.path);
        if (process) {
            if (!process.killed) {
                process.kill();
            }
            this.activePreviewProcesses.delete(file.path);
            new obsidian.Notice('Quarto preview stopped');
        }
    }
    stopAllPreviews() {
        this.activePreviewProcesses.forEach((process, filePath) => {
            if (!process.killed) {
                process.kill();
            }
            this.activePreviewProcesses.delete(filePath);
        });
        if (this.activePreviewProcesses.size > 0) {
            new obsidian.Notice('All Quarto previews stopped');
        }
    }
}
class QmdSettingTab extends obsidian.PluginSettingTab {
    constructor(app, plugin) {
        super(app, plugin);
        this.plugin = plugin;
    }
    display() {
        const { containerEl } = this;
        containerEl.empty();
        console.log('Rendering settings tab...');
        containerEl.createEl('h2', { text: 'Quarto Preview Settings' });
        new obsidian.Setting(containerEl)
            .setName('Quarto Path')
            .setDesc('Path to Quarto executable (e.g., quarto, /usr/local/bin/quarto)')
            .addText((text) => text
            .setPlaceholder('quarto')
            .setValue(this.plugin.settings.quartoPath)
            .onChange(async (value) => {
            console.log(`Quarto path changed to: ${value}`);
            this.plugin.settings.quartoPath = value;
            await this.plugin.saveSettings();
        }));
        new obsidian.Setting(containerEl)
            .setName('Auto Preview')
            .setDesc('Automatically start preview when opening Quarto files')
            .addToggle((toggle) => toggle
            .setValue(this.plugin.settings.autoPreview)
            .onChange(async (value) => {
            console.log(`Auto-preview setting changed to: ${value}`);
            this.plugin.settings.autoPreview = value;
            await this.plugin.saveSettings();
        }));
        new obsidian.Setting(containerEl)
            .setName('Enable Linking to Quarto Files')
            .setDesc('Allow linking to `.qmd` files without enabling "Detect All File Extensions"')
            .addToggle((toggle) => toggle
            .setValue(this.plugin.settings.enableQmdLinking)
            .onChange(async (value) => {
            console.log(`Enable QMD Linking setting changed to: ${value}`);
            this.plugin.settings.enableQmdLinking = value;
            if (value) {
                this.plugin.registerQmdExtension();
            }
            else {
                console.log('.qmd linking disabled. Restart Obsidian if required.');
            }
            await this.plugin.saveSettings();
        }));
        console.log('Settings tab rendered successfully');
    }
}

module.exports = QmdAsMdPlugin;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibWFpbi5qcyIsInNvdXJjZXMiOlsic3JjL21haW4udHMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtcbiAgUGx1Z2luLFxuICBOb3RpY2UsXG4gIFRGaWxlLFxuICBNYXJrZG93blZpZXcsXG4gIFBsdWdpblNldHRpbmdUYWIsXG4gIEFwcCxcbiAgU2V0dGluZyxcbiAgVEFic3RyYWN0RmlsZSxcbn0gZnJvbSAnb2JzaWRpYW4nO1xuaW1wb3J0IHsgc3Bhd24sIENoaWxkUHJvY2VzcyB9IGZyb20gJ2NoaWxkX3Byb2Nlc3MnO1xuaW1wb3J0ICogYXMgcGF0aCBmcm9tICdwYXRoJztcblxuaW50ZXJmYWNlIFFtZFBsdWdpblNldHRpbmdzIHtcbiAgcXVhcnRvUGF0aDogc3RyaW5nO1xuICBhdXRvUHJldmlldzogYm9vbGVhbjtcbiAgZW5hYmxlUW1kTGlua2luZzogYm9vbGVhbjtcbn1cblxuY29uc3QgREVGQVVMVF9TRVRUSU5HUzogUW1kUGx1Z2luU2V0dGluZ3MgPSB7XG4gIHF1YXJ0b1BhdGg6ICdxdWFydG8nLFxuICBhdXRvUHJldmlldzogZmFsc2UsXG4gIGVuYWJsZVFtZExpbmtpbmc6IGZhbHNlLFxufTtcblxuZXhwb3J0IGRlZmF1bHQgY2xhc3MgUW1kQXNNZFBsdWdpbiBleHRlbmRzIFBsdWdpbiB7XG4gIHNldHRpbmdzOiBRbWRQbHVnaW5TZXR0aW5ncztcbiAgYWN0aXZlUHJldmlld1Byb2Nlc3NlczogTWFwPHN0cmluZywgQ2hpbGRQcm9jZXNzPiA9IG5ldyBNYXAoKTtcblxuICBhc3luYyBvbmxvYWQoKSB7XG4gICAgY29uc29sZS5sb2coJ1BsdWdpbiBpcyBsb2FkaW5nLi4uJyk7XG4gICAgdHJ5IHtcbiAgICAgIGF3YWl0IHRoaXMubG9hZFNldHRpbmdzKCk7XG4gICAgICBjb25zb2xlLmxvZygnU2V0dGluZ3MgbG9hZGVkOicsIHRoaXMuc2V0dGluZ3MpO1xuXG4gICAgICBpZiAodGhpcy5zZXR0aW5ncy5lbmFibGVRbWRMaW5raW5nKSB7XG4gICAgICAgIHRoaXMucmVnaXN0ZXJRbWRFeHRlbnNpb24oKTtcbiAgICAgIH1cblxuICAgICAgdGhpcy5hZGRTZXR0aW5nVGFiKG5ldyBRbWRTZXR0aW5nVGFiKHRoaXMuYXBwLCB0aGlzKSk7XG4gICAgICBjb25zb2xlLmxvZygnU2V0dGluZ3MgdGFiIGFkZGVkIHN1Y2Nlc3NmdWxseScpO1xuXG4gICAgICB0aGlzLmFkZFJpYmJvbkljb24oJ2V5ZScsICdUb2dnbGUgUXVhcnRvIFByZXZpZXcnLCBhc3luYyAoZXZ0KSA9PiB7XG4gICAgICAgIGNvbnN0IGFjdGl2ZVZpZXcgPSB0aGlzLmFwcC53b3Jrc3BhY2UuZ2V0QWN0aXZlVmlld09mVHlwZShNYXJrZG93blZpZXcpO1xuICAgICAgICBpZiAoYWN0aXZlVmlldz8uZmlsZSAmJiB0aGlzLmlzUXVhcnRvRmlsZShhY3RpdmVWaWV3LmZpbGUpKSB7XG4gICAgICAgICAgY29uc29sZS5sb2coYFRvZ2dsaW5nIHByZXZpZXcgZm9yOiAke2FjdGl2ZVZpZXcuZmlsZS5wYXRofWApO1xuICAgICAgICAgIGF3YWl0IHRoaXMudG9nZ2xlUHJldmlldyhhY3RpdmVWaWV3LmZpbGUpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIG5ldyBOb3RpY2UoJ0N1cnJlbnQgZmlsZSBpcyBub3QgYSBRdWFydG8gZG9jdW1lbnQnKTtcbiAgICAgICAgfVxuICAgICAgfSk7XG4gICAgICBjb25zb2xlLmxvZygnUmliYm9uIGljb24gYWRkZWQnKTtcblxuICAgICAgdGhpcy5hZGRDb21tYW5kKHtcbiAgICAgICAgaWQ6ICd0b2dnbGUtcXVhcnRvLXByZXZpZXcnLFxuICAgICAgICBuYW1lOiAnVG9nZ2xlIFF1YXJ0byBQcmV2aWV3JyxcbiAgICAgICAgY2FsbGJhY2s6IGFzeW5jICgpID0+IHtcbiAgICAgICAgICBjb25zdCBhY3RpdmVWaWV3ID0gdGhpcy5hcHAud29ya3NwYWNlLmdldEFjdGl2ZVZpZXdPZlR5cGUoTWFya2Rvd25WaWV3KTtcbiAgICAgICAgICBpZiAoYWN0aXZlVmlldz8uZmlsZSAmJiB0aGlzLmlzUXVhcnRvRmlsZShhY3RpdmVWaWV3LmZpbGUpKSB7XG4gICAgICAgICAgICBjb25zb2xlLmxvZyhgQ29tbWFuZDogVG9nZ2xpbmcgcHJldmlldyBmb3IgJHthY3RpdmVWaWV3LmZpbGUucGF0aH1gKTtcbiAgICAgICAgICAgIGF3YWl0IHRoaXMudG9nZ2xlUHJldmlldyhhY3RpdmVWaWV3LmZpbGUpO1xuICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBuZXcgTm90aWNlKCdDdXJyZW50IGZpbGUgaXMgbm90IGEgUXVhcnRvIGRvY3VtZW50Jyk7XG4gICAgICAgICAgfVxuICAgICAgICB9LFxuICAgICAgICBob3RrZXlzOiBbeyBtb2RpZmllcnM6IFsnQ3RybCcsICdTaGlmdCddLCBrZXk6ICdwJyB9XSxcbiAgICAgIH0pO1xuXG4gICAgICBjb25zb2xlLmxvZygnQ29tbWFuZHMgYWRkZWQnKTtcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgY29uc29sZS5lcnJvcignRXJyb3IgbG9hZGluZyBwbHVnaW46JywgZXJyb3IpO1xuICAgICAgbmV3IE5vdGljZShcbiAgICAgICAgJ0ZhaWxlZCB0byBsb2FkIFFtZEFzTWRQbHVnaW4uIENoZWNrIHRoZSBkZXZlbG9wZXIgY29uc29sZSBmb3IgZGV0YWlscy4nXG4gICAgICApO1xuICAgIH1cbiAgfVxuXG4gIG9udW5sb2FkKCkge1xuICAgIGNvbnNvbGUubG9nKCdQbHVnaW4gaXMgdW5sb2FkaW5nLi4uJyk7XG4gICAgdGhpcy5zdG9wQWxsUHJldmlld3MoKTtcbiAgfVxuXG4gIGFzeW5jIGxvYWRTZXR0aW5ncygpIHtcbiAgICB0aGlzLnNldHRpbmdzID0gT2JqZWN0LmFzc2lnbih7fSwgREVGQVVMVF9TRVRUSU5HUywgYXdhaXQgdGhpcy5sb2FkRGF0YSgpKTtcbiAgfVxuXG4gIGFzeW5jIHNhdmVTZXR0aW5ncygpIHtcbiAgICBhd2FpdCB0aGlzLnNhdmVEYXRhKHRoaXMuc2V0dGluZ3MpO1xuICB9XG5cbiAgaXNRdWFydG9GaWxlKGZpbGU6IFRGaWxlKTogYm9vbGVhbiB7XG4gICAgcmV0dXJuIGZpbGUuZXh0ZW5zaW9uID09PSAncW1kJztcbiAgfVxuXG4gIHJlZ2lzdGVyUW1kRXh0ZW5zaW9uKCkge1xuICAgIGNvbnNvbGUubG9nKCdSZWdpc3RlcmluZyAucW1kIGFzIG1hcmtkb3duLi4uJyk7XG4gICAgdGhpcy5yZWdpc3RlckV4dGVuc2lvbnMoWydxbWQnXSwgJ21hcmtkb3duJyk7XG4gICAgY29uc29sZS5sb2coJy5xbWQgcmVnaXN0ZXJlZCBhcyBtYXJrZG93bicpO1xuICB9XG5cbiAgYXN5bmMgdG9nZ2xlUHJldmlldyhmaWxlOiBURmlsZSkge1xuICAgIGlmICh0aGlzLmFjdGl2ZVByZXZpZXdQcm9jZXNzZXMuaGFzKGZpbGUucGF0aCkpIHtcbiAgICAgIGF3YWl0IHRoaXMuc3RvcFByZXZpZXcoZmlsZSk7XG4gICAgfSBlbHNlIHtcbiAgICAgIGF3YWl0IHRoaXMuc3RhcnRQcmV2aWV3KGZpbGUpO1xuICAgIH1cbiAgfVxuXG4gIGFzeW5jIHN0YXJ0UHJldmlldyhmaWxlOiBURmlsZSkge1xuICAgIGlmICh0aGlzLmFjdGl2ZVByZXZpZXdQcm9jZXNzZXMuaGFzKGZpbGUucGF0aCkpIHtcbiAgICAgIGNvbnNvbGUubG9nKGBQcmV2aWV3IGFscmVhZHkgcnVubmluZyBmb3I6ICR7ZmlsZS5wYXRofWApO1xuICAgICAgcmV0dXJuOyAvLyBQcmV2aWV3IGFscmVhZHkgcnVubmluZ1xuICAgIH1cblxuICAgIHRyeSB7XG4gICAgICBjb25zdCBhYnN0cmFjdEZpbGUgPSB0aGlzLmFwcC52YXVsdC5nZXRBYnN0cmFjdEZpbGVCeVBhdGgoZmlsZS5wYXRoKTtcbiAgICAgIGlmICghYWJzdHJhY3RGaWxlIHx8ICEoYWJzdHJhY3RGaWxlIGluc3RhbmNlb2YgVEZpbGUpKSB7XG4gICAgICAgIG5ldyBOb3RpY2UoYEZpbGUgJHtmaWxlLnBhdGh9IG5vdCBmb3VuZGApO1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG4gICAgICBjb25zdCBmaWxlUGF0aCA9ICh0aGlzLmFwcC52YXVsdC5hZGFwdGVyIGFzIGFueSkuZ2V0RnVsbFBhdGgoYWJzdHJhY3RGaWxlLnBhdGgpO1xuICAgICAgY29uc3Qgd29ya2luZ0RpciA9IHBhdGguZGlybmFtZShmaWxlUGF0aCk7XG5cbiAgICAgIGNvbnNvbGUubG9nKGBSZXNvbHZlZCBmaWxlIHBhdGg6ICR7ZmlsZVBhdGh9YCk7XG4gICAgICBjb25zb2xlLmxvZyhgV29ya2luZyBkaXJlY3Rvcnk6ICR7d29ya2luZ0Rpcn1gKTtcblxuICAgICAgY29uc3QgcHJvY2VzcyA9IHNwYXduKHRoaXMuc2V0dGluZ3MucXVhcnRvUGF0aCwgWydwcmV2aWV3JywgZmlsZVBhdGhdLCB7XG4gICAgICAgIGN3ZDogd29ya2luZ0RpcixcbiAgICAgIH0pO1xuXG4gICAgICBsZXQgcHJldmlld1VybDogc3RyaW5nIHwgbnVsbCA9IG51bGw7XG5cbiAgICAgIHByb2Nlc3Muc3Rkb3V0Py5vbignZGF0YScsIChkYXRhOiBCdWZmZXIpID0+IHtcbiAgICAgICAgY29uc3Qgb3V0cHV0ID0gZGF0YS50b1N0cmluZygpO1xuICAgICAgICBjb25zb2xlLmxvZyhgUXVhcnRvIFByZXZpZXcgT3V0cHV0OiAke291dHB1dH1gKTtcblxuICAgICAgICBpZiAob3V0cHV0LmluY2x1ZGVzKCdCcm93c2UgYXQnKSkge1xuICAgICAgICAgIGNvbnN0IG1hdGNoID0gb3V0cHV0Lm1hdGNoKC9Ccm93c2UgYXRcXHMrKGh0dHA6XFwvXFwvW15cXHNdKykvKTtcbiAgICAgICAgICBpZiAobWF0Y2ggJiYgbWF0Y2hbMV0pIHtcbiAgICAgICAgICAgIHByZXZpZXdVcmwgPSBtYXRjaFsxXTtcbiAgICAgICAgICAgIG5ldyBOb3RpY2UoYFByZXZpZXcgYXZhaWxhYmxlIGF0ICR7cHJldmlld1VybH1gKTtcblxuICAgICAgICAgIC8vIE9wZW4gdGhlIHByZXZpZXcgaW4gYSBuZXcgdGFiXG4gICAgICAgIC8vIE9wZW4gdGhlIHByZXZpZXcgaW4gYSBuZXcgdGFiXG4gICAgICAgIGNvbnN0IGxlYWYgPSB0aGlzLmFwcC53b3Jrc3BhY2UuZ2V0TGVhZigndGFiJyk7XG4gICAgICAgIGxlYWYuc2V0Vmlld1N0YXRlKHtcbiAgICAgICAgICB0eXBlOiAnd2Vidmlld2VyJyxcbiAgICAgICAgICBhY3RpdmU6IHRydWUsXG4gICAgICAgICAgc3RhdGU6IHtcbiAgICAgICAgICAgIHVybDogcHJldmlld1VybCxcbiAgICAgICAgICB9LFxuICAgICAgICB9KTtcbiAgICAgICAgICAgLy8gUmV2ZWFsIHRoZSB0YWJcbiAgICAgICAgICAgdGhpcy5hcHAud29ya3NwYWNlLnJldmVhbExlYWYobGVhZik7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICB9KTtcblxuICAgICAgcHJvY2Vzcy5zdGRlcnI/Lm9uKCdkYXRhJywgKGRhdGE6IEJ1ZmZlcikgPT4ge1xuICAgICAgICBjb25zb2xlLmVycm9yKGBRdWFydG8gUHJldmlldyBFcnJvcjogJHtkYXRhfWApO1xuICAgICAgICBuZXcgTm90aWNlKGBRdWFydG8gUHJldmlldyBFcnJvcjogJHtkYXRhfWApO1xuICAgICAgfSk7XG5cbiAgICAgIHByb2Nlc3Mub24oJ2Nsb3NlJywgKGNvZGU6IG51bWJlciB8IG51bGwpID0+IHtcbiAgICAgICAgaWYgKGNvZGUgIT09IG51bGwgJiYgY29kZSAhPT0gMCkge1xuICAgICAgICAgIG5ldyBOb3RpY2UoYFF1YXJ0byBwcmV2aWV3IHByb2Nlc3MgZXhpdGVkIHdpdGggY29kZSAke2NvZGV9YCk7XG4gICAgICAgIH1cbiAgICAgICAgdGhpcy5hY3RpdmVQcmV2aWV3UHJvY2Vzc2VzLmRlbGV0ZShmaWxlLnBhdGgpO1xuICAgICAgfSk7XG5cbiAgICAgIHRoaXMuYWN0aXZlUHJldmlld1Byb2Nlc3Nlcy5zZXQoZmlsZS5wYXRoLCBwcm9jZXNzKTtcbiAgICAgIG5ldyBOb3RpY2UoJ1F1YXJ0byBwcmV2aWV3IHN0YXJ0ZWQnKTtcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgY29uc29sZS5lcnJvcignRmFpbGVkIHRvIHN0YXJ0IFF1YXJ0byBwcmV2aWV3OicsIGVycm9yKTtcbiAgICAgIG5ldyBOb3RpY2UoJ0ZhaWxlZCB0byBzdGFydCBRdWFydG8gcHJldmlldycpO1xuICAgIH1cbiAgfVxuXG4gIGFzeW5jIHN0b3BQcmV2aWV3KGZpbGU6IFRGaWxlKSB7XG4gICAgY29uc3QgcHJvY2VzcyA9IHRoaXMuYWN0aXZlUHJldmlld1Byb2Nlc3Nlcy5nZXQoZmlsZS5wYXRoKTtcbiAgICBpZiAocHJvY2Vzcykge1xuICAgICAgaWYgKCFwcm9jZXNzLmtpbGxlZCkge1xuICAgICAgICBwcm9jZXNzLmtpbGwoKTtcbiAgICAgIH1cbiAgICAgIHRoaXMuYWN0aXZlUHJldmlld1Byb2Nlc3Nlcy5kZWxldGUoZmlsZS5wYXRoKTtcbiAgICAgIG5ldyBOb3RpY2UoJ1F1YXJ0byBwcmV2aWV3IHN0b3BwZWQnKTtcbiAgICB9XG4gIH1cblxuICBzdG9wQWxsUHJldmlld3MoKSB7XG4gICAgdGhpcy5hY3RpdmVQcmV2aWV3UHJvY2Vzc2VzLmZvckVhY2goKHByb2Nlc3MsIGZpbGVQYXRoKSA9PiB7XG4gICAgICBpZiAoIXByb2Nlc3Mua2lsbGVkKSB7XG4gICAgICAgIHByb2Nlc3Mua2lsbCgpO1xuICAgICAgfVxuICAgICAgdGhpcy5hY3RpdmVQcmV2aWV3UHJvY2Vzc2VzLmRlbGV0ZShmaWxlUGF0aCk7XG4gICAgfSk7XG4gICAgaWYgKHRoaXMuYWN0aXZlUHJldmlld1Byb2Nlc3Nlcy5zaXplID4gMCkge1xuICAgICAgbmV3IE5vdGljZSgnQWxsIFF1YXJ0byBwcmV2aWV3cyBzdG9wcGVkJyk7XG4gICAgfVxuICB9XG59XG5cbmNsYXNzIFFtZFNldHRpbmdUYWIgZXh0ZW5kcyBQbHVnaW5TZXR0aW5nVGFiIHtcbiAgcGx1Z2luOiBRbWRBc01kUGx1Z2luO1xuXG4gIGNvbnN0cnVjdG9yKGFwcDogQXBwLCBwbHVnaW46IFFtZEFzTWRQbHVnaW4pIHtcbiAgICBzdXBlcihhcHAsIHBsdWdpbik7XG4gICAgdGhpcy5wbHVnaW4gPSBwbHVnaW47XG4gIH1cblxuICBkaXNwbGF5KCk6IHZvaWQge1xuICAgIGNvbnN0IHsgY29udGFpbmVyRWwgfSA9IHRoaXM7XG4gICAgY29udGFpbmVyRWwuZW1wdHkoKTtcblxuICAgIGNvbnNvbGUubG9nKCdSZW5kZXJpbmcgc2V0dGluZ3MgdGFiLi4uJyk7XG5cbiAgICBjb250YWluZXJFbC5jcmVhdGVFbCgnaDInLCB7IHRleHQ6ICdRdWFydG8gUHJldmlldyBTZXR0aW5ncycgfSk7XG5cbiAgICBuZXcgU2V0dGluZyhjb250YWluZXJFbClcbiAgICAgIC5zZXROYW1lKCdRdWFydG8gUGF0aCcpXG4gICAgICAuc2V0RGVzYygnUGF0aCB0byBRdWFydG8gZXhlY3V0YWJsZSAoZS5nLiwgcXVhcnRvLCAvdXNyL2xvY2FsL2Jpbi9xdWFydG8pJylcbiAgICAgIC5hZGRUZXh0KCh0ZXh0KSA9PlxuICAgICAgICB0ZXh0XG4gICAgICAgICAgLnNldFBsYWNlaG9sZGVyKCdxdWFydG8nKVxuICAgICAgICAgIC5zZXRWYWx1ZSh0aGlzLnBsdWdpbi5zZXR0aW5ncy5xdWFydG9QYXRoKVxuICAgICAgICAgIC5vbkNoYW5nZShhc3luYyAodmFsdWUpID0+IHtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKGBRdWFydG8gcGF0aCBjaGFuZ2VkIHRvOiAke3ZhbHVlfWApO1xuICAgICAgICAgICAgdGhpcy5wbHVnaW4uc2V0dGluZ3MucXVhcnRvUGF0aCA9IHZhbHVlO1xuICAgICAgICAgICAgYXdhaXQgdGhpcy5wbHVnaW4uc2F2ZVNldHRpbmdzKCk7XG4gICAgICAgICAgfSlcbiAgICAgICk7XG5cbiAgICBuZXcgU2V0dGluZyhjb250YWluZXJFbClcbiAgICAgIC5zZXROYW1lKCdBdXRvIFByZXZpZXcnKVxuICAgICAgLnNldERlc2MoJ0F1dG9tYXRpY2FsbHkgc3RhcnQgcHJldmlldyB3aGVuIG9wZW5pbmcgUXVhcnRvIGZpbGVzJylcbiAgICAgIC5hZGRUb2dnbGUoKHRvZ2dsZSkgPT5cbiAgICAgICAgdG9nZ2xlXG4gICAgICAgICAgLnNldFZhbHVlKHRoaXMucGx1Z2luLnNldHRpbmdzLmF1dG9QcmV2aWV3KVxuICAgICAgICAgIC5vbkNoYW5nZShhc3luYyAodmFsdWUpID0+IHtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKGBBdXRvLXByZXZpZXcgc2V0dGluZyBjaGFuZ2VkIHRvOiAke3ZhbHVlfWApO1xuICAgICAgICAgICAgdGhpcy5wbHVnaW4uc2V0dGluZ3MuYXV0b1ByZXZpZXcgPSB2YWx1ZTtcbiAgICAgICAgICAgIGF3YWl0IHRoaXMucGx1Z2luLnNhdmVTZXR0aW5ncygpO1xuICAgICAgICAgIH0pXG4gICAgICApO1xuXG4gICAgbmV3IFNldHRpbmcoY29udGFpbmVyRWwpXG4gICAgICAuc2V0TmFtZSgnRW5hYmxlIExpbmtpbmcgdG8gUXVhcnRvIEZpbGVzJylcbiAgICAgIC5zZXREZXNjKFxuICAgICAgICAnQWxsb3cgbGlua2luZyB0byBgLnFtZGAgZmlsZXMgd2l0aG91dCBlbmFibGluZyBcIkRldGVjdCBBbGwgRmlsZSBFeHRlbnNpb25zXCInXG4gICAgICApXG4gICAgICAuYWRkVG9nZ2xlKCh0b2dnbGUpID0+XG4gICAgICAgIHRvZ2dsZVxuICAgICAgICAgIC5zZXRWYWx1ZSh0aGlzLnBsdWdpbi5zZXR0aW5ncy5lbmFibGVRbWRMaW5raW5nKVxuICAgICAgICAgIC5vbkNoYW5nZShhc3luYyAodmFsdWUpID0+IHtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKGBFbmFibGUgUU1EIExpbmtpbmcgc2V0dGluZyBjaGFuZ2VkIHRvOiAke3ZhbHVlfWApO1xuICAgICAgICAgICAgdGhpcy5wbHVnaW4uc2V0dGluZ3MuZW5hYmxlUW1kTGlua2luZyA9IHZhbHVlO1xuXG4gICAgICAgICAgICBpZiAodmFsdWUpIHtcbiAgICAgICAgICAgICAgdGhpcy5wbHVnaW4ucmVnaXN0ZXJRbWRFeHRlbnNpb24oKTtcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgIGNvbnNvbGUubG9nKFxuICAgICAgICAgICAgICAgICcucW1kIGxpbmtpbmcgZGlzYWJsZWQuIFJlc3RhcnQgT2JzaWRpYW4gaWYgcmVxdWlyZWQuJ1xuICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICBhd2FpdCB0aGlzLnBsdWdpbi5zYXZlU2V0dGluZ3MoKTtcbiAgICAgICAgICB9KVxuICAgICAgKTtcblxuICAgIGNvbnNvbGUubG9nKCdTZXR0aW5ncyB0YWIgcmVuZGVyZWQgc3VjY2Vzc2Z1bGx5Jyk7XG4gIH1cbn0iXSwibmFtZXMiOlsiUGx1Z2luIiwiTWFya2Rvd25WaWV3IiwiTm90aWNlIiwiVEZpbGUiLCJwYXRoIiwic3Bhd24iLCJQbHVnaW5TZXR0aW5nVGFiIiwiU2V0dGluZyJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQW1CQSxNQUFNLGdCQUFnQixHQUFzQjtBQUMxQyxJQUFBLFVBQVUsRUFBRSxRQUFRO0FBQ3BCLElBQUEsV0FBVyxFQUFFLEtBQUs7QUFDbEIsSUFBQSxnQkFBZ0IsRUFBRSxLQUFLO0NBQ3hCLENBQUM7QUFFbUIsTUFBQSxhQUFjLFNBQVFBLGVBQU0sQ0FBQTtBQUFqRCxJQUFBLFdBQUEsR0FBQTs7QUFFRSxRQUFBLElBQUEsQ0FBQSxzQkFBc0IsR0FBOEIsSUFBSSxHQUFHLEVBQUUsQ0FBQztLQTZLL0Q7QUEzS0MsSUFBQSxNQUFNLE1BQU0sR0FBQTtBQUNWLFFBQUEsT0FBTyxDQUFDLEdBQUcsQ0FBQyxzQkFBc0IsQ0FBQyxDQUFDO0FBQ3BDLFFBQUEsSUFBSTtBQUNGLFlBQUEsTUFBTSxJQUFJLENBQUMsWUFBWSxFQUFFLENBQUM7WUFDMUIsT0FBTyxDQUFDLEdBQUcsQ0FBQyxrQkFBa0IsRUFBRSxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUM7QUFFL0MsWUFBQSxJQUFJLElBQUksQ0FBQyxRQUFRLENBQUMsZ0JBQWdCLEVBQUU7Z0JBQ2xDLElBQUksQ0FBQyxvQkFBb0IsRUFBRSxDQUFDO2FBQzdCO0FBRUQsWUFBQSxJQUFJLENBQUMsYUFBYSxDQUFDLElBQUksYUFBYSxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUUsSUFBSSxDQUFDLENBQUMsQ0FBQztBQUN0RCxZQUFBLE9BQU8sQ0FBQyxHQUFHLENBQUMsaUNBQWlDLENBQUMsQ0FBQztZQUUvQyxJQUFJLENBQUMsYUFBYSxDQUFDLEtBQUssRUFBRSx1QkFBdUIsRUFBRSxPQUFPLEdBQUcsS0FBSTtBQUMvRCxnQkFBQSxNQUFNLFVBQVUsR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLFNBQVMsQ0FBQyxtQkFBbUIsQ0FBQ0MscUJBQVksQ0FBQyxDQUFDO0FBQ3hFLGdCQUFBLElBQUksVUFBVSxFQUFFLElBQUksSUFBSSxJQUFJLENBQUMsWUFBWSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsRUFBRTtvQkFDMUQsT0FBTyxDQUFDLEdBQUcsQ0FBQyxDQUF5QixzQkFBQSxFQUFBLFVBQVUsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFFLENBQUEsQ0FBQyxDQUFDO29CQUM3RCxNQUFNLElBQUksQ0FBQyxhQUFhLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxDQUFDO2lCQUMzQztxQkFBTTtBQUNMLG9CQUFBLElBQUlDLGVBQU0sQ0FBQyx1Q0FBdUMsQ0FBQyxDQUFDO2lCQUNyRDtBQUNILGFBQUMsQ0FBQyxDQUFDO0FBQ0gsWUFBQSxPQUFPLENBQUMsR0FBRyxDQUFDLG1CQUFtQixDQUFDLENBQUM7WUFFakMsSUFBSSxDQUFDLFVBQVUsQ0FBQztBQUNkLGdCQUFBLEVBQUUsRUFBRSx1QkFBdUI7QUFDM0IsZ0JBQUEsSUFBSSxFQUFFLHVCQUF1QjtnQkFDN0IsUUFBUSxFQUFFLFlBQVc7QUFDbkIsb0JBQUEsTUFBTSxVQUFVLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxTQUFTLENBQUMsbUJBQW1CLENBQUNELHFCQUFZLENBQUMsQ0FBQztBQUN4RSxvQkFBQSxJQUFJLFVBQVUsRUFBRSxJQUFJLElBQUksSUFBSSxDQUFDLFlBQVksQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLEVBQUU7d0JBQzFELE9BQU8sQ0FBQyxHQUFHLENBQUMsQ0FBaUMsOEJBQUEsRUFBQSxVQUFVLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBRSxDQUFBLENBQUMsQ0FBQzt3QkFDckUsTUFBTSxJQUFJLENBQUMsYUFBYSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsQ0FBQztxQkFDM0M7eUJBQU07QUFDTCx3QkFBQSxJQUFJQyxlQUFNLENBQUMsdUNBQXVDLENBQUMsQ0FBQztxQkFDckQ7aUJBQ0Y7QUFDRCxnQkFBQSxPQUFPLEVBQUUsQ0FBQyxFQUFFLFNBQVMsRUFBRSxDQUFDLE1BQU0sRUFBRSxPQUFPLENBQUMsRUFBRSxHQUFHLEVBQUUsR0FBRyxFQUFFLENBQUM7QUFDdEQsYUFBQSxDQUFDLENBQUM7QUFFSCxZQUFBLE9BQU8sQ0FBQyxHQUFHLENBQUMsZ0JBQWdCLENBQUMsQ0FBQztTQUMvQjtRQUFDLE9BQU8sS0FBSyxFQUFFO0FBQ2QsWUFBQSxPQUFPLENBQUMsS0FBSyxDQUFDLHVCQUF1QixFQUFFLEtBQUssQ0FBQyxDQUFDO0FBQzlDLFlBQUEsSUFBSUEsZUFBTSxDQUNSLHdFQUF3RSxDQUN6RSxDQUFDO1NBQ0g7S0FDRjtJQUVELFFBQVEsR0FBQTtBQUNOLFFBQUEsT0FBTyxDQUFDLEdBQUcsQ0FBQyx3QkFBd0IsQ0FBQyxDQUFDO1FBQ3RDLElBQUksQ0FBQyxlQUFlLEVBQUUsQ0FBQztLQUN4QjtBQUVELElBQUEsTUFBTSxZQUFZLEdBQUE7QUFDaEIsUUFBQSxJQUFJLENBQUMsUUFBUSxHQUFHLE1BQU0sQ0FBQyxNQUFNLENBQUMsRUFBRSxFQUFFLGdCQUFnQixFQUFFLE1BQU0sSUFBSSxDQUFDLFFBQVEsRUFBRSxDQUFDLENBQUM7S0FDNUU7QUFFRCxJQUFBLE1BQU0sWUFBWSxHQUFBO1FBQ2hCLE1BQU0sSUFBSSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUM7S0FDcEM7QUFFRCxJQUFBLFlBQVksQ0FBQyxJQUFXLEVBQUE7QUFDdEIsUUFBQSxPQUFPLElBQUksQ0FBQyxTQUFTLEtBQUssS0FBSyxDQUFDO0tBQ2pDO0lBRUQsb0JBQW9CLEdBQUE7QUFDbEIsUUFBQSxPQUFPLENBQUMsR0FBRyxDQUFDLGlDQUFpQyxDQUFDLENBQUM7UUFDL0MsSUFBSSxDQUFDLGtCQUFrQixDQUFDLENBQUMsS0FBSyxDQUFDLEVBQUUsVUFBVSxDQUFDLENBQUM7QUFDN0MsUUFBQSxPQUFPLENBQUMsR0FBRyxDQUFDLDZCQUE2QixDQUFDLENBQUM7S0FDNUM7SUFFRCxNQUFNLGFBQWEsQ0FBQyxJQUFXLEVBQUE7UUFDN0IsSUFBSSxJQUFJLENBQUMsc0JBQXNCLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsRUFBRTtBQUM5QyxZQUFBLE1BQU0sSUFBSSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsQ0FBQztTQUM5QjthQUFNO0FBQ0wsWUFBQSxNQUFNLElBQUksQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLENBQUM7U0FDL0I7S0FDRjtJQUVELE1BQU0sWUFBWSxDQUFDLElBQVcsRUFBQTtRQUM1QixJQUFJLElBQUksQ0FBQyxzQkFBc0IsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxFQUFFO1lBQzlDLE9BQU8sQ0FBQyxHQUFHLENBQUMsQ0FBQSw2QkFBQSxFQUFnQyxJQUFJLENBQUMsSUFBSSxDQUFFLENBQUEsQ0FBQyxDQUFDO0FBQ3pELFlBQUEsT0FBTztTQUNSO0FBRUQsUUFBQSxJQUFJO0FBQ0YsWUFBQSxNQUFNLFlBQVksR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxxQkFBcUIsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7WUFDckUsSUFBSSxDQUFDLFlBQVksSUFBSSxFQUFFLFlBQVksWUFBWUMsY0FBSyxDQUFDLEVBQUU7Z0JBQ3JELElBQUlELGVBQU0sQ0FBQyxDQUFRLEtBQUEsRUFBQSxJQUFJLENBQUMsSUFBSSxDQUFBLFVBQUEsQ0FBWSxDQUFDLENBQUM7Z0JBQzFDLE9BQU87YUFDUjtBQUNELFlBQUEsTUFBTSxRQUFRLEdBQUksSUFBSSxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsT0FBZSxDQUFDLFdBQVcsQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLENBQUM7WUFDaEYsTUFBTSxVQUFVLEdBQUdFLGVBQUksQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLENBQUM7QUFFMUMsWUFBQSxPQUFPLENBQUMsR0FBRyxDQUFDLHVCQUF1QixRQUFRLENBQUEsQ0FBRSxDQUFDLENBQUM7QUFDL0MsWUFBQSxPQUFPLENBQUMsR0FBRyxDQUFDLHNCQUFzQixVQUFVLENBQUEsQ0FBRSxDQUFDLENBQUM7QUFFaEQsWUFBQSxNQUFNLE9BQU8sR0FBR0MsbUJBQUssQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLFVBQVUsRUFBRSxDQUFDLFNBQVMsRUFBRSxRQUFRLENBQUMsRUFBRTtBQUNyRSxnQkFBQSxHQUFHLEVBQUUsVUFBVTtBQUNoQixhQUFBLENBQUMsQ0FBQztZQUVILElBQUksVUFBVSxHQUFrQixJQUFJLENBQUM7WUFFckMsT0FBTyxDQUFDLE1BQU0sRUFBRSxFQUFFLENBQUMsTUFBTSxFQUFFLENBQUMsSUFBWSxLQUFJO0FBQzFDLGdCQUFBLE1BQU0sTUFBTSxHQUFHLElBQUksQ0FBQyxRQUFRLEVBQUUsQ0FBQztBQUMvQixnQkFBQSxPQUFPLENBQUMsR0FBRyxDQUFDLDBCQUEwQixNQUFNLENBQUEsQ0FBRSxDQUFDLENBQUM7QUFFaEQsZ0JBQUEsSUFBSSxNQUFNLENBQUMsUUFBUSxDQUFDLFdBQVcsQ0FBQyxFQUFFO29CQUNoQyxNQUFNLEtBQUssR0FBRyxNQUFNLENBQUMsS0FBSyxDQUFDLCtCQUErQixDQUFDLENBQUM7QUFDNUQsb0JBQUEsSUFBSSxLQUFLLElBQUksS0FBSyxDQUFDLENBQUMsQ0FBQyxFQUFFO0FBQ3JCLHdCQUFBLFVBQVUsR0FBRyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDdEIsd0JBQUEsSUFBSUgsZUFBTSxDQUFDLENBQUEscUJBQUEsRUFBd0IsVUFBVSxDQUFBLENBQUUsQ0FBQyxDQUFDOzs7QUFJckQsd0JBQUEsTUFBTSxJQUFJLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxTQUFTLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxDQUFDO3dCQUMvQyxJQUFJLENBQUMsWUFBWSxDQUFDO0FBQ2hCLDRCQUFBLElBQUksRUFBRSxXQUFXO0FBQ2pCLDRCQUFBLE1BQU0sRUFBRSxJQUFJO0FBQ1osNEJBQUEsS0FBSyxFQUFFO0FBQ0wsZ0NBQUEsR0FBRyxFQUFFLFVBQVU7QUFDaEIsNkJBQUE7QUFDRix5QkFBQSxDQUFDLENBQUM7O3dCQUVBLElBQUksQ0FBQyxHQUFHLENBQUMsU0FBUyxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsQ0FBQztxQkFDcEM7aUJBQ0Y7QUFDSCxhQUFDLENBQUMsQ0FBQztZQUVILE9BQU8sQ0FBQyxNQUFNLEVBQUUsRUFBRSxDQUFDLE1BQU0sRUFBRSxDQUFDLElBQVksS0FBSTtBQUMxQyxnQkFBQSxPQUFPLENBQUMsS0FBSyxDQUFDLHlCQUF5QixJQUFJLENBQUEsQ0FBRSxDQUFDLENBQUM7QUFDL0MsZ0JBQUEsSUFBSUEsZUFBTSxDQUFDLENBQUEsc0JBQUEsRUFBeUIsSUFBSSxDQUFBLENBQUUsQ0FBQyxDQUFDO0FBQzlDLGFBQUMsQ0FBQyxDQUFDO1lBRUgsT0FBTyxDQUFDLEVBQUUsQ0FBQyxPQUFPLEVBQUUsQ0FBQyxJQUFtQixLQUFJO2dCQUMxQyxJQUFJLElBQUksS0FBSyxJQUFJLElBQUksSUFBSSxLQUFLLENBQUMsRUFBRTtBQUMvQixvQkFBQSxJQUFJQSxlQUFNLENBQUMsQ0FBQSx3Q0FBQSxFQUEyQyxJQUFJLENBQUEsQ0FBRSxDQUFDLENBQUM7aUJBQy9EO2dCQUNELElBQUksQ0FBQyxzQkFBc0IsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO0FBQ2hELGFBQUMsQ0FBQyxDQUFDO1lBRUgsSUFBSSxDQUFDLHNCQUFzQixDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsSUFBSSxFQUFFLE9BQU8sQ0FBQyxDQUFDO0FBQ3BELFlBQUEsSUFBSUEsZUFBTSxDQUFDLHdCQUF3QixDQUFDLENBQUM7U0FDdEM7UUFBQyxPQUFPLEtBQUssRUFBRTtBQUNkLFlBQUEsT0FBTyxDQUFDLEtBQUssQ0FBQyxpQ0FBaUMsRUFBRSxLQUFLLENBQUMsQ0FBQztBQUN4RCxZQUFBLElBQUlBLGVBQU0sQ0FBQyxnQ0FBZ0MsQ0FBQyxDQUFDO1NBQzlDO0tBQ0Y7SUFFRCxNQUFNLFdBQVcsQ0FBQyxJQUFXLEVBQUE7QUFDM0IsUUFBQSxNQUFNLE9BQU8sR0FBRyxJQUFJLENBQUMsc0JBQXNCLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUMzRCxJQUFJLE9BQU8sRUFBRTtBQUNYLFlBQUEsSUFBSSxDQUFDLE9BQU8sQ0FBQyxNQUFNLEVBQUU7Z0JBQ25CLE9BQU8sQ0FBQyxJQUFJLEVBQUUsQ0FBQzthQUNoQjtZQUNELElBQUksQ0FBQyxzQkFBc0IsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO0FBQzlDLFlBQUEsSUFBSUEsZUFBTSxDQUFDLHdCQUF3QixDQUFDLENBQUM7U0FDdEM7S0FDRjtJQUVELGVBQWUsR0FBQTtRQUNiLElBQUksQ0FBQyxzQkFBc0IsQ0FBQyxPQUFPLENBQUMsQ0FBQyxPQUFPLEVBQUUsUUFBUSxLQUFJO0FBQ3hELFlBQUEsSUFBSSxDQUFDLE9BQU8sQ0FBQyxNQUFNLEVBQUU7Z0JBQ25CLE9BQU8sQ0FBQyxJQUFJLEVBQUUsQ0FBQzthQUNoQjtBQUNELFlBQUEsSUFBSSxDQUFDLHNCQUFzQixDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsQ0FBQztBQUMvQyxTQUFDLENBQUMsQ0FBQztRQUNILElBQUksSUFBSSxDQUFDLHNCQUFzQixDQUFDLElBQUksR0FBRyxDQUFDLEVBQUU7QUFDeEMsWUFBQSxJQUFJQSxlQUFNLENBQUMsNkJBQTZCLENBQUMsQ0FBQztTQUMzQztLQUNGO0FBQ0YsQ0FBQTtBQUVELE1BQU0sYUFBYyxTQUFRSSx5QkFBZ0IsQ0FBQTtJQUcxQyxXQUFZLENBQUEsR0FBUSxFQUFFLE1BQXFCLEVBQUE7QUFDekMsUUFBQSxLQUFLLENBQUMsR0FBRyxFQUFFLE1BQU0sQ0FBQyxDQUFDO0FBQ25CLFFBQUEsSUFBSSxDQUFDLE1BQU0sR0FBRyxNQUFNLENBQUM7S0FDdEI7SUFFRCxPQUFPLEdBQUE7QUFDTCxRQUFBLE1BQU0sRUFBRSxXQUFXLEVBQUUsR0FBRyxJQUFJLENBQUM7UUFDN0IsV0FBVyxDQUFDLEtBQUssRUFBRSxDQUFDO0FBRXBCLFFBQUEsT0FBTyxDQUFDLEdBQUcsQ0FBQywyQkFBMkIsQ0FBQyxDQUFDO1FBRXpDLFdBQVcsQ0FBQyxRQUFRLENBQUMsSUFBSSxFQUFFLEVBQUUsSUFBSSxFQUFFLHlCQUF5QixFQUFFLENBQUMsQ0FBQztRQUVoRSxJQUFJQyxnQkFBTyxDQUFDLFdBQVcsQ0FBQzthQUNyQixPQUFPLENBQUMsYUFBYSxDQUFDO2FBQ3RCLE9BQU8sQ0FBQyxpRUFBaUUsQ0FBQztBQUMxRSxhQUFBLE9BQU8sQ0FBQyxDQUFDLElBQUksS0FDWixJQUFJO2FBQ0QsY0FBYyxDQUFDLFFBQVEsQ0FBQzthQUN4QixRQUFRLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsVUFBVSxDQUFDO0FBQ3pDLGFBQUEsUUFBUSxDQUFDLE9BQU8sS0FBSyxLQUFJO0FBQ3hCLFlBQUEsT0FBTyxDQUFDLEdBQUcsQ0FBQywyQkFBMkIsS0FBSyxDQUFBLENBQUUsQ0FBQyxDQUFDO1lBQ2hELElBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLFVBQVUsR0FBRyxLQUFLLENBQUM7QUFDeEMsWUFBQSxNQUFNLElBQUksQ0FBQyxNQUFNLENBQUMsWUFBWSxFQUFFLENBQUM7U0FDbEMsQ0FBQyxDQUNMLENBQUM7UUFFSixJQUFJQSxnQkFBTyxDQUFDLFdBQVcsQ0FBQzthQUNyQixPQUFPLENBQUMsY0FBYyxDQUFDO2FBQ3ZCLE9BQU8sQ0FBQyx1REFBdUQsQ0FBQztBQUNoRSxhQUFBLFNBQVMsQ0FBQyxDQUFDLE1BQU0sS0FDaEIsTUFBTTthQUNILFFBQVEsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxXQUFXLENBQUM7QUFDMUMsYUFBQSxRQUFRLENBQUMsT0FBTyxLQUFLLEtBQUk7QUFDeEIsWUFBQSxPQUFPLENBQUMsR0FBRyxDQUFDLG9DQUFvQyxLQUFLLENBQUEsQ0FBRSxDQUFDLENBQUM7WUFDekQsSUFBSSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsV0FBVyxHQUFHLEtBQUssQ0FBQztBQUN6QyxZQUFBLE1BQU0sSUFBSSxDQUFDLE1BQU0sQ0FBQyxZQUFZLEVBQUUsQ0FBQztTQUNsQyxDQUFDLENBQ0wsQ0FBQztRQUVKLElBQUlBLGdCQUFPLENBQUMsV0FBVyxDQUFDO2FBQ3JCLE9BQU8sQ0FBQyxnQ0FBZ0MsQ0FBQzthQUN6QyxPQUFPLENBQ04sNkVBQTZFLENBQzlFO0FBQ0EsYUFBQSxTQUFTLENBQUMsQ0FBQyxNQUFNLEtBQ2hCLE1BQU07YUFDSCxRQUFRLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsZ0JBQWdCLENBQUM7QUFDL0MsYUFBQSxRQUFRLENBQUMsT0FBTyxLQUFLLEtBQUk7QUFDeEIsWUFBQSxPQUFPLENBQUMsR0FBRyxDQUFDLDBDQUEwQyxLQUFLLENBQUEsQ0FBRSxDQUFDLENBQUM7WUFDL0QsSUFBSSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsZ0JBQWdCLEdBQUcsS0FBSyxDQUFDO1lBRTlDLElBQUksS0FBSyxFQUFFO0FBQ1QsZ0JBQUEsSUFBSSxDQUFDLE1BQU0sQ0FBQyxvQkFBb0IsRUFBRSxDQUFDO2FBQ3BDO2lCQUFNO0FBQ0wsZ0JBQUEsT0FBTyxDQUFDLEdBQUcsQ0FDVCxzREFBc0QsQ0FDdkQsQ0FBQzthQUNIO0FBRUQsWUFBQSxNQUFNLElBQUksQ0FBQyxNQUFNLENBQUMsWUFBWSxFQUFFLENBQUM7U0FDbEMsQ0FBQyxDQUNMLENBQUM7QUFFSixRQUFBLE9BQU8sQ0FBQyxHQUFHLENBQUMsb0NBQW9DLENBQUMsQ0FBQztLQUNuRDtBQUNGOzs7OyJ9
