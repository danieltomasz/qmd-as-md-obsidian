'use strict';

var obsidian = require('obsidian');
var child_process = require('child_process');
var path = require('path');

function _interopNamespaceDefault(e) {
    var n = Object.create(null);
    if (e) {
        Object.keys(e).forEach(function (k) {
            if (k !== 'default') {
                var d = Object.getOwnPropertyDescriptor(e, k);
                Object.defineProperty(n, k, d.get ? d : {
                    enumerable: true,
                    get: function () { return e[k]; }
                });
            }
        });
    }
    n.default = e;
    return Object.freeze(n);
}

var path__namespace = /*#__PURE__*/_interopNamespaceDefault(path);

const DEFAULT_SETTINGS = {
    quartoPath: 'quarto',
    autoPreview: false,
    enableQmdLinking: false,
};
class QmdAsMdPlugin extends obsidian.Plugin {
    constructor() {
        super(...arguments);
        this.activePreviewProcesses = new Map();
    }
    async onload() {
        console.log('Plugin is loading...');
        try {
            await this.loadSettings();
            console.log('Settings loaded:', this.settings);
            if (this.settings.enableQmdLinking) {
                this.registerQmdExtension();
            }
            this.addSettingTab(new QmdSettingTab(this.app, this));
            console.log('Settings tab added successfully');
            this.addRibbonIcon('eye', 'Toggle Quarto Preview', async (evt) => {
                const activeView = this.app.workspace.getActiveViewOfType(obsidian.MarkdownView);
                if (activeView?.file && this.isQuartoFile(activeView.file)) {
                    console.log(`Toggling preview for: ${activeView.file.path}`);
                    await this.togglePreview(activeView.file);
                }
                else {
                    new obsidian.Notice('Current file is not a Quarto document');
                }
            });
            console.log('Ribbon icon added');
            this.addCommand({
                id: 'toggle-quarto-preview',
                name: 'Toggle Quarto Preview',
                callback: async () => {
                    const activeView = this.app.workspace.getActiveViewOfType(obsidian.MarkdownView);
                    if (activeView?.file && this.isQuartoFile(activeView.file)) {
                        console.log(`Command: Toggling preview for ${activeView.file.path}`);
                        await this.togglePreview(activeView.file);
                    }
                    else {
                        new obsidian.Notice('Current file is not a Quarto document');
                    }
                },
                hotkeys: [{ modifiers: ['Ctrl', 'Shift'], key: 'p' }],
            });
            console.log('Commands added');
        }
        catch (error) {
            console.error('Error loading plugin:', error);
            new obsidian.Notice('Failed to load QmdAsMdPlugin. Check the developer console for details.');
        }
    }
    onunload() {
        console.log('Plugin is unloading...');
        this.stopAllPreviews();
    }
    async loadSettings() {
        this.settings = Object.assign({}, DEFAULT_SETTINGS, await this.loadData());
    }
    async saveSettings() {
        await this.saveData(this.settings);
    }
    isQuartoFile(file) {
        return file.extension === 'qmd';
    }
    registerQmdExtension() {
        console.log('Registering .qmd as markdown...');
        this.registerExtensions(['qmd'], 'markdown');
        console.log('.qmd registered as markdown');
    }
    async togglePreview(file) {
        if (this.activePreviewProcesses.has(file.path)) {
            await this.stopPreview(file);
        }
        else {
            await this.startPreview(file);
        }
    }
    async startPreview(file) {
        if (this.activePreviewProcesses.has(file.path)) {
            console.log(`Preview already running for: ${file.path}`);
            return; // Preview already running
        }
        try {
            const abstractFile = this.app.vault.getAbstractFileByPath(file.path);
            if (!abstractFile || !(abstractFile instanceof obsidian.TFile)) {
                new obsidian.Notice(`File ${file.path} not found`);
                return;
            }
            const filePath = this.app.vault.adapter.getFullPath(abstractFile.path);
            const workingDir = path__namespace.dirname(filePath);
            console.log(`Resolved file path: ${filePath}`);
            console.log(`Working directory: ${workingDir}`);
            const process = child_process.spawn(this.settings.quartoPath, ['preview', filePath], {
                cwd: workingDir,
            });
            let previewUrl = null;
            process.stdout?.on('data', (data) => {
                const output = data.toString();
                console.log(`Quarto Preview Output: ${output}`);
                if (output.includes('Browse at')) {
                    const match = output.match(/Browse at\s+(http:\/\/[^\s]+)/);
                    if (match && match[1]) {
                        previewUrl = match[1];
                        new obsidian.Notice(`Preview available at ${previewUrl}`);
                    }
                }
            });
            process.stderr?.on('data', (data) => {
                console.error(`Quarto Preview Error: ${data}`);
                new obsidian.Notice(`Quarto Preview Error: ${data}`);
            });
            process.on('close', (code) => {
                if (code !== null && code !== 0) {
                    new obsidian.Notice(`Quarto preview process exited with code ${code}`);
                }
                this.activePreviewProcesses.delete(file.path);
            });
            this.activePreviewProcesses.set(file.path, process);
            new obsidian.Notice('Quarto preview started');
        }
        catch (error) {
            console.error('Failed to start Quarto preview:', error);
            new obsidian.Notice('Failed to start Quarto preview');
        }
    }
    async stopPreview(file) {
        const process = this.activePreviewProcesses.get(file.path);
        if (process) {
            if (!process.killed) {
                process.kill();
            }
            this.activePreviewProcesses.delete(file.path);
            new obsidian.Notice('Quarto preview stopped');
        }
    }
    stopAllPreviews() {
        this.activePreviewProcesses.forEach((process, filePath) => {
            if (!process.killed) {
                process.kill();
            }
            this.activePreviewProcesses.delete(filePath);
        });
        if (this.activePreviewProcesses.size > 0) {
            new obsidian.Notice('All Quarto previews stopped');
        }
    }
}
class QmdSettingTab extends obsidian.PluginSettingTab {
    constructor(app, plugin) {
        super(app, plugin);
        this.plugin = plugin;
    }
    display() {
        const { containerEl } = this;
        containerEl.empty();
        console.log('Rendering settings tab...');
        containerEl.createEl('h2', { text: 'Quarto Preview Settings' });
        new obsidian.Setting(containerEl)
            .setName('Quarto Path')
            .setDesc('Path to Quarto executable (e.g., quarto, /usr/local/bin/quarto)')
            .addText((text) => text
            .setPlaceholder('quarto')
            .setValue(this.plugin.settings.quartoPath)
            .onChange(async (value) => {
            console.log(`Quarto path changed to: ${value}`);
            this.plugin.settings.quartoPath = value;
            await this.plugin.saveSettings();
        }));
        new obsidian.Setting(containerEl)
            .setName('Auto Preview')
            .setDesc('Automatically start preview when opening Quarto files')
            .addToggle((toggle) => toggle
            .setValue(this.plugin.settings.autoPreview)
            .onChange(async (value) => {
            console.log(`Auto-preview setting changed to: ${value}`);
            this.plugin.settings.autoPreview = value;
            await this.plugin.saveSettings();
        }));
        new obsidian.Setting(containerEl)
            .setName('Enable Linking to Quarto Files')
            .setDesc('Allow linking to `.qmd` files without enabling "Detect All File Extensions"')
            .addToggle((toggle) => toggle
            .setValue(this.plugin.settings.enableQmdLinking)
            .onChange(async (value) => {
            console.log(`Enable QMD Linking setting changed to: ${value}`);
            this.plugin.settings.enableQmdLinking = value;
            if (value) {
                this.plugin.registerQmdExtension();
            }
            else {
                console.log('.qmd linking disabled. Restart Obsidian if required.');
            }
            await this.plugin.saveSettings();
        }));
        console.log('Settings tab rendered successfully');
    }
}

module.exports = QmdAsMdPlugin;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibWFpbi5qcyIsInNvdXJjZXMiOlsic3JjL21haW4udHMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtcbiAgUGx1Z2luLFxuICBOb3RpY2UsXG4gIFRGaWxlLFxuICBNYXJrZG93blZpZXcsXG4gIFBsdWdpblNldHRpbmdUYWIsXG4gIEFwcCxcbiAgU2V0dGluZyxcbiAgVEFic3RyYWN0RmlsZSxcbn0gZnJvbSAnb2JzaWRpYW4nO1xuaW1wb3J0IHsgc3Bhd24sIENoaWxkUHJvY2VzcyB9IGZyb20gJ2NoaWxkX3Byb2Nlc3MnO1xuaW1wb3J0ICogYXMgcGF0aCBmcm9tICdwYXRoJztcblxuaW50ZXJmYWNlIFFtZFBsdWdpblNldHRpbmdzIHtcbiAgcXVhcnRvUGF0aDogc3RyaW5nO1xuICBhdXRvUHJldmlldzogYm9vbGVhbjtcbiAgZW5hYmxlUW1kTGlua2luZzogYm9vbGVhbjtcbn1cblxuY29uc3QgREVGQVVMVF9TRVRUSU5HUzogUW1kUGx1Z2luU2V0dGluZ3MgPSB7XG4gIHF1YXJ0b1BhdGg6ICdxdWFydG8nLFxuICBhdXRvUHJldmlldzogZmFsc2UsXG4gIGVuYWJsZVFtZExpbmtpbmc6IGZhbHNlLFxufTtcblxuZXhwb3J0IGRlZmF1bHQgY2xhc3MgUW1kQXNNZFBsdWdpbiBleHRlbmRzIFBsdWdpbiB7XG4gIHNldHRpbmdzOiBRbWRQbHVnaW5TZXR0aW5ncztcbiAgYWN0aXZlUHJldmlld1Byb2Nlc3NlczogTWFwPHN0cmluZywgQ2hpbGRQcm9jZXNzPiA9IG5ldyBNYXAoKTtcblxuICBhc3luYyBvbmxvYWQoKSB7XG4gICAgY29uc29sZS5sb2coJ1BsdWdpbiBpcyBsb2FkaW5nLi4uJyk7XG4gICAgdHJ5IHtcbiAgICAgIGF3YWl0IHRoaXMubG9hZFNldHRpbmdzKCk7XG4gICAgICBjb25zb2xlLmxvZygnU2V0dGluZ3MgbG9hZGVkOicsIHRoaXMuc2V0dGluZ3MpO1xuXG4gICAgICBpZiAodGhpcy5zZXR0aW5ncy5lbmFibGVRbWRMaW5raW5nKSB7XG4gICAgICAgIHRoaXMucmVnaXN0ZXJRbWRFeHRlbnNpb24oKTtcbiAgICAgIH1cblxuICAgICAgdGhpcy5hZGRTZXR0aW5nVGFiKG5ldyBRbWRTZXR0aW5nVGFiKHRoaXMuYXBwLCB0aGlzKSk7XG4gICAgICBjb25zb2xlLmxvZygnU2V0dGluZ3MgdGFiIGFkZGVkIHN1Y2Nlc3NmdWxseScpO1xuXG4gICAgICB0aGlzLmFkZFJpYmJvbkljb24oJ2V5ZScsICdUb2dnbGUgUXVhcnRvIFByZXZpZXcnLCBhc3luYyAoZXZ0KSA9PiB7XG4gICAgICAgIGNvbnN0IGFjdGl2ZVZpZXcgPSB0aGlzLmFwcC53b3Jrc3BhY2UuZ2V0QWN0aXZlVmlld09mVHlwZShNYXJrZG93blZpZXcpO1xuICAgICAgICBpZiAoYWN0aXZlVmlldz8uZmlsZSAmJiB0aGlzLmlzUXVhcnRvRmlsZShhY3RpdmVWaWV3LmZpbGUpKSB7XG4gICAgICAgICAgY29uc29sZS5sb2coYFRvZ2dsaW5nIHByZXZpZXcgZm9yOiAke2FjdGl2ZVZpZXcuZmlsZS5wYXRofWApO1xuICAgICAgICAgIGF3YWl0IHRoaXMudG9nZ2xlUHJldmlldyhhY3RpdmVWaWV3LmZpbGUpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIG5ldyBOb3RpY2UoJ0N1cnJlbnQgZmlsZSBpcyBub3QgYSBRdWFydG8gZG9jdW1lbnQnKTtcbiAgICAgICAgfVxuICAgICAgfSk7XG4gICAgICBjb25zb2xlLmxvZygnUmliYm9uIGljb24gYWRkZWQnKTtcblxuICAgICAgdGhpcy5hZGRDb21tYW5kKHtcbiAgICAgICAgaWQ6ICd0b2dnbGUtcXVhcnRvLXByZXZpZXcnLFxuICAgICAgICBuYW1lOiAnVG9nZ2xlIFF1YXJ0byBQcmV2aWV3JyxcbiAgICAgICAgY2FsbGJhY2s6IGFzeW5jICgpID0+IHtcbiAgICAgICAgICBjb25zdCBhY3RpdmVWaWV3ID0gdGhpcy5hcHAud29ya3NwYWNlLmdldEFjdGl2ZVZpZXdPZlR5cGUoTWFya2Rvd25WaWV3KTtcbiAgICAgICAgICBpZiAoYWN0aXZlVmlldz8uZmlsZSAmJiB0aGlzLmlzUXVhcnRvRmlsZShhY3RpdmVWaWV3LmZpbGUpKSB7XG4gICAgICAgICAgICBjb25zb2xlLmxvZyhgQ29tbWFuZDogVG9nZ2xpbmcgcHJldmlldyBmb3IgJHthY3RpdmVWaWV3LmZpbGUucGF0aH1gKTtcbiAgICAgICAgICAgIGF3YWl0IHRoaXMudG9nZ2xlUHJldmlldyhhY3RpdmVWaWV3LmZpbGUpO1xuICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBuZXcgTm90aWNlKCdDdXJyZW50IGZpbGUgaXMgbm90IGEgUXVhcnRvIGRvY3VtZW50Jyk7XG4gICAgICAgICAgfVxuICAgICAgICB9LFxuICAgICAgICBob3RrZXlzOiBbeyBtb2RpZmllcnM6IFsnQ3RybCcsICdTaGlmdCddLCBrZXk6ICdwJyB9XSxcbiAgICAgIH0pO1xuXG4gICAgICBjb25zb2xlLmxvZygnQ29tbWFuZHMgYWRkZWQnKTtcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgY29uc29sZS5lcnJvcignRXJyb3IgbG9hZGluZyBwbHVnaW46JywgZXJyb3IpO1xuICAgICAgbmV3IE5vdGljZShcbiAgICAgICAgJ0ZhaWxlZCB0byBsb2FkIFFtZEFzTWRQbHVnaW4uIENoZWNrIHRoZSBkZXZlbG9wZXIgY29uc29sZSBmb3IgZGV0YWlscy4nXG4gICAgICApO1xuICAgIH1cbiAgfVxuXG4gIG9udW5sb2FkKCkge1xuICAgIGNvbnNvbGUubG9nKCdQbHVnaW4gaXMgdW5sb2FkaW5nLi4uJyk7XG4gICAgdGhpcy5zdG9wQWxsUHJldmlld3MoKTtcbiAgfVxuXG4gIGFzeW5jIGxvYWRTZXR0aW5ncygpIHtcbiAgICB0aGlzLnNldHRpbmdzID0gT2JqZWN0LmFzc2lnbih7fSwgREVGQVVMVF9TRVRUSU5HUywgYXdhaXQgdGhpcy5sb2FkRGF0YSgpKTtcbiAgfVxuXG4gIGFzeW5jIHNhdmVTZXR0aW5ncygpIHtcbiAgICBhd2FpdCB0aGlzLnNhdmVEYXRhKHRoaXMuc2V0dGluZ3MpO1xuICB9XG5cbiAgaXNRdWFydG9GaWxlKGZpbGU6IFRGaWxlKTogYm9vbGVhbiB7XG4gICAgcmV0dXJuIGZpbGUuZXh0ZW5zaW9uID09PSAncW1kJztcbiAgfVxuXG4gIHJlZ2lzdGVyUW1kRXh0ZW5zaW9uKCkge1xuICAgIGNvbnNvbGUubG9nKCdSZWdpc3RlcmluZyAucW1kIGFzIG1hcmtkb3duLi4uJyk7XG4gICAgdGhpcy5yZWdpc3RlckV4dGVuc2lvbnMoWydxbWQnXSwgJ21hcmtkb3duJyk7XG4gICAgY29uc29sZS5sb2coJy5xbWQgcmVnaXN0ZXJlZCBhcyBtYXJrZG93bicpO1xuICB9XG5cbiAgYXN5bmMgdG9nZ2xlUHJldmlldyhmaWxlOiBURmlsZSkge1xuICAgIGlmICh0aGlzLmFjdGl2ZVByZXZpZXdQcm9jZXNzZXMuaGFzKGZpbGUucGF0aCkpIHtcbiAgICAgIGF3YWl0IHRoaXMuc3RvcFByZXZpZXcoZmlsZSk7XG4gICAgfSBlbHNlIHtcbiAgICAgIGF3YWl0IHRoaXMuc3RhcnRQcmV2aWV3KGZpbGUpO1xuICAgIH1cbiAgfVxuXG4gIGFzeW5jIHN0YXJ0UHJldmlldyhmaWxlOiBURmlsZSkge1xuICAgIGlmICh0aGlzLmFjdGl2ZVByZXZpZXdQcm9jZXNzZXMuaGFzKGZpbGUucGF0aCkpIHtcbiAgICAgIGNvbnNvbGUubG9nKGBQcmV2aWV3IGFscmVhZHkgcnVubmluZyBmb3I6ICR7ZmlsZS5wYXRofWApO1xuICAgICAgcmV0dXJuOyAvLyBQcmV2aWV3IGFscmVhZHkgcnVubmluZ1xuICAgIH1cblxuICAgIHRyeSB7XG4gICAgICBjb25zdCBhYnN0cmFjdEZpbGUgPSB0aGlzLmFwcC52YXVsdC5nZXRBYnN0cmFjdEZpbGVCeVBhdGgoZmlsZS5wYXRoKTtcbiAgICAgIGlmICghYWJzdHJhY3RGaWxlIHx8ICEoYWJzdHJhY3RGaWxlIGluc3RhbmNlb2YgVEZpbGUpKSB7XG4gICAgICAgIG5ldyBOb3RpY2UoYEZpbGUgJHtmaWxlLnBhdGh9IG5vdCBmb3VuZGApO1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG4gICAgICBjb25zdCBmaWxlUGF0aCA9ICh0aGlzLmFwcC52YXVsdC5hZGFwdGVyIGFzIGFueSkuZ2V0RnVsbFBhdGgoYWJzdHJhY3RGaWxlLnBhdGgpO1xuICAgICAgY29uc3Qgd29ya2luZ0RpciA9IHBhdGguZGlybmFtZShmaWxlUGF0aCk7XG5cbiAgICAgIGNvbnNvbGUubG9nKGBSZXNvbHZlZCBmaWxlIHBhdGg6ICR7ZmlsZVBhdGh9YCk7XG4gICAgICBjb25zb2xlLmxvZyhgV29ya2luZyBkaXJlY3Rvcnk6ICR7d29ya2luZ0Rpcn1gKTtcblxuICAgICAgY29uc3QgcHJvY2VzcyA9IHNwYXduKHRoaXMuc2V0dGluZ3MucXVhcnRvUGF0aCwgWydwcmV2aWV3JywgZmlsZVBhdGhdLCB7XG4gICAgICAgIGN3ZDogd29ya2luZ0RpcixcbiAgICAgIH0pO1xuXG4gICAgICBsZXQgcHJldmlld1VybDogc3RyaW5nIHwgbnVsbCA9IG51bGw7XG5cbiAgICAgIHByb2Nlc3Muc3Rkb3V0Py5vbignZGF0YScsIChkYXRhOiBCdWZmZXIpID0+IHtcbiAgICAgICAgY29uc3Qgb3V0cHV0ID0gZGF0YS50b1N0cmluZygpO1xuICAgICAgICBjb25zb2xlLmxvZyhgUXVhcnRvIFByZXZpZXcgT3V0cHV0OiAke291dHB1dH1gKTtcblxuICAgICAgICBpZiAob3V0cHV0LmluY2x1ZGVzKCdCcm93c2UgYXQnKSkge1xuICAgICAgICAgIGNvbnN0IG1hdGNoID0gb3V0cHV0Lm1hdGNoKC9Ccm93c2UgYXRcXHMrKGh0dHA6XFwvXFwvW15cXHNdKykvKTtcbiAgICAgICAgICBpZiAobWF0Y2ggJiYgbWF0Y2hbMV0pIHtcbiAgICAgICAgICAgIHByZXZpZXdVcmwgPSBtYXRjaFsxXTtcbiAgICAgICAgICAgIG5ldyBOb3RpY2UoYFByZXZpZXcgYXZhaWxhYmxlIGF0ICR7cHJldmlld1VybH1gKTtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgIH0pO1xuXG4gICAgICBwcm9jZXNzLnN0ZGVycj8ub24oJ2RhdGEnLCAoZGF0YTogQnVmZmVyKSA9PiB7XG4gICAgICAgIGNvbnNvbGUuZXJyb3IoYFF1YXJ0byBQcmV2aWV3IEVycm9yOiAke2RhdGF9YCk7XG4gICAgICAgIG5ldyBOb3RpY2UoYFF1YXJ0byBQcmV2aWV3IEVycm9yOiAke2RhdGF9YCk7XG4gICAgICB9KTtcblxuICAgICAgcHJvY2Vzcy5vbignY2xvc2UnLCAoY29kZTogbnVtYmVyIHwgbnVsbCkgPT4ge1xuICAgICAgICBpZiAoY29kZSAhPT0gbnVsbCAmJiBjb2RlICE9PSAwKSB7XG4gICAgICAgICAgbmV3IE5vdGljZShgUXVhcnRvIHByZXZpZXcgcHJvY2VzcyBleGl0ZWQgd2l0aCBjb2RlICR7Y29kZX1gKTtcbiAgICAgICAgfVxuICAgICAgICB0aGlzLmFjdGl2ZVByZXZpZXdQcm9jZXNzZXMuZGVsZXRlKGZpbGUucGF0aCk7XG4gICAgICB9KTtcblxuICAgICAgdGhpcy5hY3RpdmVQcmV2aWV3UHJvY2Vzc2VzLnNldChmaWxlLnBhdGgsIHByb2Nlc3MpO1xuICAgICAgbmV3IE5vdGljZSgnUXVhcnRvIHByZXZpZXcgc3RhcnRlZCcpO1xuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICBjb25zb2xlLmVycm9yKCdGYWlsZWQgdG8gc3RhcnQgUXVhcnRvIHByZXZpZXc6JywgZXJyb3IpO1xuICAgICAgbmV3IE5vdGljZSgnRmFpbGVkIHRvIHN0YXJ0IFF1YXJ0byBwcmV2aWV3Jyk7XG4gICAgfVxuICB9XG5cbiAgYXN5bmMgc3RvcFByZXZpZXcoZmlsZTogVEZpbGUpIHtcbiAgICBjb25zdCBwcm9jZXNzID0gdGhpcy5hY3RpdmVQcmV2aWV3UHJvY2Vzc2VzLmdldChmaWxlLnBhdGgpO1xuICAgIGlmIChwcm9jZXNzKSB7XG4gICAgICBpZiAoIXByb2Nlc3Mua2lsbGVkKSB7XG4gICAgICAgIHByb2Nlc3Mua2lsbCgpO1xuICAgICAgfVxuICAgICAgdGhpcy5hY3RpdmVQcmV2aWV3UHJvY2Vzc2VzLmRlbGV0ZShmaWxlLnBhdGgpO1xuICAgICAgbmV3IE5vdGljZSgnUXVhcnRvIHByZXZpZXcgc3RvcHBlZCcpO1xuICAgIH1cbiAgfVxuXG4gIHN0b3BBbGxQcmV2aWV3cygpIHtcbiAgICB0aGlzLmFjdGl2ZVByZXZpZXdQcm9jZXNzZXMuZm9yRWFjaCgocHJvY2VzcywgZmlsZVBhdGgpID0+IHtcbiAgICAgIGlmICghcHJvY2Vzcy5raWxsZWQpIHtcbiAgICAgICAgcHJvY2Vzcy5raWxsKCk7XG4gICAgICB9XG4gICAgICB0aGlzLmFjdGl2ZVByZXZpZXdQcm9jZXNzZXMuZGVsZXRlKGZpbGVQYXRoKTtcbiAgICB9KTtcbiAgICBpZiAodGhpcy5hY3RpdmVQcmV2aWV3UHJvY2Vzc2VzLnNpemUgPiAwKSB7XG4gICAgICBuZXcgTm90aWNlKCdBbGwgUXVhcnRvIHByZXZpZXdzIHN0b3BwZWQnKTtcbiAgICB9XG4gIH1cbn1cblxuY2xhc3MgUW1kU2V0dGluZ1RhYiBleHRlbmRzIFBsdWdpblNldHRpbmdUYWIge1xuICBwbHVnaW46IFFtZEFzTWRQbHVnaW47XG5cbiAgY29uc3RydWN0b3IoYXBwOiBBcHAsIHBsdWdpbjogUW1kQXNNZFBsdWdpbikge1xuICAgIHN1cGVyKGFwcCwgcGx1Z2luKTtcbiAgICB0aGlzLnBsdWdpbiA9IHBsdWdpbjtcbiAgfVxuXG4gIGRpc3BsYXkoKTogdm9pZCB7XG4gICAgY29uc3QgeyBjb250YWluZXJFbCB9ID0gdGhpcztcbiAgICBjb250YWluZXJFbC5lbXB0eSgpO1xuXG4gICAgY29uc29sZS5sb2coJ1JlbmRlcmluZyBzZXR0aW5ncyB0YWIuLi4nKTtcblxuICAgIGNvbnRhaW5lckVsLmNyZWF0ZUVsKCdoMicsIHsgdGV4dDogJ1F1YXJ0byBQcmV2aWV3IFNldHRpbmdzJyB9KTtcblxuICAgIG5ldyBTZXR0aW5nKGNvbnRhaW5lckVsKVxuICAgICAgLnNldE5hbWUoJ1F1YXJ0byBQYXRoJylcbiAgICAgIC5zZXREZXNjKCdQYXRoIHRvIFF1YXJ0byBleGVjdXRhYmxlIChlLmcuLCBxdWFydG8sIC91c3IvbG9jYWwvYmluL3F1YXJ0byknKVxuICAgICAgLmFkZFRleHQoKHRleHQpID0+XG4gICAgICAgIHRleHRcbiAgICAgICAgICAuc2V0UGxhY2Vob2xkZXIoJ3F1YXJ0bycpXG4gICAgICAgICAgLnNldFZhbHVlKHRoaXMucGx1Z2luLnNldHRpbmdzLnF1YXJ0b1BhdGgpXG4gICAgICAgICAgLm9uQ2hhbmdlKGFzeW5jICh2YWx1ZSkgPT4ge1xuICAgICAgICAgICAgY29uc29sZS5sb2coYFF1YXJ0byBwYXRoIGNoYW5nZWQgdG86ICR7dmFsdWV9YCk7XG4gICAgICAgICAgICB0aGlzLnBsdWdpbi5zZXR0aW5ncy5xdWFydG9QYXRoID0gdmFsdWU7XG4gICAgICAgICAgICBhd2FpdCB0aGlzLnBsdWdpbi5zYXZlU2V0dGluZ3MoKTtcbiAgICAgICAgICB9KVxuICAgICAgKTtcblxuICAgIG5ldyBTZXR0aW5nKGNvbnRhaW5lckVsKVxuICAgICAgLnNldE5hbWUoJ0F1dG8gUHJldmlldycpXG4gICAgICAuc2V0RGVzYygnQXV0b21hdGljYWxseSBzdGFydCBwcmV2aWV3IHdoZW4gb3BlbmluZyBRdWFydG8gZmlsZXMnKVxuICAgICAgLmFkZFRvZ2dsZSgodG9nZ2xlKSA9PlxuICAgICAgICB0b2dnbGVcbiAgICAgICAgICAuc2V0VmFsdWUodGhpcy5wbHVnaW4uc2V0dGluZ3MuYXV0b1ByZXZpZXcpXG4gICAgICAgICAgLm9uQ2hhbmdlKGFzeW5jICh2YWx1ZSkgPT4ge1xuICAgICAgICAgICAgY29uc29sZS5sb2coYEF1dG8tcHJldmlldyBzZXR0aW5nIGNoYW5nZWQgdG86ICR7dmFsdWV9YCk7XG4gICAgICAgICAgICB0aGlzLnBsdWdpbi5zZXR0aW5ncy5hdXRvUHJldmlldyA9IHZhbHVlO1xuICAgICAgICAgICAgYXdhaXQgdGhpcy5wbHVnaW4uc2F2ZVNldHRpbmdzKCk7XG4gICAgICAgICAgfSlcbiAgICAgICk7XG5cbiAgICBuZXcgU2V0dGluZyhjb250YWluZXJFbClcbiAgICAgIC5zZXROYW1lKCdFbmFibGUgTGlua2luZyB0byBRdWFydG8gRmlsZXMnKVxuICAgICAgLnNldERlc2MoXG4gICAgICAgICdBbGxvdyBsaW5raW5nIHRvIGAucW1kYCBmaWxlcyB3aXRob3V0IGVuYWJsaW5nIFwiRGV0ZWN0IEFsbCBGaWxlIEV4dGVuc2lvbnNcIidcbiAgICAgIClcbiAgICAgIC5hZGRUb2dnbGUoKHRvZ2dsZSkgPT5cbiAgICAgICAgdG9nZ2xlXG4gICAgICAgICAgLnNldFZhbHVlKHRoaXMucGx1Z2luLnNldHRpbmdzLmVuYWJsZVFtZExpbmtpbmcpXG4gICAgICAgICAgLm9uQ2hhbmdlKGFzeW5jICh2YWx1ZSkgPT4ge1xuICAgICAgICAgICAgY29uc29sZS5sb2coYEVuYWJsZSBRTUQgTGlua2luZyBzZXR0aW5nIGNoYW5nZWQgdG86ICR7dmFsdWV9YCk7XG4gICAgICAgICAgICB0aGlzLnBsdWdpbi5zZXR0aW5ncy5lbmFibGVRbWRMaW5raW5nID0gdmFsdWU7XG5cbiAgICAgICAgICAgIGlmICh2YWx1ZSkge1xuICAgICAgICAgICAgICB0aGlzLnBsdWdpbi5yZWdpc3RlclFtZEV4dGVuc2lvbigpO1xuICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgY29uc29sZS5sb2coXG4gICAgICAgICAgICAgICAgJy5xbWQgbGlua2luZyBkaXNhYmxlZC4gUmVzdGFydCBPYnNpZGlhbiBpZiByZXF1aXJlZC4nXG4gICAgICAgICAgICAgICk7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIGF3YWl0IHRoaXMucGx1Z2luLnNhdmVTZXR0aW5ncygpO1xuICAgICAgICAgIH0pXG4gICAgICApO1xuXG4gICAgY29uc29sZS5sb2coJ1NldHRpbmdzIHRhYiByZW5kZXJlZCBzdWNjZXNzZnVsbHknKTtcbiAgfVxufSJdLCJuYW1lcyI6WyJQbHVnaW4iLCJNYXJrZG93blZpZXciLCJOb3RpY2UiLCJURmlsZSIsInBhdGgiLCJzcGF3biIsIlBsdWdpblNldHRpbmdUYWIiLCJTZXR0aW5nIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBbUJBLE1BQU0sZ0JBQWdCLEdBQXNCO0FBQzFDLElBQUEsVUFBVSxFQUFFLFFBQVE7QUFDcEIsSUFBQSxXQUFXLEVBQUUsS0FBSztBQUNsQixJQUFBLGdCQUFnQixFQUFFLEtBQUs7Q0FDeEIsQ0FBQztBQUVtQixNQUFBLGFBQWMsU0FBUUEsZUFBTSxDQUFBO0FBQWpELElBQUEsV0FBQSxHQUFBOztBQUVFLFFBQUEsSUFBQSxDQUFBLHNCQUFzQixHQUE4QixJQUFJLEdBQUcsRUFBRSxDQUFDO0tBZ0svRDtBQTlKQyxJQUFBLE1BQU0sTUFBTSxHQUFBO0FBQ1YsUUFBQSxPQUFPLENBQUMsR0FBRyxDQUFDLHNCQUFzQixDQUFDLENBQUM7QUFDcEMsUUFBQSxJQUFJO0FBQ0YsWUFBQSxNQUFNLElBQUksQ0FBQyxZQUFZLEVBQUUsQ0FBQztZQUMxQixPQUFPLENBQUMsR0FBRyxDQUFDLGtCQUFrQixFQUFFLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQztBQUUvQyxZQUFBLElBQUksSUFBSSxDQUFDLFFBQVEsQ0FBQyxnQkFBZ0IsRUFBRTtnQkFDbEMsSUFBSSxDQUFDLG9CQUFvQixFQUFFLENBQUM7YUFDN0I7QUFFRCxZQUFBLElBQUksQ0FBQyxhQUFhLENBQUMsSUFBSSxhQUFhLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRSxJQUFJLENBQUMsQ0FBQyxDQUFDO0FBQ3RELFlBQUEsT0FBTyxDQUFDLEdBQUcsQ0FBQyxpQ0FBaUMsQ0FBQyxDQUFDO1lBRS9DLElBQUksQ0FBQyxhQUFhLENBQUMsS0FBSyxFQUFFLHVCQUF1QixFQUFFLE9BQU8sR0FBRyxLQUFJO0FBQy9ELGdCQUFBLE1BQU0sVUFBVSxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsU0FBUyxDQUFDLG1CQUFtQixDQUFDQyxxQkFBWSxDQUFDLENBQUM7QUFDeEUsZ0JBQUEsSUFBSSxVQUFVLEVBQUUsSUFBSSxJQUFJLElBQUksQ0FBQyxZQUFZLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxFQUFFO29CQUMxRCxPQUFPLENBQUMsR0FBRyxDQUFDLENBQXlCLHNCQUFBLEVBQUEsVUFBVSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUUsQ0FBQSxDQUFDLENBQUM7b0JBQzdELE1BQU0sSUFBSSxDQUFDLGFBQWEsQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLENBQUM7aUJBQzNDO3FCQUFNO0FBQ0wsb0JBQUEsSUFBSUMsZUFBTSxDQUFDLHVDQUF1QyxDQUFDLENBQUM7aUJBQ3JEO0FBQ0gsYUFBQyxDQUFDLENBQUM7QUFDSCxZQUFBLE9BQU8sQ0FBQyxHQUFHLENBQUMsbUJBQW1CLENBQUMsQ0FBQztZQUVqQyxJQUFJLENBQUMsVUFBVSxDQUFDO0FBQ2QsZ0JBQUEsRUFBRSxFQUFFLHVCQUF1QjtBQUMzQixnQkFBQSxJQUFJLEVBQUUsdUJBQXVCO2dCQUM3QixRQUFRLEVBQUUsWUFBVztBQUNuQixvQkFBQSxNQUFNLFVBQVUsR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLFNBQVMsQ0FBQyxtQkFBbUIsQ0FBQ0QscUJBQVksQ0FBQyxDQUFDO0FBQ3hFLG9CQUFBLElBQUksVUFBVSxFQUFFLElBQUksSUFBSSxJQUFJLENBQUMsWUFBWSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsRUFBRTt3QkFDMUQsT0FBTyxDQUFDLEdBQUcsQ0FBQyxDQUFpQyw4QkFBQSxFQUFBLFVBQVUsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFFLENBQUEsQ0FBQyxDQUFDO3dCQUNyRSxNQUFNLElBQUksQ0FBQyxhQUFhLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxDQUFDO3FCQUMzQzt5QkFBTTtBQUNMLHdCQUFBLElBQUlDLGVBQU0sQ0FBQyx1Q0FBdUMsQ0FBQyxDQUFDO3FCQUNyRDtpQkFDRjtBQUNELGdCQUFBLE9BQU8sRUFBRSxDQUFDLEVBQUUsU0FBUyxFQUFFLENBQUMsTUFBTSxFQUFFLE9BQU8sQ0FBQyxFQUFFLEdBQUcsRUFBRSxHQUFHLEVBQUUsQ0FBQztBQUN0RCxhQUFBLENBQUMsQ0FBQztBQUVILFlBQUEsT0FBTyxDQUFDLEdBQUcsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDO1NBQy9CO1FBQUMsT0FBTyxLQUFLLEVBQUU7QUFDZCxZQUFBLE9BQU8sQ0FBQyxLQUFLLENBQUMsdUJBQXVCLEVBQUUsS0FBSyxDQUFDLENBQUM7QUFDOUMsWUFBQSxJQUFJQSxlQUFNLENBQ1Isd0VBQXdFLENBQ3pFLENBQUM7U0FDSDtLQUNGO0lBRUQsUUFBUSxHQUFBO0FBQ04sUUFBQSxPQUFPLENBQUMsR0FBRyxDQUFDLHdCQUF3QixDQUFDLENBQUM7UUFDdEMsSUFBSSxDQUFDLGVBQWUsRUFBRSxDQUFDO0tBQ3hCO0FBRUQsSUFBQSxNQUFNLFlBQVksR0FBQTtBQUNoQixRQUFBLElBQUksQ0FBQyxRQUFRLEdBQUcsTUFBTSxDQUFDLE1BQU0sQ0FBQyxFQUFFLEVBQUUsZ0JBQWdCLEVBQUUsTUFBTSxJQUFJLENBQUMsUUFBUSxFQUFFLENBQUMsQ0FBQztLQUM1RTtBQUVELElBQUEsTUFBTSxZQUFZLEdBQUE7UUFDaEIsTUFBTSxJQUFJLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQztLQUNwQztBQUVELElBQUEsWUFBWSxDQUFDLElBQVcsRUFBQTtBQUN0QixRQUFBLE9BQU8sSUFBSSxDQUFDLFNBQVMsS0FBSyxLQUFLLENBQUM7S0FDakM7SUFFRCxvQkFBb0IsR0FBQTtBQUNsQixRQUFBLE9BQU8sQ0FBQyxHQUFHLENBQUMsaUNBQWlDLENBQUMsQ0FBQztRQUMvQyxJQUFJLENBQUMsa0JBQWtCLENBQUMsQ0FBQyxLQUFLLENBQUMsRUFBRSxVQUFVLENBQUMsQ0FBQztBQUM3QyxRQUFBLE9BQU8sQ0FBQyxHQUFHLENBQUMsNkJBQTZCLENBQUMsQ0FBQztLQUM1QztJQUVELE1BQU0sYUFBYSxDQUFDLElBQVcsRUFBQTtRQUM3QixJQUFJLElBQUksQ0FBQyxzQkFBc0IsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxFQUFFO0FBQzlDLFlBQUEsTUFBTSxJQUFJLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxDQUFDO1NBQzlCO2FBQU07QUFDTCxZQUFBLE1BQU0sSUFBSSxDQUFDLFlBQVksQ0FBQyxJQUFJLENBQUMsQ0FBQztTQUMvQjtLQUNGO0lBRUQsTUFBTSxZQUFZLENBQUMsSUFBVyxFQUFBO1FBQzVCLElBQUksSUFBSSxDQUFDLHNCQUFzQixDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEVBQUU7WUFDOUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxDQUFBLDZCQUFBLEVBQWdDLElBQUksQ0FBQyxJQUFJLENBQUUsQ0FBQSxDQUFDLENBQUM7QUFDekQsWUFBQSxPQUFPO1NBQ1I7QUFFRCxRQUFBLElBQUk7QUFDRixZQUFBLE1BQU0sWUFBWSxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLHFCQUFxQixDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztZQUNyRSxJQUFJLENBQUMsWUFBWSxJQUFJLEVBQUUsWUFBWSxZQUFZQyxjQUFLLENBQUMsRUFBRTtnQkFDckQsSUFBSUQsZUFBTSxDQUFDLENBQVEsS0FBQSxFQUFBLElBQUksQ0FBQyxJQUFJLENBQUEsVUFBQSxDQUFZLENBQUMsQ0FBQztnQkFDMUMsT0FBTzthQUNSO0FBQ0QsWUFBQSxNQUFNLFFBQVEsR0FBSSxJQUFJLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxPQUFlLENBQUMsV0FBVyxDQUFDLFlBQVksQ0FBQyxJQUFJLENBQUMsQ0FBQztZQUNoRixNQUFNLFVBQVUsR0FBR0UsZUFBSSxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsQ0FBQztBQUUxQyxZQUFBLE9BQU8sQ0FBQyxHQUFHLENBQUMsdUJBQXVCLFFBQVEsQ0FBQSxDQUFFLENBQUMsQ0FBQztBQUMvQyxZQUFBLE9BQU8sQ0FBQyxHQUFHLENBQUMsc0JBQXNCLFVBQVUsQ0FBQSxDQUFFLENBQUMsQ0FBQztBQUVoRCxZQUFBLE1BQU0sT0FBTyxHQUFHQyxtQkFBSyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsVUFBVSxFQUFFLENBQUMsU0FBUyxFQUFFLFFBQVEsQ0FBQyxFQUFFO0FBQ3JFLGdCQUFBLEdBQUcsRUFBRSxVQUFVO0FBQ2hCLGFBQUEsQ0FBQyxDQUFDO1lBRUgsSUFBSSxVQUFVLEdBQWtCLElBQUksQ0FBQztZQUVyQyxPQUFPLENBQUMsTUFBTSxFQUFFLEVBQUUsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxJQUFZLEtBQUk7QUFDMUMsZ0JBQUEsTUFBTSxNQUFNLEdBQUcsSUFBSSxDQUFDLFFBQVEsRUFBRSxDQUFDO0FBQy9CLGdCQUFBLE9BQU8sQ0FBQyxHQUFHLENBQUMsMEJBQTBCLE1BQU0sQ0FBQSxDQUFFLENBQUMsQ0FBQztBQUVoRCxnQkFBQSxJQUFJLE1BQU0sQ0FBQyxRQUFRLENBQUMsV0FBVyxDQUFDLEVBQUU7b0JBQ2hDLE1BQU0sS0FBSyxHQUFHLE1BQU0sQ0FBQyxLQUFLLENBQUMsK0JBQStCLENBQUMsQ0FBQztBQUM1RCxvQkFBQSxJQUFJLEtBQUssSUFBSSxLQUFLLENBQUMsQ0FBQyxDQUFDLEVBQUU7QUFDckIsd0JBQUEsVUFBVSxHQUFHLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN0Qix3QkFBQSxJQUFJSCxlQUFNLENBQUMsQ0FBQSxxQkFBQSxFQUF3QixVQUFVLENBQUEsQ0FBRSxDQUFDLENBQUM7cUJBQ2xEO2lCQUNGO0FBQ0gsYUFBQyxDQUFDLENBQUM7WUFFSCxPQUFPLENBQUMsTUFBTSxFQUFFLEVBQUUsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxJQUFZLEtBQUk7QUFDMUMsZ0JBQUEsT0FBTyxDQUFDLEtBQUssQ0FBQyx5QkFBeUIsSUFBSSxDQUFBLENBQUUsQ0FBQyxDQUFDO0FBQy9DLGdCQUFBLElBQUlBLGVBQU0sQ0FBQyxDQUFBLHNCQUFBLEVBQXlCLElBQUksQ0FBQSxDQUFFLENBQUMsQ0FBQztBQUM5QyxhQUFDLENBQUMsQ0FBQztZQUVILE9BQU8sQ0FBQyxFQUFFLENBQUMsT0FBTyxFQUFFLENBQUMsSUFBbUIsS0FBSTtnQkFDMUMsSUFBSSxJQUFJLEtBQUssSUFBSSxJQUFJLElBQUksS0FBSyxDQUFDLEVBQUU7QUFDL0Isb0JBQUEsSUFBSUEsZUFBTSxDQUFDLENBQUEsd0NBQUEsRUFBMkMsSUFBSSxDQUFBLENBQUUsQ0FBQyxDQUFDO2lCQUMvRDtnQkFDRCxJQUFJLENBQUMsc0JBQXNCLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUNoRCxhQUFDLENBQUMsQ0FBQztZQUVILElBQUksQ0FBQyxzQkFBc0IsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLElBQUksRUFBRSxPQUFPLENBQUMsQ0FBQztBQUNwRCxZQUFBLElBQUlBLGVBQU0sQ0FBQyx3QkFBd0IsQ0FBQyxDQUFDO1NBQ3RDO1FBQUMsT0FBTyxLQUFLLEVBQUU7QUFDZCxZQUFBLE9BQU8sQ0FBQyxLQUFLLENBQUMsaUNBQWlDLEVBQUUsS0FBSyxDQUFDLENBQUM7QUFDeEQsWUFBQSxJQUFJQSxlQUFNLENBQUMsZ0NBQWdDLENBQUMsQ0FBQztTQUM5QztLQUNGO0lBRUQsTUFBTSxXQUFXLENBQUMsSUFBVyxFQUFBO0FBQzNCLFFBQUEsTUFBTSxPQUFPLEdBQUcsSUFBSSxDQUFDLHNCQUFzQixDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7UUFDM0QsSUFBSSxPQUFPLEVBQUU7QUFDWCxZQUFBLElBQUksQ0FBQyxPQUFPLENBQUMsTUFBTSxFQUFFO2dCQUNuQixPQUFPLENBQUMsSUFBSSxFQUFFLENBQUM7YUFDaEI7WUFDRCxJQUFJLENBQUMsc0JBQXNCLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUM5QyxZQUFBLElBQUlBLGVBQU0sQ0FBQyx3QkFBd0IsQ0FBQyxDQUFDO1NBQ3RDO0tBQ0Y7SUFFRCxlQUFlLEdBQUE7UUFDYixJQUFJLENBQUMsc0JBQXNCLENBQUMsT0FBTyxDQUFDLENBQUMsT0FBTyxFQUFFLFFBQVEsS0FBSTtBQUN4RCxZQUFBLElBQUksQ0FBQyxPQUFPLENBQUMsTUFBTSxFQUFFO2dCQUNuQixPQUFPLENBQUMsSUFBSSxFQUFFLENBQUM7YUFDaEI7QUFDRCxZQUFBLElBQUksQ0FBQyxzQkFBc0IsQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLENBQUM7QUFDL0MsU0FBQyxDQUFDLENBQUM7UUFDSCxJQUFJLElBQUksQ0FBQyxzQkFBc0IsQ0FBQyxJQUFJLEdBQUcsQ0FBQyxFQUFFO0FBQ3hDLFlBQUEsSUFBSUEsZUFBTSxDQUFDLDZCQUE2QixDQUFDLENBQUM7U0FDM0M7S0FDRjtBQUNGLENBQUE7QUFFRCxNQUFNLGFBQWMsU0FBUUkseUJBQWdCLENBQUE7SUFHMUMsV0FBWSxDQUFBLEdBQVEsRUFBRSxNQUFxQixFQUFBO0FBQ3pDLFFBQUEsS0FBSyxDQUFDLEdBQUcsRUFBRSxNQUFNLENBQUMsQ0FBQztBQUNuQixRQUFBLElBQUksQ0FBQyxNQUFNLEdBQUcsTUFBTSxDQUFDO0tBQ3RCO0lBRUQsT0FBTyxHQUFBO0FBQ0wsUUFBQSxNQUFNLEVBQUUsV0FBVyxFQUFFLEdBQUcsSUFBSSxDQUFDO1FBQzdCLFdBQVcsQ0FBQyxLQUFLLEVBQUUsQ0FBQztBQUVwQixRQUFBLE9BQU8sQ0FBQyxHQUFHLENBQUMsMkJBQTJCLENBQUMsQ0FBQztRQUV6QyxXQUFXLENBQUMsUUFBUSxDQUFDLElBQUksRUFBRSxFQUFFLElBQUksRUFBRSx5QkFBeUIsRUFBRSxDQUFDLENBQUM7UUFFaEUsSUFBSUMsZ0JBQU8sQ0FBQyxXQUFXLENBQUM7YUFDckIsT0FBTyxDQUFDLGFBQWEsQ0FBQzthQUN0QixPQUFPLENBQUMsaUVBQWlFLENBQUM7QUFDMUUsYUFBQSxPQUFPLENBQUMsQ0FBQyxJQUFJLEtBQ1osSUFBSTthQUNELGNBQWMsQ0FBQyxRQUFRLENBQUM7YUFDeEIsUUFBUSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLFVBQVUsQ0FBQztBQUN6QyxhQUFBLFFBQVEsQ0FBQyxPQUFPLEtBQUssS0FBSTtBQUN4QixZQUFBLE9BQU8sQ0FBQyxHQUFHLENBQUMsMkJBQTJCLEtBQUssQ0FBQSxDQUFFLENBQUMsQ0FBQztZQUNoRCxJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxVQUFVLEdBQUcsS0FBSyxDQUFDO0FBQ3hDLFlBQUEsTUFBTSxJQUFJLENBQUMsTUFBTSxDQUFDLFlBQVksRUFBRSxDQUFDO1NBQ2xDLENBQUMsQ0FDTCxDQUFDO1FBRUosSUFBSUEsZ0JBQU8sQ0FBQyxXQUFXLENBQUM7YUFDckIsT0FBTyxDQUFDLGNBQWMsQ0FBQzthQUN2QixPQUFPLENBQUMsdURBQXVELENBQUM7QUFDaEUsYUFBQSxTQUFTLENBQUMsQ0FBQyxNQUFNLEtBQ2hCLE1BQU07YUFDSCxRQUFRLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsV0FBVyxDQUFDO0FBQzFDLGFBQUEsUUFBUSxDQUFDLE9BQU8sS0FBSyxLQUFJO0FBQ3hCLFlBQUEsT0FBTyxDQUFDLEdBQUcsQ0FBQyxvQ0FBb0MsS0FBSyxDQUFBLENBQUUsQ0FBQyxDQUFDO1lBQ3pELElBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLFdBQVcsR0FBRyxLQUFLLENBQUM7QUFDekMsWUFBQSxNQUFNLElBQUksQ0FBQyxNQUFNLENBQUMsWUFBWSxFQUFFLENBQUM7U0FDbEMsQ0FBQyxDQUNMLENBQUM7UUFFSixJQUFJQSxnQkFBTyxDQUFDLFdBQVcsQ0FBQzthQUNyQixPQUFPLENBQUMsZ0NBQWdDLENBQUM7YUFDekMsT0FBTyxDQUNOLDZFQUE2RSxDQUM5RTtBQUNBLGFBQUEsU0FBUyxDQUFDLENBQUMsTUFBTSxLQUNoQixNQUFNO2FBQ0gsUUFBUSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLGdCQUFnQixDQUFDO0FBQy9DLGFBQUEsUUFBUSxDQUFDLE9BQU8sS0FBSyxLQUFJO0FBQ3hCLFlBQUEsT0FBTyxDQUFDLEdBQUcsQ0FBQywwQ0FBMEMsS0FBSyxDQUFBLENBQUUsQ0FBQyxDQUFDO1lBQy9ELElBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLGdCQUFnQixHQUFHLEtBQUssQ0FBQztZQUU5QyxJQUFJLEtBQUssRUFBRTtBQUNULGdCQUFBLElBQUksQ0FBQyxNQUFNLENBQUMsb0JBQW9CLEVBQUUsQ0FBQzthQUNwQztpQkFBTTtBQUNMLGdCQUFBLE9BQU8sQ0FBQyxHQUFHLENBQ1Qsc0RBQXNELENBQ3ZELENBQUM7YUFDSDtBQUVELFlBQUEsTUFBTSxJQUFJLENBQUMsTUFBTSxDQUFDLFlBQVksRUFBRSxDQUFDO1NBQ2xDLENBQUMsQ0FDTCxDQUFDO0FBRUosUUFBQSxPQUFPLENBQUMsR0FBRyxDQUFDLG9DQUFvQyxDQUFDLENBQUM7S0FDbkQ7QUFDRjs7OzsifQ==
