'use strict';

var obsidian = require('obsidian');
var child_process = require('child_process');
var path = require('path');

function _interopNamespaceDefault(e) {
    var n = Object.create(null);
    if (e) {
        Object.keys(e).forEach(function (k) {
            if (k !== 'default') {
                var d = Object.getOwnPropertyDescriptor(e, k);
                Object.defineProperty(n, k, d.get ? d : {
                    enumerable: true,
                    get: function () { return e[k]; }
                });
            }
        });
    }
    n.default = e;
    return Object.freeze(n);
}

var path__namespace = /*#__PURE__*/_interopNamespaceDefault(path);

const DEFAULT_SETTINGS = {
    quartoPath: 'quarto',
    enableQmdLinking: true,
};
class QmdAsMdPlugin extends obsidian.Plugin {
    constructor() {
        super(...arguments);
        this.activePreviewProcesses = new Map();
    }
    async onload() {
        console.log('Plugin is loading...');
        try {
            await this.loadSettings();
            console.log('Settings loaded:', this.settings);
            if (this.settings.enableQmdLinking) {
                this.registerQmdExtension();
            }
            this.addSettingTab(new QmdSettingTab(this.app, this));
            console.log('Settings tab added successfully');
            this.addRibbonIcon('eye', 'Toggle Quarto Preview', async (evt) => {
                const activeView = this.app.workspace.getActiveViewOfType(obsidian.MarkdownView);
                if (activeView?.file && this.isQuartoFile(activeView.file)) {
                    console.log(`Toggling preview for: ${activeView.file.path}`);
                    await this.togglePreview(activeView.file);
                }
                else {
                    new obsidian.Notice('Current file is not a Quarto document');
                }
            });
            console.log('Ribbon icon added');
            this.addCommand({
                id: 'toggle-quarto-preview',
                name: 'Toggle Quarto Preview',
                callback: async () => {
                    const activeView = this.app.workspace.getActiveViewOfType(obsidian.MarkdownView);
                    if (activeView?.file && this.isQuartoFile(activeView.file)) {
                        console.log(`Command: Toggling preview for ${activeView.file.path}`);
                        await this.togglePreview(activeView.file);
                    }
                    else {
                        new obsidian.Notice('Current file is not a Quarto document');
                    }
                },
                hotkeys: [{ modifiers: ['Ctrl', 'Shift'], key: 'p' }],
            });
            console.log('Commands added');
        }
        catch (error) {
            console.error('Error loading plugin:', error);
            new obsidian.Notice('Failed to load QmdAsMdPlugin. Check the developer console for details.');
        }
    }
    onunload() {
        console.log('Plugin is unloading...');
        this.stopAllPreviews();
    }
    async loadSettings() {
        this.settings = Object.assign({}, DEFAULT_SETTINGS, await this.loadData());
    }
    async saveSettings() {
        await this.saveData(this.settings);
    }
    isQuartoFile(file) {
        return file.extension === 'qmd';
    }
    registerQmdExtension() {
        console.log('Registering .qmd as markdown...');
        this.registerExtensions(['qmd'], 'markdown');
        console.log('.qmd registered as markdown');
    }
    async togglePreview(file) {
        if (this.activePreviewProcesses.has(file.path)) {
            await this.stopPreview(file);
        }
        else {
            await this.startPreview(file);
        }
    }
    async startPreview(file) {
        if (this.activePreviewProcesses.has(file.path)) {
            console.log(`Preview already running for: ${file.path}`);
            return; // Preview already running
        }
        try {
            const abstractFile = this.app.vault.getAbstractFileByPath(file.path);
            if (!abstractFile || !(abstractFile instanceof obsidian.TFile)) {
                new obsidian.Notice(`File ${file.path} not found`);
                return;
            }
            const filePath = this.app.vault.adapter.getFullPath(abstractFile.path);
            const workingDir = path__namespace.dirname(filePath);
            console.log(`Resolved file path: ${filePath}`);
            console.log(`Working directory: ${workingDir}`);
            const process = child_process.spawn(this.settings.quartoPath, ['preview', filePath], {
                cwd: workingDir,
            });
            let previewUrl = null;
            process.stdout?.on('data', (data) => {
                const output = data.toString();
                console.log(`Quarto Preview Output: ${output}`);
                if (output.includes('Browse at')) {
                    const match = output.match(/Browse at\s+(http:\/\/[^\s]+)/);
                    if (match && match[1]) {
                        previewUrl = match[1];
                        new obsidian.Notice(`Preview available at ${previewUrl}`);
                        const leaf = this.app.workspace.getLeaf('tab');
                        leaf.setViewState({
                            type: 'webviewer',
                            active: true,
                            state: {
                                url: previewUrl,
                            },
                        });
                        this.app.workspace.revealLeaf(leaf);
                    }
                }
            });
            process.stderr?.on('data', (data) => {
                console.error(`Quarto Preview Error: ${data}`);
                new obsidian.Notice(`Quarto Preview Error: ${data}`);
            });
            process.on('close', (code) => {
                if (code !== null && code !== 0) {
                    new obsidian.Notice(`Quarto preview process exited with code ${code}`);
                }
                this.activePreviewProcesses.delete(file.path);
            });
            this.activePreviewProcesses.set(file.path, process);
            new obsidian.Notice('Quarto preview started');
        }
        catch (error) {
            console.error('Failed to start Quarto preview:', error);
            new obsidian.Notice('Failed to start Quarto preview');
        }
    }
    async stopPreview(file) {
        const process = this.activePreviewProcesses.get(file.path);
        if (process) {
            if (!process.killed) {
                process.kill();
            }
            this.activePreviewProcesses.delete(file.path);
            new obsidian.Notice('Quarto preview stopped');
        }
    }
    stopAllPreviews() {
        this.activePreviewProcesses.forEach((process, filePath) => {
            if (!process.killed) {
                process.kill();
            }
            this.activePreviewProcesses.delete(filePath);
        });
        if (this.activePreviewProcesses.size > 0) {
            new obsidian.Notice('All Quarto previews stopped');
        }
    }
}
class QmdSettingTab extends obsidian.PluginSettingTab {
    constructor(app, plugin) {
        super(app, plugin);
        this.plugin = plugin;
    }
    display() {
        const { containerEl } = this;
        containerEl.empty();
        console.log('Rendering settings tab...');
        containerEl.createEl('h2', { text: 'Quarto Preview Settings' });
        new obsidian.Setting(containerEl)
            .setName('Quarto Path')
            .setDesc('Path to Quarto executable (e.g., quarto, /usr/local/bin/quarto)')
            .addText((text) => text
            .setPlaceholder('quarto')
            .setValue(this.plugin.settings.quartoPath)
            .onChange(async (value) => {
            console.log(`Quarto path changed to: ${value}`);
            this.plugin.settings.quartoPath = value;
            await this.plugin.saveSettings();
        }));
        new obsidian.Setting(containerEl)
            .setName('Enable Linking to Quarto Files')
            .setDesc('Allow linking to `.qmd` files without enabling "Detect All File Extensions"')
            .addToggle((toggle) => toggle
            .setValue(this.plugin.settings.enableQmdLinking)
            .onChange(async (value) => {
            console.log(`Enable QMD Linking setting changed to: ${value}`);
            this.plugin.settings.enableQmdLinking = value;
            if (value) {
                this.plugin.registerQmdExtension();
            }
            else {
                console.log('.qmd linking disabled. Restart Obsidian if required.');
            }
            await this.plugin.saveSettings();
        }));
        console.log('Settings tab rendered successfully');
    }
}

module.exports = QmdAsMdPlugin;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibWFpbi5qcyIsInNvdXJjZXMiOlsic3JjL21haW4udHMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtcbiAgUGx1Z2luLFxuICBOb3RpY2UsXG4gIFRGaWxlLFxuICBNYXJrZG93blZpZXcsXG4gIFBsdWdpblNldHRpbmdUYWIsXG4gIEFwcCxcbiAgU2V0dGluZyxcbiAgVEFic3RyYWN0RmlsZSxcbn0gZnJvbSAnb2JzaWRpYW4nO1xuaW1wb3J0IHsgc3Bhd24sIENoaWxkUHJvY2VzcyB9IGZyb20gJ2NoaWxkX3Byb2Nlc3MnO1xuaW1wb3J0ICogYXMgcGF0aCBmcm9tICdwYXRoJztcblxuaW50ZXJmYWNlIFFtZFBsdWdpblNldHRpbmdzIHtcbiAgcXVhcnRvUGF0aDogc3RyaW5nO1xuICBlbmFibGVRbWRMaW5raW5nOiBib29sZWFuO1xufVxuXG5jb25zdCBERUZBVUxUX1NFVFRJTkdTOiBRbWRQbHVnaW5TZXR0aW5ncyA9IHtcbiAgcXVhcnRvUGF0aDogJ3F1YXJ0bycsXG4gIGVuYWJsZVFtZExpbmtpbmc6IHRydWUsXG59O1xuXG5leHBvcnQgZGVmYXVsdCBjbGFzcyBRbWRBc01kUGx1Z2luIGV4dGVuZHMgUGx1Z2luIHtcbiAgc2V0dGluZ3M6IFFtZFBsdWdpblNldHRpbmdzO1xuICBhY3RpdmVQcmV2aWV3UHJvY2Vzc2VzOiBNYXA8c3RyaW5nLCBDaGlsZFByb2Nlc3M+ID0gbmV3IE1hcCgpO1xuXG4gIGFzeW5jIG9ubG9hZCgpIHtcbiAgICBjb25zb2xlLmxvZygnUGx1Z2luIGlzIGxvYWRpbmcuLi4nKTtcbiAgICB0cnkge1xuICAgICAgYXdhaXQgdGhpcy5sb2FkU2V0dGluZ3MoKTtcbiAgICAgIGNvbnNvbGUubG9nKCdTZXR0aW5ncyBsb2FkZWQ6JywgdGhpcy5zZXR0aW5ncyk7XG5cbiAgICAgIGlmICh0aGlzLnNldHRpbmdzLmVuYWJsZVFtZExpbmtpbmcpIHtcbiAgICAgICAgdGhpcy5yZWdpc3RlclFtZEV4dGVuc2lvbigpO1xuICAgICAgfVxuXG4gICAgICB0aGlzLmFkZFNldHRpbmdUYWIobmV3IFFtZFNldHRpbmdUYWIodGhpcy5hcHAsIHRoaXMpKTtcbiAgICAgIGNvbnNvbGUubG9nKCdTZXR0aW5ncyB0YWIgYWRkZWQgc3VjY2Vzc2Z1bGx5Jyk7XG5cbiAgICAgIHRoaXMuYWRkUmliYm9uSWNvbignZXllJywgJ1RvZ2dsZSBRdWFydG8gUHJldmlldycsIGFzeW5jIChldnQpID0+IHtcbiAgICAgICAgY29uc3QgYWN0aXZlVmlldyA9IHRoaXMuYXBwLndvcmtzcGFjZS5nZXRBY3RpdmVWaWV3T2ZUeXBlKE1hcmtkb3duVmlldyk7XG4gICAgICAgIGlmIChhY3RpdmVWaWV3Py5maWxlICYmIHRoaXMuaXNRdWFydG9GaWxlKGFjdGl2ZVZpZXcuZmlsZSkpIHtcbiAgICAgICAgICBjb25zb2xlLmxvZyhgVG9nZ2xpbmcgcHJldmlldyBmb3I6ICR7YWN0aXZlVmlldy5maWxlLnBhdGh9YCk7XG4gICAgICAgICAgYXdhaXQgdGhpcy50b2dnbGVQcmV2aWV3KGFjdGl2ZVZpZXcuZmlsZSk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgbmV3IE5vdGljZSgnQ3VycmVudCBmaWxlIGlzIG5vdCBhIFF1YXJ0byBkb2N1bWVudCcpO1xuICAgICAgICB9XG4gICAgICB9KTtcbiAgICAgIGNvbnNvbGUubG9nKCdSaWJib24gaWNvbiBhZGRlZCcpO1xuXG4gICAgICB0aGlzLmFkZENvbW1hbmQoe1xuICAgICAgICBpZDogJ3RvZ2dsZS1xdWFydG8tcHJldmlldycsXG4gICAgICAgIG5hbWU6ICdUb2dnbGUgUXVhcnRvIFByZXZpZXcnLFxuICAgICAgICBjYWxsYmFjazogYXN5bmMgKCkgPT4ge1xuICAgICAgICAgIGNvbnN0IGFjdGl2ZVZpZXcgPSB0aGlzLmFwcC53b3Jrc3BhY2UuZ2V0QWN0aXZlVmlld09mVHlwZShNYXJrZG93blZpZXcpO1xuICAgICAgICAgIGlmIChhY3RpdmVWaWV3Py5maWxlICYmIHRoaXMuaXNRdWFydG9GaWxlKGFjdGl2ZVZpZXcuZmlsZSkpIHtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKGBDb21tYW5kOiBUb2dnbGluZyBwcmV2aWV3IGZvciAke2FjdGl2ZVZpZXcuZmlsZS5wYXRofWApO1xuICAgICAgICAgICAgYXdhaXQgdGhpcy50b2dnbGVQcmV2aWV3KGFjdGl2ZVZpZXcuZmlsZSk7XG4gICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIG5ldyBOb3RpY2UoJ0N1cnJlbnQgZmlsZSBpcyBub3QgYSBRdWFydG8gZG9jdW1lbnQnKTtcbiAgICAgICAgICB9XG4gICAgICAgIH0sXG4gICAgICAgIGhvdGtleXM6IFt7IG1vZGlmaWVyczogWydDdHJsJywgJ1NoaWZ0J10sIGtleTogJ3AnIH1dLFxuICAgICAgfSk7XG5cbiAgICAgIGNvbnNvbGUubG9nKCdDb21tYW5kcyBhZGRlZCcpO1xuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICBjb25zb2xlLmVycm9yKCdFcnJvciBsb2FkaW5nIHBsdWdpbjonLCBlcnJvcik7XG4gICAgICBuZXcgTm90aWNlKFxuICAgICAgICAnRmFpbGVkIHRvIGxvYWQgUW1kQXNNZFBsdWdpbi4gQ2hlY2sgdGhlIGRldmVsb3BlciBjb25zb2xlIGZvciBkZXRhaWxzLidcbiAgICAgICk7XG4gICAgfVxuICB9XG5cbiAgb251bmxvYWQoKSB7XG4gICAgY29uc29sZS5sb2coJ1BsdWdpbiBpcyB1bmxvYWRpbmcuLi4nKTtcbiAgICB0aGlzLnN0b3BBbGxQcmV2aWV3cygpO1xuICB9XG5cbiAgYXN5bmMgbG9hZFNldHRpbmdzKCkge1xuICAgIHRoaXMuc2V0dGluZ3MgPSBPYmplY3QuYXNzaWduKHt9LCBERUZBVUxUX1NFVFRJTkdTLCBhd2FpdCB0aGlzLmxvYWREYXRhKCkpO1xuICB9XG5cbiAgYXN5bmMgc2F2ZVNldHRpbmdzKCkge1xuICAgIGF3YWl0IHRoaXMuc2F2ZURhdGEodGhpcy5zZXR0aW5ncyk7XG4gIH1cblxuICBpc1F1YXJ0b0ZpbGUoZmlsZTogVEZpbGUpOiBib29sZWFuIHtcbiAgICByZXR1cm4gZmlsZS5leHRlbnNpb24gPT09ICdxbWQnO1xuICB9XG5cbiAgcmVnaXN0ZXJRbWRFeHRlbnNpb24oKSB7XG4gICAgY29uc29sZS5sb2coJ1JlZ2lzdGVyaW5nIC5xbWQgYXMgbWFya2Rvd24uLi4nKTtcbiAgICB0aGlzLnJlZ2lzdGVyRXh0ZW5zaW9ucyhbJ3FtZCddLCAnbWFya2Rvd24nKTtcbiAgICBjb25zb2xlLmxvZygnLnFtZCByZWdpc3RlcmVkIGFzIG1hcmtkb3duJyk7XG4gIH1cblxuICBhc3luYyB0b2dnbGVQcmV2aWV3KGZpbGU6IFRGaWxlKSB7XG4gICAgaWYgKHRoaXMuYWN0aXZlUHJldmlld1Byb2Nlc3Nlcy5oYXMoZmlsZS5wYXRoKSkge1xuICAgICAgYXdhaXQgdGhpcy5zdG9wUHJldmlldyhmaWxlKTtcbiAgICB9IGVsc2Uge1xuICAgICAgYXdhaXQgdGhpcy5zdGFydFByZXZpZXcoZmlsZSk7XG4gICAgfVxuICB9XG5cbiAgYXN5bmMgc3RhcnRQcmV2aWV3KGZpbGU6IFRGaWxlKSB7XG4gICAgaWYgKHRoaXMuYWN0aXZlUHJldmlld1Byb2Nlc3Nlcy5oYXMoZmlsZS5wYXRoKSkge1xuICAgICAgY29uc29sZS5sb2coYFByZXZpZXcgYWxyZWFkeSBydW5uaW5nIGZvcjogJHtmaWxlLnBhdGh9YCk7XG4gICAgICByZXR1cm47IC8vIFByZXZpZXcgYWxyZWFkeSBydW5uaW5nXG4gICAgfVxuXG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IGFic3RyYWN0RmlsZSA9IHRoaXMuYXBwLnZhdWx0LmdldEFic3RyYWN0RmlsZUJ5UGF0aChmaWxlLnBhdGgpO1xuICAgICAgaWYgKCFhYnN0cmFjdEZpbGUgfHwgIShhYnN0cmFjdEZpbGUgaW5zdGFuY2VvZiBURmlsZSkpIHtcbiAgICAgICAgbmV3IE5vdGljZShgRmlsZSAke2ZpbGUucGF0aH0gbm90IGZvdW5kYCk7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cbiAgICAgIGNvbnN0IGZpbGVQYXRoID0gKHRoaXMuYXBwLnZhdWx0LmFkYXB0ZXIgYXMgYW55KS5nZXRGdWxsUGF0aChhYnN0cmFjdEZpbGUucGF0aCk7XG4gICAgICBjb25zdCB3b3JraW5nRGlyID0gcGF0aC5kaXJuYW1lKGZpbGVQYXRoKTtcblxuICAgICAgY29uc29sZS5sb2coYFJlc29sdmVkIGZpbGUgcGF0aDogJHtmaWxlUGF0aH1gKTtcbiAgICAgIGNvbnNvbGUubG9nKGBXb3JraW5nIGRpcmVjdG9yeTogJHt3b3JraW5nRGlyfWApO1xuXG4gICAgICBjb25zdCBwcm9jZXNzID0gc3Bhd24odGhpcy5zZXR0aW5ncy5xdWFydG9QYXRoLCBbJ3ByZXZpZXcnLCBmaWxlUGF0aF0sIHtcbiAgICAgICAgY3dkOiB3b3JraW5nRGlyLFxuICAgICAgfSk7XG5cbiAgICAgIGxldCBwcmV2aWV3VXJsOiBzdHJpbmcgfCBudWxsID0gbnVsbDtcblxuICAgICAgcHJvY2Vzcy5zdGRvdXQ/Lm9uKCdkYXRhJywgKGRhdGE6IEJ1ZmZlcikgPT4ge1xuICAgICAgICBjb25zdCBvdXRwdXQgPSBkYXRhLnRvU3RyaW5nKCk7XG4gICAgICAgIGNvbnNvbGUubG9nKGBRdWFydG8gUHJldmlldyBPdXRwdXQ6ICR7b3V0cHV0fWApO1xuXG4gICAgICAgIGlmIChvdXRwdXQuaW5jbHVkZXMoJ0Jyb3dzZSBhdCcpKSB7XG4gICAgICAgICAgY29uc3QgbWF0Y2ggPSBvdXRwdXQubWF0Y2goL0Jyb3dzZSBhdFxccysoaHR0cDpcXC9cXC9bXlxcc10rKS8pO1xuICAgICAgICAgIGlmIChtYXRjaCAmJiBtYXRjaFsxXSkge1xuICAgICAgICAgICAgcHJldmlld1VybCA9IG1hdGNoWzFdO1xuICAgICAgICAgICAgbmV3IE5vdGljZShgUHJldmlldyBhdmFpbGFibGUgYXQgJHtwcmV2aWV3VXJsfWApO1xuXG4gICAgICAgICAgICBjb25zdCBsZWFmID0gdGhpcy5hcHAud29ya3NwYWNlLmdldExlYWYoJ3RhYicpO1xuICAgICAgICAgICAgbGVhZi5zZXRWaWV3U3RhdGUoe1xuICAgICAgICAgICAgICB0eXBlOiAnd2Vidmlld2VyJyxcbiAgICAgICAgICAgICAgYWN0aXZlOiB0cnVlLFxuICAgICAgICAgICAgICBzdGF0ZToge1xuICAgICAgICAgICAgICAgIHVybDogcHJldmlld1VybCxcbiAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgdGhpcy5hcHAud29ya3NwYWNlLnJldmVhbExlYWYobGVhZik7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICB9KTtcblxuICAgICAgcHJvY2Vzcy5zdGRlcnI/Lm9uKCdkYXRhJywgKGRhdGE6IEJ1ZmZlcikgPT4ge1xuICAgICAgICBjb25zb2xlLmVycm9yKGBRdWFydG8gUHJldmlldyBFcnJvcjogJHtkYXRhfWApO1xuICAgICAgICBuZXcgTm90aWNlKGBRdWFydG8gUHJldmlldyBFcnJvcjogJHtkYXRhfWApO1xuICAgICAgfSk7XG5cbiAgICAgIHByb2Nlc3Mub24oJ2Nsb3NlJywgKGNvZGU6IG51bWJlciB8IG51bGwpID0+IHtcbiAgICAgICAgaWYgKGNvZGUgIT09IG51bGwgJiYgY29kZSAhPT0gMCkge1xuICAgICAgICAgIG5ldyBOb3RpY2UoYFF1YXJ0byBwcmV2aWV3IHByb2Nlc3MgZXhpdGVkIHdpdGggY29kZSAke2NvZGV9YCk7XG4gICAgICAgIH1cbiAgICAgICAgdGhpcy5hY3RpdmVQcmV2aWV3UHJvY2Vzc2VzLmRlbGV0ZShmaWxlLnBhdGgpO1xuICAgICAgfSk7XG5cbiAgICAgIHRoaXMuYWN0aXZlUHJldmlld1Byb2Nlc3Nlcy5zZXQoZmlsZS5wYXRoLCBwcm9jZXNzKTtcbiAgICAgIG5ldyBOb3RpY2UoJ1F1YXJ0byBwcmV2aWV3IHN0YXJ0ZWQnKTtcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgY29uc29sZS5lcnJvcignRmFpbGVkIHRvIHN0YXJ0IFF1YXJ0byBwcmV2aWV3OicsIGVycm9yKTtcbiAgICAgIG5ldyBOb3RpY2UoJ0ZhaWxlZCB0byBzdGFydCBRdWFydG8gcHJldmlldycpO1xuICAgIH1cbiAgfVxuXG4gIGFzeW5jIHN0b3BQcmV2aWV3KGZpbGU6IFRGaWxlKSB7XG4gICAgY29uc3QgcHJvY2VzcyA9IHRoaXMuYWN0aXZlUHJldmlld1Byb2Nlc3Nlcy5nZXQoZmlsZS5wYXRoKTtcbiAgICBpZiAocHJvY2Vzcykge1xuICAgICAgaWYgKCFwcm9jZXNzLmtpbGxlZCkge1xuICAgICAgICBwcm9jZXNzLmtpbGwoKTtcbiAgICAgIH1cbiAgICAgIHRoaXMuYWN0aXZlUHJldmlld1Byb2Nlc3Nlcy5kZWxldGUoZmlsZS5wYXRoKTtcbiAgICAgIG5ldyBOb3RpY2UoJ1F1YXJ0byBwcmV2aWV3IHN0b3BwZWQnKTtcbiAgICB9XG4gIH1cblxuICBzdG9wQWxsUHJldmlld3MoKSB7XG4gICAgdGhpcy5hY3RpdmVQcmV2aWV3UHJvY2Vzc2VzLmZvckVhY2goKHByb2Nlc3MsIGZpbGVQYXRoKSA9PiB7XG4gICAgICBpZiAoIXByb2Nlc3Mua2lsbGVkKSB7XG4gICAgICAgIHByb2Nlc3Mua2lsbCgpO1xuICAgICAgfVxuICAgICAgdGhpcy5hY3RpdmVQcmV2aWV3UHJvY2Vzc2VzLmRlbGV0ZShmaWxlUGF0aCk7XG4gICAgfSk7XG4gICAgaWYgKHRoaXMuYWN0aXZlUHJldmlld1Byb2Nlc3Nlcy5zaXplID4gMCkge1xuICAgICAgbmV3IE5vdGljZSgnQWxsIFF1YXJ0byBwcmV2aWV3cyBzdG9wcGVkJyk7XG4gICAgfVxuICB9XG59XG5cbmNsYXNzIFFtZFNldHRpbmdUYWIgZXh0ZW5kcyBQbHVnaW5TZXR0aW5nVGFiIHtcbiAgcGx1Z2luOiBRbWRBc01kUGx1Z2luO1xuXG4gIGNvbnN0cnVjdG9yKGFwcDogQXBwLCBwbHVnaW46IFFtZEFzTWRQbHVnaW4pIHtcbiAgICBzdXBlcihhcHAsIHBsdWdpbik7XG4gICAgdGhpcy5wbHVnaW4gPSBwbHVnaW47XG4gIH1cblxuICBkaXNwbGF5KCk6IHZvaWQge1xuICAgIGNvbnN0IHsgY29udGFpbmVyRWwgfSA9IHRoaXM7XG4gICAgY29udGFpbmVyRWwuZW1wdHkoKTtcblxuICAgIGNvbnNvbGUubG9nKCdSZW5kZXJpbmcgc2V0dGluZ3MgdGFiLi4uJyk7XG5cbiAgICBjb250YWluZXJFbC5jcmVhdGVFbCgnaDInLCB7IHRleHQ6ICdRdWFydG8gUHJldmlldyBTZXR0aW5ncycgfSk7XG5cbiAgICBuZXcgU2V0dGluZyhjb250YWluZXJFbClcbiAgICAgIC5zZXROYW1lKCdRdWFydG8gUGF0aCcpXG4gICAgICAuc2V0RGVzYygnUGF0aCB0byBRdWFydG8gZXhlY3V0YWJsZSAoZS5nLiwgcXVhcnRvLCAvdXNyL2xvY2FsL2Jpbi9xdWFydG8pJylcbiAgICAgIC5hZGRUZXh0KCh0ZXh0KSA9PlxuICAgICAgICB0ZXh0XG4gICAgICAgICAgLnNldFBsYWNlaG9sZGVyKCdxdWFydG8nKVxuICAgICAgICAgIC5zZXRWYWx1ZSh0aGlzLnBsdWdpbi5zZXR0aW5ncy5xdWFydG9QYXRoKVxuICAgICAgICAgIC5vbkNoYW5nZShhc3luYyAodmFsdWUpID0+IHtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKGBRdWFydG8gcGF0aCBjaGFuZ2VkIHRvOiAke3ZhbHVlfWApO1xuICAgICAgICAgICAgdGhpcy5wbHVnaW4uc2V0dGluZ3MucXVhcnRvUGF0aCA9IHZhbHVlO1xuICAgICAgICAgICAgYXdhaXQgdGhpcy5wbHVnaW4uc2F2ZVNldHRpbmdzKCk7XG4gICAgICAgICAgfSlcbiAgICAgICk7XG5cbiAgICBuZXcgU2V0dGluZyhjb250YWluZXJFbClcbiAgICAgIC5zZXROYW1lKCdFbmFibGUgTGlua2luZyB0byBRdWFydG8gRmlsZXMnKVxuICAgICAgLnNldERlc2MoXG4gICAgICAgICdBbGxvdyBsaW5raW5nIHRvIGAucW1kYCBmaWxlcyB3aXRob3V0IGVuYWJsaW5nIFwiRGV0ZWN0IEFsbCBGaWxlIEV4dGVuc2lvbnNcIidcbiAgICAgIClcbiAgICAgIC5hZGRUb2dnbGUoKHRvZ2dsZSkgPT5cbiAgICAgICAgdG9nZ2xlXG4gICAgICAgICAgLnNldFZhbHVlKHRoaXMucGx1Z2luLnNldHRpbmdzLmVuYWJsZVFtZExpbmtpbmcpXG4gICAgICAgICAgLm9uQ2hhbmdlKGFzeW5jICh2YWx1ZSkgPT4ge1xuICAgICAgICAgICAgY29uc29sZS5sb2coYEVuYWJsZSBRTUQgTGlua2luZyBzZXR0aW5nIGNoYW5nZWQgdG86ICR7dmFsdWV9YCk7XG4gICAgICAgICAgICB0aGlzLnBsdWdpbi5zZXR0aW5ncy5lbmFibGVRbWRMaW5raW5nID0gdmFsdWU7XG5cbiAgICAgICAgICAgIGlmICh2YWx1ZSkge1xuICAgICAgICAgICAgICB0aGlzLnBsdWdpbi5yZWdpc3RlclFtZEV4dGVuc2lvbigpO1xuICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgY29uc29sZS5sb2coXG4gICAgICAgICAgICAgICAgJy5xbWQgbGlua2luZyBkaXNhYmxlZC4gUmVzdGFydCBPYnNpZGlhbiBpZiByZXF1aXJlZC4nXG4gICAgICAgICAgICAgICk7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIGF3YWl0IHRoaXMucGx1Z2luLnNhdmVTZXR0aW5ncygpO1xuICAgICAgICAgIH0pXG4gICAgICApO1xuXG4gICAgY29uc29sZS5sb2coJ1NldHRpbmdzIHRhYiByZW5kZXJlZCBzdWNjZXNzZnVsbHknKTtcbiAgfVxufSJdLCJuYW1lcyI6WyJQbHVnaW4iLCJNYXJrZG93blZpZXciLCJOb3RpY2UiLCJURmlsZSIsInBhdGgiLCJzcGF3biIsIlBsdWdpblNldHRpbmdUYWIiLCJTZXR0aW5nIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBa0JBLE1BQU0sZ0JBQWdCLEdBQXNCO0FBQzFDLElBQUEsVUFBVSxFQUFFLFFBQVE7QUFDcEIsSUFBQSxnQkFBZ0IsRUFBRSxJQUFJO0NBQ3ZCLENBQUM7QUFFbUIsTUFBQSxhQUFjLFNBQVFBLGVBQU0sQ0FBQTtBQUFqRCxJQUFBLFdBQUEsR0FBQTs7QUFFRSxRQUFBLElBQUEsQ0FBQSxzQkFBc0IsR0FBOEIsSUFBSSxHQUFHLEVBQUUsQ0FBQztLQTBLL0Q7QUF4S0MsSUFBQSxNQUFNLE1BQU0sR0FBQTtBQUNWLFFBQUEsT0FBTyxDQUFDLEdBQUcsQ0FBQyxzQkFBc0IsQ0FBQyxDQUFDO0FBQ3BDLFFBQUEsSUFBSTtBQUNGLFlBQUEsTUFBTSxJQUFJLENBQUMsWUFBWSxFQUFFLENBQUM7WUFDMUIsT0FBTyxDQUFDLEdBQUcsQ0FBQyxrQkFBa0IsRUFBRSxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUM7QUFFL0MsWUFBQSxJQUFJLElBQUksQ0FBQyxRQUFRLENBQUMsZ0JBQWdCLEVBQUU7Z0JBQ2xDLElBQUksQ0FBQyxvQkFBb0IsRUFBRSxDQUFDO2FBQzdCO0FBRUQsWUFBQSxJQUFJLENBQUMsYUFBYSxDQUFDLElBQUksYUFBYSxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUUsSUFBSSxDQUFDLENBQUMsQ0FBQztBQUN0RCxZQUFBLE9BQU8sQ0FBQyxHQUFHLENBQUMsaUNBQWlDLENBQUMsQ0FBQztZQUUvQyxJQUFJLENBQUMsYUFBYSxDQUFDLEtBQUssRUFBRSx1QkFBdUIsRUFBRSxPQUFPLEdBQUcsS0FBSTtBQUMvRCxnQkFBQSxNQUFNLFVBQVUsR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLFNBQVMsQ0FBQyxtQkFBbUIsQ0FBQ0MscUJBQVksQ0FBQyxDQUFDO0FBQ3hFLGdCQUFBLElBQUksVUFBVSxFQUFFLElBQUksSUFBSSxJQUFJLENBQUMsWUFBWSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsRUFBRTtvQkFDMUQsT0FBTyxDQUFDLEdBQUcsQ0FBQyxDQUF5QixzQkFBQSxFQUFBLFVBQVUsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFFLENBQUEsQ0FBQyxDQUFDO29CQUM3RCxNQUFNLElBQUksQ0FBQyxhQUFhLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxDQUFDO2lCQUMzQztxQkFBTTtBQUNMLG9CQUFBLElBQUlDLGVBQU0sQ0FBQyx1Q0FBdUMsQ0FBQyxDQUFDO2lCQUNyRDtBQUNILGFBQUMsQ0FBQyxDQUFDO0FBQ0gsWUFBQSxPQUFPLENBQUMsR0FBRyxDQUFDLG1CQUFtQixDQUFDLENBQUM7WUFFakMsSUFBSSxDQUFDLFVBQVUsQ0FBQztBQUNkLGdCQUFBLEVBQUUsRUFBRSx1QkFBdUI7QUFDM0IsZ0JBQUEsSUFBSSxFQUFFLHVCQUF1QjtnQkFDN0IsUUFBUSxFQUFFLFlBQVc7QUFDbkIsb0JBQUEsTUFBTSxVQUFVLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxTQUFTLENBQUMsbUJBQW1CLENBQUNELHFCQUFZLENBQUMsQ0FBQztBQUN4RSxvQkFBQSxJQUFJLFVBQVUsRUFBRSxJQUFJLElBQUksSUFBSSxDQUFDLFlBQVksQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLEVBQUU7d0JBQzFELE9BQU8sQ0FBQyxHQUFHLENBQUMsQ0FBaUMsOEJBQUEsRUFBQSxVQUFVLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBRSxDQUFBLENBQUMsQ0FBQzt3QkFDckUsTUFBTSxJQUFJLENBQUMsYUFBYSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsQ0FBQztxQkFDM0M7eUJBQU07QUFDTCx3QkFBQSxJQUFJQyxlQUFNLENBQUMsdUNBQXVDLENBQUMsQ0FBQztxQkFDckQ7aUJBQ0Y7QUFDRCxnQkFBQSxPQUFPLEVBQUUsQ0FBQyxFQUFFLFNBQVMsRUFBRSxDQUFDLE1BQU0sRUFBRSxPQUFPLENBQUMsRUFBRSxHQUFHLEVBQUUsR0FBRyxFQUFFLENBQUM7QUFDdEQsYUFBQSxDQUFDLENBQUM7QUFFSCxZQUFBLE9BQU8sQ0FBQyxHQUFHLENBQUMsZ0JBQWdCLENBQUMsQ0FBQztTQUMvQjtRQUFDLE9BQU8sS0FBSyxFQUFFO0FBQ2QsWUFBQSxPQUFPLENBQUMsS0FBSyxDQUFDLHVCQUF1QixFQUFFLEtBQUssQ0FBQyxDQUFDO0FBQzlDLFlBQUEsSUFBSUEsZUFBTSxDQUNSLHdFQUF3RSxDQUN6RSxDQUFDO1NBQ0g7S0FDRjtJQUVELFFBQVEsR0FBQTtBQUNOLFFBQUEsT0FBTyxDQUFDLEdBQUcsQ0FBQyx3QkFBd0IsQ0FBQyxDQUFDO1FBQ3RDLElBQUksQ0FBQyxlQUFlLEVBQUUsQ0FBQztLQUN4QjtBQUVELElBQUEsTUFBTSxZQUFZLEdBQUE7QUFDaEIsUUFBQSxJQUFJLENBQUMsUUFBUSxHQUFHLE1BQU0sQ0FBQyxNQUFNLENBQUMsRUFBRSxFQUFFLGdCQUFnQixFQUFFLE1BQU0sSUFBSSxDQUFDLFFBQVEsRUFBRSxDQUFDLENBQUM7S0FDNUU7QUFFRCxJQUFBLE1BQU0sWUFBWSxHQUFBO1FBQ2hCLE1BQU0sSUFBSSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUM7S0FDcEM7QUFFRCxJQUFBLFlBQVksQ0FBQyxJQUFXLEVBQUE7QUFDdEIsUUFBQSxPQUFPLElBQUksQ0FBQyxTQUFTLEtBQUssS0FBSyxDQUFDO0tBQ2pDO0lBRUQsb0JBQW9CLEdBQUE7QUFDbEIsUUFBQSxPQUFPLENBQUMsR0FBRyxDQUFDLGlDQUFpQyxDQUFDLENBQUM7UUFDL0MsSUFBSSxDQUFDLGtCQUFrQixDQUFDLENBQUMsS0FBSyxDQUFDLEVBQUUsVUFBVSxDQUFDLENBQUM7QUFDN0MsUUFBQSxPQUFPLENBQUMsR0FBRyxDQUFDLDZCQUE2QixDQUFDLENBQUM7S0FDNUM7SUFFRCxNQUFNLGFBQWEsQ0FBQyxJQUFXLEVBQUE7UUFDN0IsSUFBSSxJQUFJLENBQUMsc0JBQXNCLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsRUFBRTtBQUM5QyxZQUFBLE1BQU0sSUFBSSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsQ0FBQztTQUM5QjthQUFNO0FBQ0wsWUFBQSxNQUFNLElBQUksQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLENBQUM7U0FDL0I7S0FDRjtJQUVELE1BQU0sWUFBWSxDQUFDLElBQVcsRUFBQTtRQUM1QixJQUFJLElBQUksQ0FBQyxzQkFBc0IsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxFQUFFO1lBQzlDLE9BQU8sQ0FBQyxHQUFHLENBQUMsQ0FBQSw2QkFBQSxFQUFnQyxJQUFJLENBQUMsSUFBSSxDQUFFLENBQUEsQ0FBQyxDQUFDO0FBQ3pELFlBQUEsT0FBTztTQUNSO0FBRUQsUUFBQSxJQUFJO0FBQ0YsWUFBQSxNQUFNLFlBQVksR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxxQkFBcUIsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7WUFDckUsSUFBSSxDQUFDLFlBQVksSUFBSSxFQUFFLFlBQVksWUFBWUMsY0FBSyxDQUFDLEVBQUU7Z0JBQ3JELElBQUlELGVBQU0sQ0FBQyxDQUFRLEtBQUEsRUFBQSxJQUFJLENBQUMsSUFBSSxDQUFBLFVBQUEsQ0FBWSxDQUFDLENBQUM7Z0JBQzFDLE9BQU87YUFDUjtBQUNELFlBQUEsTUFBTSxRQUFRLEdBQUksSUFBSSxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsT0FBZSxDQUFDLFdBQVcsQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLENBQUM7WUFDaEYsTUFBTSxVQUFVLEdBQUdFLGVBQUksQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLENBQUM7QUFFMUMsWUFBQSxPQUFPLENBQUMsR0FBRyxDQUFDLHVCQUF1QixRQUFRLENBQUEsQ0FBRSxDQUFDLENBQUM7QUFDL0MsWUFBQSxPQUFPLENBQUMsR0FBRyxDQUFDLHNCQUFzQixVQUFVLENBQUEsQ0FBRSxDQUFDLENBQUM7QUFFaEQsWUFBQSxNQUFNLE9BQU8sR0FBR0MsbUJBQUssQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLFVBQVUsRUFBRSxDQUFDLFNBQVMsRUFBRSxRQUFRLENBQUMsRUFBRTtBQUNyRSxnQkFBQSxHQUFHLEVBQUUsVUFBVTtBQUNoQixhQUFBLENBQUMsQ0FBQztZQUVILElBQUksVUFBVSxHQUFrQixJQUFJLENBQUM7WUFFckMsT0FBTyxDQUFDLE1BQU0sRUFBRSxFQUFFLENBQUMsTUFBTSxFQUFFLENBQUMsSUFBWSxLQUFJO0FBQzFDLGdCQUFBLE1BQU0sTUFBTSxHQUFHLElBQUksQ0FBQyxRQUFRLEVBQUUsQ0FBQztBQUMvQixnQkFBQSxPQUFPLENBQUMsR0FBRyxDQUFDLDBCQUEwQixNQUFNLENBQUEsQ0FBRSxDQUFDLENBQUM7QUFFaEQsZ0JBQUEsSUFBSSxNQUFNLENBQUMsUUFBUSxDQUFDLFdBQVcsQ0FBQyxFQUFFO29CQUNoQyxNQUFNLEtBQUssR0FBRyxNQUFNLENBQUMsS0FBSyxDQUFDLCtCQUErQixDQUFDLENBQUM7QUFDNUQsb0JBQUEsSUFBSSxLQUFLLElBQUksS0FBSyxDQUFDLENBQUMsQ0FBQyxFQUFFO0FBQ3JCLHdCQUFBLFVBQVUsR0FBRyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDdEIsd0JBQUEsSUFBSUgsZUFBTSxDQUFDLENBQUEscUJBQUEsRUFBd0IsVUFBVSxDQUFBLENBQUUsQ0FBQyxDQUFDO0FBRWpELHdCQUFBLE1BQU0sSUFBSSxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsU0FBUyxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsQ0FBQzt3QkFDL0MsSUFBSSxDQUFDLFlBQVksQ0FBQztBQUNoQiw0QkFBQSxJQUFJLEVBQUUsV0FBVztBQUNqQiw0QkFBQSxNQUFNLEVBQUUsSUFBSTtBQUNaLDRCQUFBLEtBQUssRUFBRTtBQUNMLGdDQUFBLEdBQUcsRUFBRSxVQUFVO0FBQ2hCLDZCQUFBO0FBQ0YseUJBQUEsQ0FBQyxDQUFDO3dCQUNILElBQUksQ0FBQyxHQUFHLENBQUMsU0FBUyxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsQ0FBQztxQkFDckM7aUJBQ0Y7QUFDSCxhQUFDLENBQUMsQ0FBQztZQUVILE9BQU8sQ0FBQyxNQUFNLEVBQUUsRUFBRSxDQUFDLE1BQU0sRUFBRSxDQUFDLElBQVksS0FBSTtBQUMxQyxnQkFBQSxPQUFPLENBQUMsS0FBSyxDQUFDLHlCQUF5QixJQUFJLENBQUEsQ0FBRSxDQUFDLENBQUM7QUFDL0MsZ0JBQUEsSUFBSUEsZUFBTSxDQUFDLENBQUEsc0JBQUEsRUFBeUIsSUFBSSxDQUFBLENBQUUsQ0FBQyxDQUFDO0FBQzlDLGFBQUMsQ0FBQyxDQUFDO1lBRUgsT0FBTyxDQUFDLEVBQUUsQ0FBQyxPQUFPLEVBQUUsQ0FBQyxJQUFtQixLQUFJO2dCQUMxQyxJQUFJLElBQUksS0FBSyxJQUFJLElBQUksSUFBSSxLQUFLLENBQUMsRUFBRTtBQUMvQixvQkFBQSxJQUFJQSxlQUFNLENBQUMsQ0FBQSx3Q0FBQSxFQUEyQyxJQUFJLENBQUEsQ0FBRSxDQUFDLENBQUM7aUJBQy9EO2dCQUNELElBQUksQ0FBQyxzQkFBc0IsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO0FBQ2hELGFBQUMsQ0FBQyxDQUFDO1lBRUgsSUFBSSxDQUFDLHNCQUFzQixDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsSUFBSSxFQUFFLE9BQU8sQ0FBQyxDQUFDO0FBQ3BELFlBQUEsSUFBSUEsZUFBTSxDQUFDLHdCQUF3QixDQUFDLENBQUM7U0FDdEM7UUFBQyxPQUFPLEtBQUssRUFBRTtBQUNkLFlBQUEsT0FBTyxDQUFDLEtBQUssQ0FBQyxpQ0FBaUMsRUFBRSxLQUFLLENBQUMsQ0FBQztBQUN4RCxZQUFBLElBQUlBLGVBQU0sQ0FBQyxnQ0FBZ0MsQ0FBQyxDQUFDO1NBQzlDO0tBQ0Y7SUFFRCxNQUFNLFdBQVcsQ0FBQyxJQUFXLEVBQUE7QUFDM0IsUUFBQSxNQUFNLE9BQU8sR0FBRyxJQUFJLENBQUMsc0JBQXNCLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUMzRCxJQUFJLE9BQU8sRUFBRTtBQUNYLFlBQUEsSUFBSSxDQUFDLE9BQU8sQ0FBQyxNQUFNLEVBQUU7Z0JBQ25CLE9BQU8sQ0FBQyxJQUFJLEVBQUUsQ0FBQzthQUNoQjtZQUNELElBQUksQ0FBQyxzQkFBc0IsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO0FBQzlDLFlBQUEsSUFBSUEsZUFBTSxDQUFDLHdCQUF3QixDQUFDLENBQUM7U0FDdEM7S0FDRjtJQUVELGVBQWUsR0FBQTtRQUNiLElBQUksQ0FBQyxzQkFBc0IsQ0FBQyxPQUFPLENBQUMsQ0FBQyxPQUFPLEVBQUUsUUFBUSxLQUFJO0FBQ3hELFlBQUEsSUFBSSxDQUFDLE9BQU8sQ0FBQyxNQUFNLEVBQUU7Z0JBQ25CLE9BQU8sQ0FBQyxJQUFJLEVBQUUsQ0FBQzthQUNoQjtBQUNELFlBQUEsSUFBSSxDQUFDLHNCQUFzQixDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsQ0FBQztBQUMvQyxTQUFDLENBQUMsQ0FBQztRQUNILElBQUksSUFBSSxDQUFDLHNCQUFzQixDQUFDLElBQUksR0FBRyxDQUFDLEVBQUU7QUFDeEMsWUFBQSxJQUFJQSxlQUFNLENBQUMsNkJBQTZCLENBQUMsQ0FBQztTQUMzQztLQUNGO0FBQ0YsQ0FBQTtBQUVELE1BQU0sYUFBYyxTQUFRSSx5QkFBZ0IsQ0FBQTtJQUcxQyxXQUFZLENBQUEsR0FBUSxFQUFFLE1BQXFCLEVBQUE7QUFDekMsUUFBQSxLQUFLLENBQUMsR0FBRyxFQUFFLE1BQU0sQ0FBQyxDQUFDO0FBQ25CLFFBQUEsSUFBSSxDQUFDLE1BQU0sR0FBRyxNQUFNLENBQUM7S0FDdEI7SUFFRCxPQUFPLEdBQUE7QUFDTCxRQUFBLE1BQU0sRUFBRSxXQUFXLEVBQUUsR0FBRyxJQUFJLENBQUM7UUFDN0IsV0FBVyxDQUFDLEtBQUssRUFBRSxDQUFDO0FBRXBCLFFBQUEsT0FBTyxDQUFDLEdBQUcsQ0FBQywyQkFBMkIsQ0FBQyxDQUFDO1FBRXpDLFdBQVcsQ0FBQyxRQUFRLENBQUMsSUFBSSxFQUFFLEVBQUUsSUFBSSxFQUFFLHlCQUF5QixFQUFFLENBQUMsQ0FBQztRQUVoRSxJQUFJQyxnQkFBTyxDQUFDLFdBQVcsQ0FBQzthQUNyQixPQUFPLENBQUMsYUFBYSxDQUFDO2FBQ3RCLE9BQU8sQ0FBQyxpRUFBaUUsQ0FBQztBQUMxRSxhQUFBLE9BQU8sQ0FBQyxDQUFDLElBQUksS0FDWixJQUFJO2FBQ0QsY0FBYyxDQUFDLFFBQVEsQ0FBQzthQUN4QixRQUFRLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsVUFBVSxDQUFDO0FBQ3pDLGFBQUEsUUFBUSxDQUFDLE9BQU8sS0FBSyxLQUFJO0FBQ3hCLFlBQUEsT0FBTyxDQUFDLEdBQUcsQ0FBQywyQkFBMkIsS0FBSyxDQUFBLENBQUUsQ0FBQyxDQUFDO1lBQ2hELElBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLFVBQVUsR0FBRyxLQUFLLENBQUM7QUFDeEMsWUFBQSxNQUFNLElBQUksQ0FBQyxNQUFNLENBQUMsWUFBWSxFQUFFLENBQUM7U0FDbEMsQ0FBQyxDQUNMLENBQUM7UUFFSixJQUFJQSxnQkFBTyxDQUFDLFdBQVcsQ0FBQzthQUNyQixPQUFPLENBQUMsZ0NBQWdDLENBQUM7YUFDekMsT0FBTyxDQUNOLDZFQUE2RSxDQUM5RTtBQUNBLGFBQUEsU0FBUyxDQUFDLENBQUMsTUFBTSxLQUNoQixNQUFNO2FBQ0gsUUFBUSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLGdCQUFnQixDQUFDO0FBQy9DLGFBQUEsUUFBUSxDQUFDLE9BQU8sS0FBSyxLQUFJO0FBQ3hCLFlBQUEsT0FBTyxDQUFDLEdBQUcsQ0FBQywwQ0FBMEMsS0FBSyxDQUFBLENBQUUsQ0FBQyxDQUFDO1lBQy9ELElBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLGdCQUFnQixHQUFHLEtBQUssQ0FBQztZQUU5QyxJQUFJLEtBQUssRUFBRTtBQUNULGdCQUFBLElBQUksQ0FBQyxNQUFNLENBQUMsb0JBQW9CLEVBQUUsQ0FBQzthQUNwQztpQkFBTTtBQUNMLGdCQUFBLE9BQU8sQ0FBQyxHQUFHLENBQ1Qsc0RBQXNELENBQ3ZELENBQUM7YUFDSDtBQUVELFlBQUEsTUFBTSxJQUFJLENBQUMsTUFBTSxDQUFDLFlBQVksRUFBRSxDQUFDO1NBQ2xDLENBQUMsQ0FDTCxDQUFDO0FBRUosUUFBQSxPQUFPLENBQUMsR0FBRyxDQUFDLG9DQUFvQyxDQUFDLENBQUM7S0FDbkQ7QUFDRjs7OzsifQ==
