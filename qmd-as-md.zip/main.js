'use strict';

var obsidian = require('obsidian');
var child_process = require('child_process');
var path = require('path');

function _interopNamespaceDefault(e) {
    var n = Object.create(null);
    if (e) {
        Object.keys(e).forEach(function (k) {
            if (k !== 'default') {
                var d = Object.getOwnPropertyDescriptor(e, k);
                Object.defineProperty(n, k, d.get ? d : {
                    enumerable: true,
                    get: function () { return e[k]; }
                });
            }
        });
    }
    n.default = e;
    return Object.freeze(n);
}

var path__namespace = /*#__PURE__*/_interopNamespaceDefault(path);

const DEFAULT_SETTINGS = {
    quartoPath: 'quarto',
    enableQmdLinking: true,
    quartoTypst: '', // Default is empty
};
class QmdAsMdPlugin extends obsidian.Plugin {
    constructor() {
        super(...arguments);
        this.activePreviewProcesses = new Map();
    }
    async onload() {
        console.log('Plugin is loading...');
        try {
            await this.loadSettings();
            console.log('Settings loaded:', this.settings);
            if (this.settings.enableQmdLinking) {
                this.registerQmdExtension();
            }
            this.addSettingTab(new QmdSettingTab(this.app, this));
            console.log('Settings tab added successfully');
            this.addRibbonIcon('eye', 'Toggle Quarto Preview', async () => {
                const activeView = this.app.workspace.getActiveViewOfType(obsidian.MarkdownView);
                if (activeView?.file && this.isQuartoFile(activeView.file)) {
                    console.log(`Toggling preview for: ${activeView.file.path}`);
                    await this.togglePreview(activeView.file);
                }
                else {
                    new obsidian.Notice('Current file is not a Quarto document');
                }
            });
            console.log('Ribbon icon added');
            this.addCommand({
                id: 'toggle-quarto-preview',
                name: 'Toggle Quarto Preview',
                callback: async () => {
                    const activeView = this.app.workspace.getActiveViewOfType(obsidian.MarkdownView);
                    if (activeView?.file && this.isQuartoFile(activeView.file)) {
                        console.log(`Command: Toggling preview for ${activeView.file.path}`);
                        await this.togglePreview(activeView.file);
                    }
                    else {
                        new obsidian.Notice('Current file is not a Quarto document');
                    }
                },
                hotkeys: [{ modifiers: ['Ctrl', 'Shift'], key: 'p' }],
            });
            console.log('Commands added');
        }
        catch (error) {
            console.error('Error loading plugin:', error);
            new obsidian.Notice('Failed to load QmdAsMdPlugin. Check the developer console for details.');
        }
    }
    onunload() {
        console.log('Plugin is unloading...');
        this.stopAllPreviews();
    }
    async loadSettings() {
        this.settings = Object.assign({}, DEFAULT_SETTINGS, await this.loadData());
    }
    async saveSettings() {
        await this.saveData(this.settings);
    }
    isQuartoFile(file) {
        return file.extension === 'qmd';
    }
    registerQmdExtension() {
        console.log('Registering .qmd as markdown...');
        this.registerExtensions(['qmd'], 'markdown');
        console.log('.qmd registered as markdown');
    }
    async togglePreview(file) {
        if (this.activePreviewProcesses.has(file.path)) {
            await this.stopPreview(file);
        }
        else {
            await this.startPreview(file);
        }
    }
    async startPreview(file) {
        if (this.activePreviewProcesses.has(file.path)) {
            console.log(`Preview already running for: ${file.path}`);
            return; // Preview already running
        }
        try {
            const abstractFile = this.app.vault.getAbstractFileByPath(file.path);
            if (!abstractFile || !(abstractFile instanceof obsidian.TFile)) {
                new obsidian.Notice(`File ${file.path} not found`);
                return;
            }
            const filePath = this.app.vault.adapter.getFullPath(abstractFile.path);
            const workingDir = path__namespace.dirname(filePath);
            console.log(`Resolved file path: ${filePath}`);
            console.log(`Working directory: ${workingDir}`);
            const envVars = {
                ...process.env, // inherit the existing environment
            };
            if (this.settings.quartoTypst.trim()) {
                envVars.QUARTO_TYPST = this.settings.quartoTypst.trim();
                console.log(`QUARTO_TYPST set to: ${envVars.QUARTO_TYPST}`);
            }
            else {
                console.log('QUARTO_TYPST not set (empty).');
            }
            const quartoProcess = child_process.spawn(this.settings.quartoPath, ['preview', filePath], {
                cwd: workingDir,
                env: envVars,
            });
            let previewUrl = null;
            quartoProcess.stdout?.on('data', (data) => {
                const output = data.toString();
                console.log(`Quarto Preview Output: ${output}`);
                if (output.includes('Browse at')) {
                    const match = output.match(/Browse at\s+(http:\/\/[^\s]+)/);
                    if (match && match[1]) {
                        previewUrl = match[1];
                        new obsidian.Notice(`Preview available at ${previewUrl}`);
                        const leaf = this.app.workspace.getLeaf('tab');
                        leaf.setViewState({
                            type: 'webviewer',
                            active: true,
                            state: {
                                url: previewUrl,
                            },
                        });
                        this.app.workspace.revealLeaf(leaf);
                    }
                }
            });
            quartoProcess.stderr?.on('data', (data) => {
                console.error(`Quarto Preview Error: ${data}`);
                new obsidian.Notice(`Quarto Preview Error: ${data}`);
            });
            quartoProcess.on('close', (code) => {
                if (code !== null && code !== 0) {
                    new obsidian.Notice(`Quarto preview process exited with code ${code}`);
                }
                this.activePreviewProcesses.delete(file.path);
            });
            this.activePreviewProcesses.set(file.path, quartoProcess);
            new obsidian.Notice('Quarto preview started');
        }
        catch (error) {
            console.error('Failed to start Quarto preview:', error);
            new obsidian.Notice('Failed to start Quarto preview');
        }
    }
    async stopPreview(file) {
        const quartoProcess = this.activePreviewProcesses.get(file.path);
        if (quartoProcess) {
            if (!quartoProcess.killed) {
                quartoProcess.kill();
            }
            this.activePreviewProcesses.delete(file.path);
            new obsidian.Notice('Quarto preview stopped');
        }
    }
    stopAllPreviews() {
        this.activePreviewProcesses.forEach((quartoProcess, filePath) => {
            if (!quartoProcess.killed) {
                quartoProcess.kill();
            }
            this.activePreviewProcesses.delete(filePath);
        });
        if (this.activePreviewProcesses.size > 0) {
            new obsidian.Notice('All Quarto previews stopped');
        }
    }
}
class QmdSettingTab extends obsidian.PluginSettingTab {
    constructor(app, plugin) {
        super(app, plugin);
        this.plugin = plugin;
    }
    display() {
        const { containerEl } = this;
        containerEl.empty();
        console.log('Rendering settings tab...');
        containerEl.createEl('h2', { text: 'Quarto Preview Settings' });
        new obsidian.Setting(containerEl)
            .setName('Quarto Path')
            .setDesc('Path to Quarto executable (e.g., quarto, /usr/local/bin/quarto)')
            .addText((text) => text
            .setPlaceholder('quarto')
            .setValue(this.plugin.settings.quartoPath)
            .onChange(async (value) => {
            console.log(`Quarto path changed to: ${value}`);
            this.plugin.settings.quartoPath = value;
            await this.plugin.saveSettings();
        }));
        new obsidian.Setting(containerEl)
            .setName('Enable Linking to Quarto Files')
            .setDesc('Allow linking to `.qmd` files without enabling "Detect All File Extensions"')
            .addToggle((toggle) => toggle
            .setValue(this.plugin.settings.enableQmdLinking)
            .onChange(async (value) => {
            console.log(`Enable QMD Linking setting changed to: ${value}`);
            this.plugin.settings.enableQmdLinking = value;
            if (value) {
                this.plugin.registerQmdExtension();
            }
            else {
                console.log('.qmd linking disabled. Restart Obsidian if required.');
            }
            await this.plugin.saveSettings();
        }));
        new obsidian.Setting(containerEl)
            .setName('QUARTO_TYPST Variable')
            .setDesc('Define the QUARTO_TYPST environment variable (leave empty to unset)')
            .addText((text) => text
            .setPlaceholder('e.g., typst_path')
            .setValue(this.plugin.settings.quartoTypst)
            .onChange(async (value) => {
            console.log(`QUARTO_TYPST set to: ${value}`);
            this.plugin.settings.quartoTypst = value;
            await this.plugin.saveSettings();
        }));
        console.log('Settings tab rendered successfully');
    }
}

module.exports = QmdAsMdPlugin;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibWFpbi5qcyIsInNvdXJjZXMiOlsic3JjL21haW4udHMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtcbiAgUGx1Z2luLFxuICBOb3RpY2UsXG4gIFRGaWxlLFxuICBNYXJrZG93blZpZXcsXG4gIFBsdWdpblNldHRpbmdUYWIsXG4gIEFwcCxcbiAgU2V0dGluZyxcbn0gZnJvbSAnb2JzaWRpYW4nO1xuaW1wb3J0IHsgc3Bhd24sIENoaWxkUHJvY2VzcyB9IGZyb20gJ2NoaWxkX3Byb2Nlc3MnO1xuaW1wb3J0ICogYXMgcGF0aCBmcm9tICdwYXRoJztcblxuaW50ZXJmYWNlIFFtZFBsdWdpblNldHRpbmdzIHtcbiAgcXVhcnRvUGF0aDogc3RyaW5nO1xuICBlbmFibGVRbWRMaW5raW5nOiBib29sZWFuO1xuICBxdWFydG9UeXBzdDogc3RyaW5nOyAvLyBBZGQgUXVhcnRvIFR5cHN0IHZhcmlhYmxlXG59XG5cbmNvbnN0IERFRkFVTFRfU0VUVElOR1M6IFFtZFBsdWdpblNldHRpbmdzID0ge1xuICBxdWFydG9QYXRoOiAncXVhcnRvJyxcbiAgZW5hYmxlUW1kTGlua2luZzogdHJ1ZSxcbiAgcXVhcnRvVHlwc3Q6ICcnLCAvLyBEZWZhdWx0IGlzIGVtcHR5XG59O1xuXG5leHBvcnQgZGVmYXVsdCBjbGFzcyBRbWRBc01kUGx1Z2luIGV4dGVuZHMgUGx1Z2luIHtcbiAgc2V0dGluZ3M6IFFtZFBsdWdpblNldHRpbmdzO1xuICBhY3RpdmVQcmV2aWV3UHJvY2Vzc2VzOiBNYXA8c3RyaW5nLCBDaGlsZFByb2Nlc3M+ID0gbmV3IE1hcCgpO1xuXG4gIGFzeW5jIG9ubG9hZCgpIHtcbiAgICBjb25zb2xlLmxvZygnUGx1Z2luIGlzIGxvYWRpbmcuLi4nKTtcbiAgICB0cnkge1xuICAgICAgYXdhaXQgdGhpcy5sb2FkU2V0dGluZ3MoKTtcbiAgICAgIGNvbnNvbGUubG9nKCdTZXR0aW5ncyBsb2FkZWQ6JywgdGhpcy5zZXR0aW5ncyk7XG5cbiAgICAgIGlmICh0aGlzLnNldHRpbmdzLmVuYWJsZVFtZExpbmtpbmcpIHtcbiAgICAgICAgdGhpcy5yZWdpc3RlclFtZEV4dGVuc2lvbigpO1xuICAgICAgfVxuXG4gICAgICB0aGlzLmFkZFNldHRpbmdUYWIobmV3IFFtZFNldHRpbmdUYWIodGhpcy5hcHAsIHRoaXMpKTtcbiAgICAgIGNvbnNvbGUubG9nKCdTZXR0aW5ncyB0YWIgYWRkZWQgc3VjY2Vzc2Z1bGx5Jyk7XG5cbiAgICAgIHRoaXMuYWRkUmliYm9uSWNvbignZXllJywgJ1RvZ2dsZSBRdWFydG8gUHJldmlldycsIGFzeW5jICgpID0+IHtcbiAgICAgICAgY29uc3QgYWN0aXZlVmlldyA9IHRoaXMuYXBwLndvcmtzcGFjZS5nZXRBY3RpdmVWaWV3T2ZUeXBlKE1hcmtkb3duVmlldyk7XG4gICAgICAgIGlmIChhY3RpdmVWaWV3Py5maWxlICYmIHRoaXMuaXNRdWFydG9GaWxlKGFjdGl2ZVZpZXcuZmlsZSkpIHtcbiAgICAgICAgICBjb25zb2xlLmxvZyhgVG9nZ2xpbmcgcHJldmlldyBmb3I6ICR7YWN0aXZlVmlldy5maWxlLnBhdGh9YCk7XG4gICAgICAgICAgYXdhaXQgdGhpcy50b2dnbGVQcmV2aWV3KGFjdGl2ZVZpZXcuZmlsZSk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgbmV3IE5vdGljZSgnQ3VycmVudCBmaWxlIGlzIG5vdCBhIFF1YXJ0byBkb2N1bWVudCcpO1xuICAgICAgICB9XG4gICAgICB9KTtcbiAgICAgIGNvbnNvbGUubG9nKCdSaWJib24gaWNvbiBhZGRlZCcpO1xuXG4gICAgICB0aGlzLmFkZENvbW1hbmQoe1xuICAgICAgICBpZDogJ3RvZ2dsZS1xdWFydG8tcHJldmlldycsXG4gICAgICAgIG5hbWU6ICdUb2dnbGUgUXVhcnRvIFByZXZpZXcnLFxuICAgICAgICBjYWxsYmFjazogYXN5bmMgKCkgPT4ge1xuICAgICAgICAgIGNvbnN0IGFjdGl2ZVZpZXcgPSB0aGlzLmFwcC53b3Jrc3BhY2UuZ2V0QWN0aXZlVmlld09mVHlwZShNYXJrZG93blZpZXcpO1xuICAgICAgICAgIGlmIChhY3RpdmVWaWV3Py5maWxlICYmIHRoaXMuaXNRdWFydG9GaWxlKGFjdGl2ZVZpZXcuZmlsZSkpIHtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKGBDb21tYW5kOiBUb2dnbGluZyBwcmV2aWV3IGZvciAke2FjdGl2ZVZpZXcuZmlsZS5wYXRofWApO1xuICAgICAgICAgICAgYXdhaXQgdGhpcy50b2dnbGVQcmV2aWV3KGFjdGl2ZVZpZXcuZmlsZSk7XG4gICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIG5ldyBOb3RpY2UoJ0N1cnJlbnQgZmlsZSBpcyBub3QgYSBRdWFydG8gZG9jdW1lbnQnKTtcbiAgICAgICAgICB9XG4gICAgICAgIH0sXG4gICAgICAgIGhvdGtleXM6IFt7IG1vZGlmaWVyczogWydDdHJsJywgJ1NoaWZ0J10sIGtleTogJ3AnIH1dLFxuICAgICAgfSk7XG5cbiAgICAgIGNvbnNvbGUubG9nKCdDb21tYW5kcyBhZGRlZCcpO1xuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICBjb25zb2xlLmVycm9yKCdFcnJvciBsb2FkaW5nIHBsdWdpbjonLCBlcnJvcik7XG4gICAgICBuZXcgTm90aWNlKFxuICAgICAgICAnRmFpbGVkIHRvIGxvYWQgUW1kQXNNZFBsdWdpbi4gQ2hlY2sgdGhlIGRldmVsb3BlciBjb25zb2xlIGZvciBkZXRhaWxzLidcbiAgICAgICk7XG4gICAgfVxuICB9XG5cbiAgb251bmxvYWQoKSB7XG4gICAgY29uc29sZS5sb2coJ1BsdWdpbiBpcyB1bmxvYWRpbmcuLi4nKTtcbiAgICB0aGlzLnN0b3BBbGxQcmV2aWV3cygpO1xuICB9XG5cbiAgYXN5bmMgbG9hZFNldHRpbmdzKCkge1xuICAgIHRoaXMuc2V0dGluZ3MgPSBPYmplY3QuYXNzaWduKHt9LCBERUZBVUxUX1NFVFRJTkdTLCBhd2FpdCB0aGlzLmxvYWREYXRhKCkpO1xuICB9XG5cbiAgYXN5bmMgc2F2ZVNldHRpbmdzKCkge1xuICAgIGF3YWl0IHRoaXMuc2F2ZURhdGEodGhpcy5zZXR0aW5ncyk7XG4gIH1cblxuICBpc1F1YXJ0b0ZpbGUoZmlsZTogVEZpbGUpOiBib29sZWFuIHtcbiAgICByZXR1cm4gZmlsZS5leHRlbnNpb24gPT09ICdxbWQnO1xuICB9XG5cbiAgcmVnaXN0ZXJRbWRFeHRlbnNpb24oKSB7XG4gICAgY29uc29sZS5sb2coJ1JlZ2lzdGVyaW5nIC5xbWQgYXMgbWFya2Rvd24uLi4nKTtcbiAgICB0aGlzLnJlZ2lzdGVyRXh0ZW5zaW9ucyhbJ3FtZCddLCAnbWFya2Rvd24nKTtcbiAgICBjb25zb2xlLmxvZygnLnFtZCByZWdpc3RlcmVkIGFzIG1hcmtkb3duJyk7XG4gIH1cblxuICBhc3luYyB0b2dnbGVQcmV2aWV3KGZpbGU6IFRGaWxlKSB7XG4gICAgaWYgKHRoaXMuYWN0aXZlUHJldmlld1Byb2Nlc3Nlcy5oYXMoZmlsZS5wYXRoKSkge1xuICAgICAgYXdhaXQgdGhpcy5zdG9wUHJldmlldyhmaWxlKTtcbiAgICB9IGVsc2Uge1xuICAgICAgYXdhaXQgdGhpcy5zdGFydFByZXZpZXcoZmlsZSk7XG4gICAgfVxuICB9XG5cbiAgYXN5bmMgc3RhcnRQcmV2aWV3KGZpbGU6IFRGaWxlKSB7XG4gICAgaWYgKHRoaXMuYWN0aXZlUHJldmlld1Byb2Nlc3Nlcy5oYXMoZmlsZS5wYXRoKSkge1xuICAgICAgY29uc29sZS5sb2coYFByZXZpZXcgYWxyZWFkeSBydW5uaW5nIGZvcjogJHtmaWxlLnBhdGh9YCk7XG4gICAgICByZXR1cm47IC8vIFByZXZpZXcgYWxyZWFkeSBydW5uaW5nXG4gICAgfVxuXG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IGFic3RyYWN0RmlsZSA9IHRoaXMuYXBwLnZhdWx0LmdldEFic3RyYWN0RmlsZUJ5UGF0aChmaWxlLnBhdGgpO1xuICAgICAgaWYgKCFhYnN0cmFjdEZpbGUgfHwgIShhYnN0cmFjdEZpbGUgaW5zdGFuY2VvZiBURmlsZSkpIHtcbiAgICAgICAgbmV3IE5vdGljZShgRmlsZSAke2ZpbGUucGF0aH0gbm90IGZvdW5kYCk7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cbiAgICAgIGNvbnN0IGZpbGVQYXRoID0gKHRoaXMuYXBwLnZhdWx0LmFkYXB0ZXIgYXMgYW55KS5nZXRGdWxsUGF0aChhYnN0cmFjdEZpbGUucGF0aCk7XG4gICAgICBjb25zdCB3b3JraW5nRGlyID0gcGF0aC5kaXJuYW1lKGZpbGVQYXRoKTtcblxuICAgICAgY29uc29sZS5sb2coYFJlc29sdmVkIGZpbGUgcGF0aDogJHtmaWxlUGF0aH1gKTtcbiAgICAgIGNvbnNvbGUubG9nKGBXb3JraW5nIGRpcmVjdG9yeTogJHt3b3JraW5nRGlyfWApO1xuXG4gICAgICBjb25zdCBlbnZWYXJzOiBOb2RlSlMuUHJvY2Vzc0VudiA9IHtcbiAgICAgICAgLi4ucHJvY2Vzcy5lbnYsIC8vIGluaGVyaXQgdGhlIGV4aXN0aW5nIGVudmlyb25tZW50XG4gICAgICB9O1xuXG4gICAgICBpZiAodGhpcy5zZXR0aW5ncy5xdWFydG9UeXBzdC50cmltKCkpIHtcbiAgICAgICAgZW52VmFycy5RVUFSVE9fVFlQU1QgPSB0aGlzLnNldHRpbmdzLnF1YXJ0b1R5cHN0LnRyaW0oKTtcbiAgICAgICAgY29uc29sZS5sb2coYFFVQVJUT19UWVBTVCBzZXQgdG86ICR7ZW52VmFycy5RVUFSVE9fVFlQU1R9YCk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBjb25zb2xlLmxvZygnUVVBUlRPX1RZUFNUIG5vdCBzZXQgKGVtcHR5KS4nKTtcbiAgICAgIH1cblxuICAgICAgY29uc3QgcXVhcnRvUHJvY2VzcyA9IHNwYXduKHRoaXMuc2V0dGluZ3MucXVhcnRvUGF0aCwgWydwcmV2aWV3JywgZmlsZVBhdGhdLCB7XG4gICAgICAgIGN3ZDogd29ya2luZ0RpcixcbiAgICAgICAgZW52OiBlbnZWYXJzLFxuICAgICAgfSk7XG5cbiAgICAgIGxldCBwcmV2aWV3VXJsOiBzdHJpbmcgfCBudWxsID0gbnVsbDtcblxuICAgICAgcXVhcnRvUHJvY2Vzcy5zdGRvdXQ/Lm9uKCdkYXRhJywgKGRhdGE6IEJ1ZmZlcikgPT4ge1xuICAgICAgICBjb25zdCBvdXRwdXQgPSBkYXRhLnRvU3RyaW5nKCk7XG4gICAgICAgIGNvbnNvbGUubG9nKGBRdWFydG8gUHJldmlldyBPdXRwdXQ6ICR7b3V0cHV0fWApO1xuXG4gICAgICAgIGlmIChvdXRwdXQuaW5jbHVkZXMoJ0Jyb3dzZSBhdCcpKSB7XG4gICAgICAgICAgY29uc3QgbWF0Y2ggPSBvdXRwdXQubWF0Y2goL0Jyb3dzZSBhdFxccysoaHR0cDpcXC9cXC9bXlxcc10rKS8pO1xuICAgICAgICAgIGlmIChtYXRjaCAmJiBtYXRjaFsxXSkge1xuICAgICAgICAgICAgcHJldmlld1VybCA9IG1hdGNoWzFdO1xuICAgICAgICAgICAgbmV3IE5vdGljZShgUHJldmlldyBhdmFpbGFibGUgYXQgJHtwcmV2aWV3VXJsfWApO1xuXG4gICAgICAgICAgICBjb25zdCBsZWFmID0gdGhpcy5hcHAud29ya3NwYWNlLmdldExlYWYoJ3RhYicpO1xuICAgICAgICAgICAgbGVhZi5zZXRWaWV3U3RhdGUoe1xuICAgICAgICAgICAgICB0eXBlOiAnd2Vidmlld2VyJyxcbiAgICAgICAgICAgICAgYWN0aXZlOiB0cnVlLFxuICAgICAgICAgICAgICBzdGF0ZToge1xuICAgICAgICAgICAgICAgIHVybDogcHJldmlld1VybCxcbiAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgdGhpcy5hcHAud29ya3NwYWNlLnJldmVhbExlYWYobGVhZik7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICB9KTtcblxuICAgICAgcXVhcnRvUHJvY2Vzcy5zdGRlcnI/Lm9uKCdkYXRhJywgKGRhdGE6IEJ1ZmZlcikgPT4ge1xuICAgICAgICBjb25zb2xlLmVycm9yKGBRdWFydG8gUHJldmlldyBFcnJvcjogJHtkYXRhfWApO1xuICAgICAgICBuZXcgTm90aWNlKGBRdWFydG8gUHJldmlldyBFcnJvcjogJHtkYXRhfWApO1xuICAgICAgfSk7XG5cbiAgICAgIHF1YXJ0b1Byb2Nlc3Mub24oJ2Nsb3NlJywgKGNvZGU6IG51bWJlciB8IG51bGwpID0+IHtcbiAgICAgICAgaWYgKGNvZGUgIT09IG51bGwgJiYgY29kZSAhPT0gMCkge1xuICAgICAgICAgIG5ldyBOb3RpY2UoYFF1YXJ0byBwcmV2aWV3IHByb2Nlc3MgZXhpdGVkIHdpdGggY29kZSAke2NvZGV9YCk7XG4gICAgICAgIH1cbiAgICAgICAgdGhpcy5hY3RpdmVQcmV2aWV3UHJvY2Vzc2VzLmRlbGV0ZShmaWxlLnBhdGgpO1xuICAgICAgfSk7XG5cbiAgICAgIHRoaXMuYWN0aXZlUHJldmlld1Byb2Nlc3Nlcy5zZXQoZmlsZS5wYXRoLCBxdWFydG9Qcm9jZXNzKTtcbiAgICAgIG5ldyBOb3RpY2UoJ1F1YXJ0byBwcmV2aWV3IHN0YXJ0ZWQnKTtcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgY29uc29sZS5lcnJvcignRmFpbGVkIHRvIHN0YXJ0IFF1YXJ0byBwcmV2aWV3OicsIGVycm9yKTtcbiAgICAgIG5ldyBOb3RpY2UoJ0ZhaWxlZCB0byBzdGFydCBRdWFydG8gcHJldmlldycpO1xuICAgIH1cbiAgfVxuXG4gIGFzeW5jIHN0b3BQcmV2aWV3KGZpbGU6IFRGaWxlKSB7XG4gICAgY29uc3QgcXVhcnRvUHJvY2VzcyA9IHRoaXMuYWN0aXZlUHJldmlld1Byb2Nlc3Nlcy5nZXQoZmlsZS5wYXRoKTtcbiAgICBpZiAocXVhcnRvUHJvY2Vzcykge1xuICAgICAgaWYgKCFxdWFydG9Qcm9jZXNzLmtpbGxlZCkge1xuICAgICAgICBxdWFydG9Qcm9jZXNzLmtpbGwoKTtcbiAgICAgIH1cbiAgICAgIHRoaXMuYWN0aXZlUHJldmlld1Byb2Nlc3Nlcy5kZWxldGUoZmlsZS5wYXRoKTtcbiAgICAgIG5ldyBOb3RpY2UoJ1F1YXJ0byBwcmV2aWV3IHN0b3BwZWQnKTtcbiAgICB9XG4gIH1cblxuICBzdG9wQWxsUHJldmlld3MoKSB7XG4gICAgdGhpcy5hY3RpdmVQcmV2aWV3UHJvY2Vzc2VzLmZvckVhY2goKHF1YXJ0b1Byb2Nlc3MsIGZpbGVQYXRoKSA9PiB7XG4gICAgICBpZiAoIXF1YXJ0b1Byb2Nlc3Mua2lsbGVkKSB7XG4gICAgICAgIHF1YXJ0b1Byb2Nlc3Mua2lsbCgpO1xuICAgICAgfVxuICAgICAgdGhpcy5hY3RpdmVQcmV2aWV3UHJvY2Vzc2VzLmRlbGV0ZShmaWxlUGF0aCk7XG4gICAgfSk7XG4gICAgaWYgKHRoaXMuYWN0aXZlUHJldmlld1Byb2Nlc3Nlcy5zaXplID4gMCkge1xuICAgICAgbmV3IE5vdGljZSgnQWxsIFF1YXJ0byBwcmV2aWV3cyBzdG9wcGVkJyk7XG4gICAgfVxuICB9XG59XG5cbmNsYXNzIFFtZFNldHRpbmdUYWIgZXh0ZW5kcyBQbHVnaW5TZXR0aW5nVGFiIHtcbiAgcGx1Z2luOiBRbWRBc01kUGx1Z2luO1xuXG4gIGNvbnN0cnVjdG9yKGFwcDogQXBwLCBwbHVnaW46IFFtZEFzTWRQbHVnaW4pIHtcbiAgICBzdXBlcihhcHAsIHBsdWdpbik7XG4gICAgdGhpcy5wbHVnaW4gPSBwbHVnaW47XG4gIH1cblxuICBkaXNwbGF5KCk6IHZvaWQge1xuICAgIGNvbnN0IHsgY29udGFpbmVyRWwgfSA9IHRoaXM7XG4gICAgY29udGFpbmVyRWwuZW1wdHkoKTtcblxuICAgIGNvbnNvbGUubG9nKCdSZW5kZXJpbmcgc2V0dGluZ3MgdGFiLi4uJyk7XG5cbiAgICBjb250YWluZXJFbC5jcmVhdGVFbCgnaDInLCB7IHRleHQ6ICdRdWFydG8gUHJldmlldyBTZXR0aW5ncycgfSk7XG5cbiAgICBuZXcgU2V0dGluZyhjb250YWluZXJFbClcbiAgICAgIC5zZXROYW1lKCdRdWFydG8gUGF0aCcpXG4gICAgICAuc2V0RGVzYygnUGF0aCB0byBRdWFydG8gZXhlY3V0YWJsZSAoZS5nLiwgcXVhcnRvLCAvdXNyL2xvY2FsL2Jpbi9xdWFydG8pJylcbiAgICAgIC5hZGRUZXh0KCh0ZXh0KSA9PlxuICAgICAgICB0ZXh0XG4gICAgICAgICAgLnNldFBsYWNlaG9sZGVyKCdxdWFydG8nKVxuICAgICAgICAgIC5zZXRWYWx1ZSh0aGlzLnBsdWdpbi5zZXR0aW5ncy5xdWFydG9QYXRoKVxuICAgICAgICAgIC5vbkNoYW5nZShhc3luYyAodmFsdWUpID0+IHtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKGBRdWFydG8gcGF0aCBjaGFuZ2VkIHRvOiAke3ZhbHVlfWApO1xuICAgICAgICAgICAgdGhpcy5wbHVnaW4uc2V0dGluZ3MucXVhcnRvUGF0aCA9IHZhbHVlO1xuICAgICAgICAgICAgYXdhaXQgdGhpcy5wbHVnaW4uc2F2ZVNldHRpbmdzKCk7XG4gICAgICAgICAgfSlcbiAgICAgICk7XG5cbiAgICBuZXcgU2V0dGluZyhjb250YWluZXJFbClcbiAgICAgIC5zZXROYW1lKCdFbmFibGUgTGlua2luZyB0byBRdWFydG8gRmlsZXMnKVxuICAgICAgLnNldERlc2MoXG4gICAgICAgICdBbGxvdyBsaW5raW5nIHRvIGAucW1kYCBmaWxlcyB3aXRob3V0IGVuYWJsaW5nIFwiRGV0ZWN0IEFsbCBGaWxlIEV4dGVuc2lvbnNcIidcbiAgICAgIClcbiAgICAgIC5hZGRUb2dnbGUoKHRvZ2dsZSkgPT5cbiAgICAgICAgdG9nZ2xlXG4gICAgICAgICAgLnNldFZhbHVlKHRoaXMucGx1Z2luLnNldHRpbmdzLmVuYWJsZVFtZExpbmtpbmcpXG4gICAgICAgICAgLm9uQ2hhbmdlKGFzeW5jICh2YWx1ZSkgPT4ge1xuICAgICAgICAgICAgY29uc29sZS5sb2coYEVuYWJsZSBRTUQgTGlua2luZyBzZXR0aW5nIGNoYW5nZWQgdG86ICR7dmFsdWV9YCk7XG4gICAgICAgICAgICB0aGlzLnBsdWdpbi5zZXR0aW5ncy5lbmFibGVRbWRMaW5raW5nID0gdmFsdWU7XG5cbiAgICAgICAgICAgIGlmICh2YWx1ZSkge1xuICAgICAgICAgICAgICB0aGlzLnBsdWdpbi5yZWdpc3RlclFtZEV4dGVuc2lvbigpO1xuICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgY29uc29sZS5sb2coXG4gICAgICAgICAgICAgICAgJy5xbWQgbGlua2luZyBkaXNhYmxlZC4gUmVzdGFydCBPYnNpZGlhbiBpZiByZXF1aXJlZC4nXG4gICAgICAgICAgICAgICk7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIGF3YWl0IHRoaXMucGx1Z2luLnNhdmVTZXR0aW5ncygpO1xuICAgICAgICAgIH0pXG4gICAgICApO1xuXG4gICAgbmV3IFNldHRpbmcoY29udGFpbmVyRWwpXG4gICAgICAuc2V0TmFtZSgnUVVBUlRPX1RZUFNUIFZhcmlhYmxlJylcbiAgICAgIC5zZXREZXNjKCdEZWZpbmUgdGhlIFFVQVJUT19UWVBTVCBlbnZpcm9ubWVudCB2YXJpYWJsZSAobGVhdmUgZW1wdHkgdG8gdW5zZXQpJylcbiAgICAgIC5hZGRUZXh0KCh0ZXh0KSA9PlxuICAgICAgICB0ZXh0XG4gICAgICAgICAgLnNldFBsYWNlaG9sZGVyKCdlLmcuLCB0eXBzdF9wYXRoJylcbiAgICAgICAgICAuc2V0VmFsdWUodGhpcy5wbHVnaW4uc2V0dGluZ3MucXVhcnRvVHlwc3QpXG4gICAgICAgICAgLm9uQ2hhbmdlKGFzeW5jICh2YWx1ZSkgPT4ge1xuICAgICAgICAgICAgY29uc29sZS5sb2coYFFVQVJUT19UWVBTVCBzZXQgdG86ICR7dmFsdWV9YCk7XG4gICAgICAgICAgICB0aGlzLnBsdWdpbi5zZXR0aW5ncy5xdWFydG9UeXBzdCA9IHZhbHVlO1xuICAgICAgICAgICAgYXdhaXQgdGhpcy5wbHVnaW4uc2F2ZVNldHRpbmdzKCk7XG4gICAgICAgICAgfSlcbiAgICAgICk7XG5cbiAgICBjb25zb2xlLmxvZygnU2V0dGluZ3MgdGFiIHJlbmRlcmVkIHN1Y2Nlc3NmdWxseScpO1xuICB9XG59Il0sIm5hbWVzIjpbIlBsdWdpbiIsIk1hcmtkb3duVmlldyIsIk5vdGljZSIsIlRGaWxlIiwicGF0aCIsInNwYXduIiwiUGx1Z2luU2V0dGluZ1RhYiIsIlNldHRpbmciXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFrQkEsTUFBTSxnQkFBZ0IsR0FBc0I7QUFDMUMsSUFBQSxVQUFVLEVBQUUsUUFBUTtBQUNwQixJQUFBLGdCQUFnQixFQUFFLElBQUk7SUFDdEIsV0FBVyxFQUFFLEVBQUU7Q0FDaEIsQ0FBQztBQUVtQixNQUFBLGFBQWMsU0FBUUEsZUFBTSxDQUFBO0FBQWpELElBQUEsV0FBQSxHQUFBOztBQUVFLFFBQUEsSUFBQSxDQUFBLHNCQUFzQixHQUE4QixJQUFJLEdBQUcsRUFBRSxDQUFDO0tBc0wvRDtBQXBMQyxJQUFBLE1BQU0sTUFBTSxHQUFBO0FBQ1YsUUFBQSxPQUFPLENBQUMsR0FBRyxDQUFDLHNCQUFzQixDQUFDLENBQUM7QUFDcEMsUUFBQSxJQUFJO0FBQ0YsWUFBQSxNQUFNLElBQUksQ0FBQyxZQUFZLEVBQUUsQ0FBQztZQUMxQixPQUFPLENBQUMsR0FBRyxDQUFDLGtCQUFrQixFQUFFLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQztBQUUvQyxZQUFBLElBQUksSUFBSSxDQUFDLFFBQVEsQ0FBQyxnQkFBZ0IsRUFBRTtnQkFDbEMsSUFBSSxDQUFDLG9CQUFvQixFQUFFLENBQUM7YUFDN0I7QUFFRCxZQUFBLElBQUksQ0FBQyxhQUFhLENBQUMsSUFBSSxhQUFhLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRSxJQUFJLENBQUMsQ0FBQyxDQUFDO0FBQ3RELFlBQUEsT0FBTyxDQUFDLEdBQUcsQ0FBQyxpQ0FBaUMsQ0FBQyxDQUFDO1lBRS9DLElBQUksQ0FBQyxhQUFhLENBQUMsS0FBSyxFQUFFLHVCQUF1QixFQUFFLFlBQVc7QUFDNUQsZ0JBQUEsTUFBTSxVQUFVLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxTQUFTLENBQUMsbUJBQW1CLENBQUNDLHFCQUFZLENBQUMsQ0FBQztBQUN4RSxnQkFBQSxJQUFJLFVBQVUsRUFBRSxJQUFJLElBQUksSUFBSSxDQUFDLFlBQVksQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLEVBQUU7b0JBQzFELE9BQU8sQ0FBQyxHQUFHLENBQUMsQ0FBeUIsc0JBQUEsRUFBQSxVQUFVLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBRSxDQUFBLENBQUMsQ0FBQztvQkFDN0QsTUFBTSxJQUFJLENBQUMsYUFBYSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsQ0FBQztpQkFDM0M7cUJBQU07QUFDTCxvQkFBQSxJQUFJQyxlQUFNLENBQUMsdUNBQXVDLENBQUMsQ0FBQztpQkFDckQ7QUFDSCxhQUFDLENBQUMsQ0FBQztBQUNILFlBQUEsT0FBTyxDQUFDLEdBQUcsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDO1lBRWpDLElBQUksQ0FBQyxVQUFVLENBQUM7QUFDZCxnQkFBQSxFQUFFLEVBQUUsdUJBQXVCO0FBQzNCLGdCQUFBLElBQUksRUFBRSx1QkFBdUI7Z0JBQzdCLFFBQVEsRUFBRSxZQUFXO0FBQ25CLG9CQUFBLE1BQU0sVUFBVSxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsU0FBUyxDQUFDLG1CQUFtQixDQUFDRCxxQkFBWSxDQUFDLENBQUM7QUFDeEUsb0JBQUEsSUFBSSxVQUFVLEVBQUUsSUFBSSxJQUFJLElBQUksQ0FBQyxZQUFZLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxFQUFFO3dCQUMxRCxPQUFPLENBQUMsR0FBRyxDQUFDLENBQWlDLDhCQUFBLEVBQUEsVUFBVSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUUsQ0FBQSxDQUFDLENBQUM7d0JBQ3JFLE1BQU0sSUFBSSxDQUFDLGFBQWEsQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLENBQUM7cUJBQzNDO3lCQUFNO0FBQ0wsd0JBQUEsSUFBSUMsZUFBTSxDQUFDLHVDQUF1QyxDQUFDLENBQUM7cUJBQ3JEO2lCQUNGO0FBQ0QsZ0JBQUEsT0FBTyxFQUFFLENBQUMsRUFBRSxTQUFTLEVBQUUsQ0FBQyxNQUFNLEVBQUUsT0FBTyxDQUFDLEVBQUUsR0FBRyxFQUFFLEdBQUcsRUFBRSxDQUFDO0FBQ3RELGFBQUEsQ0FBQyxDQUFDO0FBRUgsWUFBQSxPQUFPLENBQUMsR0FBRyxDQUFDLGdCQUFnQixDQUFDLENBQUM7U0FDL0I7UUFBQyxPQUFPLEtBQUssRUFBRTtBQUNkLFlBQUEsT0FBTyxDQUFDLEtBQUssQ0FBQyx1QkFBdUIsRUFBRSxLQUFLLENBQUMsQ0FBQztBQUM5QyxZQUFBLElBQUlBLGVBQU0sQ0FDUix3RUFBd0UsQ0FDekUsQ0FBQztTQUNIO0tBQ0Y7SUFFRCxRQUFRLEdBQUE7QUFDTixRQUFBLE9BQU8sQ0FBQyxHQUFHLENBQUMsd0JBQXdCLENBQUMsQ0FBQztRQUN0QyxJQUFJLENBQUMsZUFBZSxFQUFFLENBQUM7S0FDeEI7QUFFRCxJQUFBLE1BQU0sWUFBWSxHQUFBO0FBQ2hCLFFBQUEsSUFBSSxDQUFDLFFBQVEsR0FBRyxNQUFNLENBQUMsTUFBTSxDQUFDLEVBQUUsRUFBRSxnQkFBZ0IsRUFBRSxNQUFNLElBQUksQ0FBQyxRQUFRLEVBQUUsQ0FBQyxDQUFDO0tBQzVFO0FBRUQsSUFBQSxNQUFNLFlBQVksR0FBQTtRQUNoQixNQUFNLElBQUksQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDO0tBQ3BDO0FBRUQsSUFBQSxZQUFZLENBQUMsSUFBVyxFQUFBO0FBQ3RCLFFBQUEsT0FBTyxJQUFJLENBQUMsU0FBUyxLQUFLLEtBQUssQ0FBQztLQUNqQztJQUVELG9CQUFvQixHQUFBO0FBQ2xCLFFBQUEsT0FBTyxDQUFDLEdBQUcsQ0FBQyxpQ0FBaUMsQ0FBQyxDQUFDO1FBQy9DLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDLEtBQUssQ0FBQyxFQUFFLFVBQVUsQ0FBQyxDQUFDO0FBQzdDLFFBQUEsT0FBTyxDQUFDLEdBQUcsQ0FBQyw2QkFBNkIsQ0FBQyxDQUFDO0tBQzVDO0lBRUQsTUFBTSxhQUFhLENBQUMsSUFBVyxFQUFBO1FBQzdCLElBQUksSUFBSSxDQUFDLHNCQUFzQixDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEVBQUU7QUFDOUMsWUFBQSxNQUFNLElBQUksQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLENBQUM7U0FDOUI7YUFBTTtBQUNMLFlBQUEsTUFBTSxJQUFJLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxDQUFDO1NBQy9CO0tBQ0Y7SUFFRCxNQUFNLFlBQVksQ0FBQyxJQUFXLEVBQUE7UUFDNUIsSUFBSSxJQUFJLENBQUMsc0JBQXNCLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsRUFBRTtZQUM5QyxPQUFPLENBQUMsR0FBRyxDQUFDLENBQUEsNkJBQUEsRUFBZ0MsSUFBSSxDQUFDLElBQUksQ0FBRSxDQUFBLENBQUMsQ0FBQztBQUN6RCxZQUFBLE9BQU87U0FDUjtBQUVELFFBQUEsSUFBSTtBQUNGLFlBQUEsTUFBTSxZQUFZLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMscUJBQXFCLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO1lBQ3JFLElBQUksQ0FBQyxZQUFZLElBQUksRUFBRSxZQUFZLFlBQVlDLGNBQUssQ0FBQyxFQUFFO2dCQUNyRCxJQUFJRCxlQUFNLENBQUMsQ0FBUSxLQUFBLEVBQUEsSUFBSSxDQUFDLElBQUksQ0FBQSxVQUFBLENBQVksQ0FBQyxDQUFDO2dCQUMxQyxPQUFPO2FBQ1I7QUFDRCxZQUFBLE1BQU0sUUFBUSxHQUFJLElBQUksQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLE9BQWUsQ0FBQyxXQUFXLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxDQUFDO1lBQ2hGLE1BQU0sVUFBVSxHQUFHRSxlQUFJLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxDQUFDO0FBRTFDLFlBQUEsT0FBTyxDQUFDLEdBQUcsQ0FBQyx1QkFBdUIsUUFBUSxDQUFBLENBQUUsQ0FBQyxDQUFDO0FBQy9DLFlBQUEsT0FBTyxDQUFDLEdBQUcsQ0FBQyxzQkFBc0IsVUFBVSxDQUFBLENBQUUsQ0FBQyxDQUFDO0FBRWhELFlBQUEsTUFBTSxPQUFPLEdBQXNCO0FBQ2pDLGdCQUFBLEdBQUcsT0FBTyxDQUFDLEdBQUc7YUFDZixDQUFDO1lBRUYsSUFBSSxJQUFJLENBQUMsUUFBUSxDQUFDLFdBQVcsQ0FBQyxJQUFJLEVBQUUsRUFBRTtnQkFDcEMsT0FBTyxDQUFDLFlBQVksR0FBRyxJQUFJLENBQUMsUUFBUSxDQUFDLFdBQVcsQ0FBQyxJQUFJLEVBQUUsQ0FBQztnQkFDeEQsT0FBTyxDQUFDLEdBQUcsQ0FBQyxDQUFBLHFCQUFBLEVBQXdCLE9BQU8sQ0FBQyxZQUFZLENBQUUsQ0FBQSxDQUFDLENBQUM7YUFDN0Q7aUJBQU07QUFDTCxnQkFBQSxPQUFPLENBQUMsR0FBRyxDQUFDLCtCQUErQixDQUFDLENBQUM7YUFDOUM7QUFFRCxZQUFBLE1BQU0sYUFBYSxHQUFHQyxtQkFBSyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsVUFBVSxFQUFFLENBQUMsU0FBUyxFQUFFLFFBQVEsQ0FBQyxFQUFFO0FBQzNFLGdCQUFBLEdBQUcsRUFBRSxVQUFVO0FBQ2YsZ0JBQUEsR0FBRyxFQUFFLE9BQU87QUFDYixhQUFBLENBQUMsQ0FBQztZQUVILElBQUksVUFBVSxHQUFrQixJQUFJLENBQUM7WUFFckMsYUFBYSxDQUFDLE1BQU0sRUFBRSxFQUFFLENBQUMsTUFBTSxFQUFFLENBQUMsSUFBWSxLQUFJO0FBQ2hELGdCQUFBLE1BQU0sTUFBTSxHQUFHLElBQUksQ0FBQyxRQUFRLEVBQUUsQ0FBQztBQUMvQixnQkFBQSxPQUFPLENBQUMsR0FBRyxDQUFDLDBCQUEwQixNQUFNLENBQUEsQ0FBRSxDQUFDLENBQUM7QUFFaEQsZ0JBQUEsSUFBSSxNQUFNLENBQUMsUUFBUSxDQUFDLFdBQVcsQ0FBQyxFQUFFO29CQUNoQyxNQUFNLEtBQUssR0FBRyxNQUFNLENBQUMsS0FBSyxDQUFDLCtCQUErQixDQUFDLENBQUM7QUFDNUQsb0JBQUEsSUFBSSxLQUFLLElBQUksS0FBSyxDQUFDLENBQUMsQ0FBQyxFQUFFO0FBQ3JCLHdCQUFBLFVBQVUsR0FBRyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDdEIsd0JBQUEsSUFBSUgsZUFBTSxDQUFDLENBQUEscUJBQUEsRUFBd0IsVUFBVSxDQUFBLENBQUUsQ0FBQyxDQUFDO0FBRWpELHdCQUFBLE1BQU0sSUFBSSxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsU0FBUyxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsQ0FBQzt3QkFDL0MsSUFBSSxDQUFDLFlBQVksQ0FBQztBQUNoQiw0QkFBQSxJQUFJLEVBQUUsV0FBVztBQUNqQiw0QkFBQSxNQUFNLEVBQUUsSUFBSTtBQUNaLDRCQUFBLEtBQUssRUFBRTtBQUNMLGdDQUFBLEdBQUcsRUFBRSxVQUFVO0FBQ2hCLDZCQUFBO0FBQ0YseUJBQUEsQ0FBQyxDQUFDO3dCQUNILElBQUksQ0FBQyxHQUFHLENBQUMsU0FBUyxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsQ0FBQztxQkFDckM7aUJBQ0Y7QUFDSCxhQUFDLENBQUMsQ0FBQztZQUVILGFBQWEsQ0FBQyxNQUFNLEVBQUUsRUFBRSxDQUFDLE1BQU0sRUFBRSxDQUFDLElBQVksS0FBSTtBQUNoRCxnQkFBQSxPQUFPLENBQUMsS0FBSyxDQUFDLHlCQUF5QixJQUFJLENBQUEsQ0FBRSxDQUFDLENBQUM7QUFDL0MsZ0JBQUEsSUFBSUEsZUFBTSxDQUFDLENBQUEsc0JBQUEsRUFBeUIsSUFBSSxDQUFBLENBQUUsQ0FBQyxDQUFDO0FBQzlDLGFBQUMsQ0FBQyxDQUFDO1lBRUgsYUFBYSxDQUFDLEVBQUUsQ0FBQyxPQUFPLEVBQUUsQ0FBQyxJQUFtQixLQUFJO2dCQUNoRCxJQUFJLElBQUksS0FBSyxJQUFJLElBQUksSUFBSSxLQUFLLENBQUMsRUFBRTtBQUMvQixvQkFBQSxJQUFJQSxlQUFNLENBQUMsQ0FBQSx3Q0FBQSxFQUEyQyxJQUFJLENBQUEsQ0FBRSxDQUFDLENBQUM7aUJBQy9EO2dCQUNELElBQUksQ0FBQyxzQkFBc0IsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO0FBQ2hELGFBQUMsQ0FBQyxDQUFDO1lBRUgsSUFBSSxDQUFDLHNCQUFzQixDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsSUFBSSxFQUFFLGFBQWEsQ0FBQyxDQUFDO0FBQzFELFlBQUEsSUFBSUEsZUFBTSxDQUFDLHdCQUF3QixDQUFDLENBQUM7U0FDdEM7UUFBQyxPQUFPLEtBQUssRUFBRTtBQUNkLFlBQUEsT0FBTyxDQUFDLEtBQUssQ0FBQyxpQ0FBaUMsRUFBRSxLQUFLLENBQUMsQ0FBQztBQUN4RCxZQUFBLElBQUlBLGVBQU0sQ0FBQyxnQ0FBZ0MsQ0FBQyxDQUFDO1NBQzlDO0tBQ0Y7SUFFRCxNQUFNLFdBQVcsQ0FBQyxJQUFXLEVBQUE7QUFDM0IsUUFBQSxNQUFNLGFBQWEsR0FBRyxJQUFJLENBQUMsc0JBQXNCLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUNqRSxJQUFJLGFBQWEsRUFBRTtBQUNqQixZQUFBLElBQUksQ0FBQyxhQUFhLENBQUMsTUFBTSxFQUFFO2dCQUN6QixhQUFhLENBQUMsSUFBSSxFQUFFLENBQUM7YUFDdEI7WUFDRCxJQUFJLENBQUMsc0JBQXNCLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUM5QyxZQUFBLElBQUlBLGVBQU0sQ0FBQyx3QkFBd0IsQ0FBQyxDQUFDO1NBQ3RDO0tBQ0Y7SUFFRCxlQUFlLEdBQUE7UUFDYixJQUFJLENBQUMsc0JBQXNCLENBQUMsT0FBTyxDQUFDLENBQUMsYUFBYSxFQUFFLFFBQVEsS0FBSTtBQUM5RCxZQUFBLElBQUksQ0FBQyxhQUFhLENBQUMsTUFBTSxFQUFFO2dCQUN6QixhQUFhLENBQUMsSUFBSSxFQUFFLENBQUM7YUFDdEI7QUFDRCxZQUFBLElBQUksQ0FBQyxzQkFBc0IsQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLENBQUM7QUFDL0MsU0FBQyxDQUFDLENBQUM7UUFDSCxJQUFJLElBQUksQ0FBQyxzQkFBc0IsQ0FBQyxJQUFJLEdBQUcsQ0FBQyxFQUFFO0FBQ3hDLFlBQUEsSUFBSUEsZUFBTSxDQUFDLDZCQUE2QixDQUFDLENBQUM7U0FDM0M7S0FDRjtBQUNGLENBQUE7QUFFRCxNQUFNLGFBQWMsU0FBUUkseUJBQWdCLENBQUE7SUFHMUMsV0FBWSxDQUFBLEdBQVEsRUFBRSxNQUFxQixFQUFBO0FBQ3pDLFFBQUEsS0FBSyxDQUFDLEdBQUcsRUFBRSxNQUFNLENBQUMsQ0FBQztBQUNuQixRQUFBLElBQUksQ0FBQyxNQUFNLEdBQUcsTUFBTSxDQUFDO0tBQ3RCO0lBRUQsT0FBTyxHQUFBO0FBQ0wsUUFBQSxNQUFNLEVBQUUsV0FBVyxFQUFFLEdBQUcsSUFBSSxDQUFDO1FBQzdCLFdBQVcsQ0FBQyxLQUFLLEVBQUUsQ0FBQztBQUVwQixRQUFBLE9BQU8sQ0FBQyxHQUFHLENBQUMsMkJBQTJCLENBQUMsQ0FBQztRQUV6QyxXQUFXLENBQUMsUUFBUSxDQUFDLElBQUksRUFBRSxFQUFFLElBQUksRUFBRSx5QkFBeUIsRUFBRSxDQUFDLENBQUM7UUFFaEUsSUFBSUMsZ0JBQU8sQ0FBQyxXQUFXLENBQUM7YUFDckIsT0FBTyxDQUFDLGFBQWEsQ0FBQzthQUN0QixPQUFPLENBQUMsaUVBQWlFLENBQUM7QUFDMUUsYUFBQSxPQUFPLENBQUMsQ0FBQyxJQUFJLEtBQ1osSUFBSTthQUNELGNBQWMsQ0FBQyxRQUFRLENBQUM7YUFDeEIsUUFBUSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLFVBQVUsQ0FBQztBQUN6QyxhQUFBLFFBQVEsQ0FBQyxPQUFPLEtBQUssS0FBSTtBQUN4QixZQUFBLE9BQU8sQ0FBQyxHQUFHLENBQUMsMkJBQTJCLEtBQUssQ0FBQSxDQUFFLENBQUMsQ0FBQztZQUNoRCxJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxVQUFVLEdBQUcsS0FBSyxDQUFDO0FBQ3hDLFlBQUEsTUFBTSxJQUFJLENBQUMsTUFBTSxDQUFDLFlBQVksRUFBRSxDQUFDO1NBQ2xDLENBQUMsQ0FDTCxDQUFDO1FBRUosSUFBSUEsZ0JBQU8sQ0FBQyxXQUFXLENBQUM7YUFDckIsT0FBTyxDQUFDLGdDQUFnQyxDQUFDO2FBQ3pDLE9BQU8sQ0FDTiw2RUFBNkUsQ0FDOUU7QUFDQSxhQUFBLFNBQVMsQ0FBQyxDQUFDLE1BQU0sS0FDaEIsTUFBTTthQUNILFFBQVEsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxnQkFBZ0IsQ0FBQztBQUMvQyxhQUFBLFFBQVEsQ0FBQyxPQUFPLEtBQUssS0FBSTtBQUN4QixZQUFBLE9BQU8sQ0FBQyxHQUFHLENBQUMsMENBQTBDLEtBQUssQ0FBQSxDQUFFLENBQUMsQ0FBQztZQUMvRCxJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxnQkFBZ0IsR0FBRyxLQUFLLENBQUM7WUFFOUMsSUFBSSxLQUFLLEVBQUU7QUFDVCxnQkFBQSxJQUFJLENBQUMsTUFBTSxDQUFDLG9CQUFvQixFQUFFLENBQUM7YUFDcEM7aUJBQU07QUFDTCxnQkFBQSxPQUFPLENBQUMsR0FBRyxDQUNULHNEQUFzRCxDQUN2RCxDQUFDO2FBQ0g7QUFFRCxZQUFBLE1BQU0sSUFBSSxDQUFDLE1BQU0sQ0FBQyxZQUFZLEVBQUUsQ0FBQztTQUNsQyxDQUFDLENBQ0wsQ0FBQztRQUVKLElBQUlBLGdCQUFPLENBQUMsV0FBVyxDQUFDO2FBQ3JCLE9BQU8sQ0FBQyx1QkFBdUIsQ0FBQzthQUNoQyxPQUFPLENBQUMscUVBQXFFLENBQUM7QUFDOUUsYUFBQSxPQUFPLENBQUMsQ0FBQyxJQUFJLEtBQ1osSUFBSTthQUNELGNBQWMsQ0FBQyxrQkFBa0IsQ0FBQzthQUNsQyxRQUFRLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsV0FBVyxDQUFDO0FBQzFDLGFBQUEsUUFBUSxDQUFDLE9BQU8sS0FBSyxLQUFJO0FBQ3hCLFlBQUEsT0FBTyxDQUFDLEdBQUcsQ0FBQyx3QkFBd0IsS0FBSyxDQUFBLENBQUUsQ0FBQyxDQUFDO1lBQzdDLElBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLFdBQVcsR0FBRyxLQUFLLENBQUM7QUFDekMsWUFBQSxNQUFNLElBQUksQ0FBQyxNQUFNLENBQUMsWUFBWSxFQUFFLENBQUM7U0FDbEMsQ0FBQyxDQUNMLENBQUM7QUFFSixRQUFBLE9BQU8sQ0FBQyxHQUFHLENBQUMsb0NBQW9DLENBQUMsQ0FBQztLQUNuRDtBQUNGOzs7OyJ9
